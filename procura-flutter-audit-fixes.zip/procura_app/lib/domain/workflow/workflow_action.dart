enum WorkflowAction {
  submitForApproval,
  approveDepartment,
  requestChanges,
  reject,
  publishRfq,
  openEvaluation,
  /// Records recommendation only — does not change procurement status.
  /// Applied in the service layer; not a state-machine transition.
  recommendVendor,
  award,
  issuePo,
  markPreparing,
  markDispatched,
  markInTransit,
  markDelivered,
  receiveGoods,
  submitInvoice,
  approvePayment,
  holdPaymentReview,
  complete,
}
