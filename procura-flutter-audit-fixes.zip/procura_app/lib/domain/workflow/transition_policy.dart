import '../models/auth_user.dart';
import '../models/procurement_status.dart';
import '../models/role.dart';
import 'state_machine.dart';
import 'workflow_action.dart';

/// Policy checks applied before a state-machine transition.
/// Used by [WorkflowService] inside a DB transaction.
class TransitionPolicy {
  /// Throws [WorkflowException] if the actor may not apply [action] to this row.
  static void assertAllowed({
    required ProcurementStatus from,
    required WorkflowAction action,
    required AuthUser actor,
    required String createdByUserId,
    required String departmentId,
  }) {
    // Self-approval block
    if (action == WorkflowAction.approveDepartment ||
        action == WorkflowAction.requestChanges ||
        action == WorkflowAction.reject) {
      if (createdByUserId == actor.id) {
        throw WorkflowException('You cannot approve or reject your own request.');
      }
    }

    // Cross-department block
    if (actor.role == UserRole.departmentHead &&
        (action == WorkflowAction.approveDepartment ||
            action == WorkflowAction.requestChanges ||
            action == WorkflowAction.reject)) {
      if (actor.departmentId == null || actor.departmentId != departmentId) {
        throw WorkflowException(
          'Department heads may only act on requests from their own department.',
        );
      }
    }

    // Role / status table
    ProcurementStateMachine.transition(
      from: from,
      action: action,
      role: actor.role,
    );
  }

  /// Returns next status after policy + state machine succeed.
  static ProcurementStatus nextStatus({
    required ProcurementStatus from,
    required WorkflowAction action,
    required AuthUser actor,
    required String createdByUserId,
    required String departmentId,
  }) {
    assertAllowed(
      from: from,
      action: action,
      actor: actor,
      createdByUserId: createdByUserId,
      departmentId: departmentId,
    );
    return ProcurementStateMachine.transition(
      from: from,
      action: action,
      role: actor.role,
    );
  }
}
