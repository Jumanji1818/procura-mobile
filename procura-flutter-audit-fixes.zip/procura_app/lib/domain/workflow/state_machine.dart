import '../models/procurement_status.dart';
import '../models/role.dart';
import 'workflow_action.dart';

/// Single source of truth for allowed transitions.
/// UI must never decide transitions — only this table.
class TransitionRule {
  final ProcurementStatus from;
  final WorkflowAction action;
  final Set<UserRole> roles;
  final ProcurementStatus to;

  const TransitionRule({
    required this.from,
    required this.action,
    required this.roles,
    required this.to,
  });
}

class WorkflowException implements Exception {
  final String message;
  WorkflowException(this.message);
  @override
  String toString() => message;
}

class ProcurementStateMachine {
  /// Org Admin is included only where a documented operational need exists
  /// (publish RFQ, issue PO, complete). Separation of duties: Admin is NOT
  /// on approveDepartment, award, or approvePayment.
  static const List<TransitionRule> rules = [
    TransitionRule(
      from: ProcurementStatus.draft,
      action: WorkflowAction.submitForApproval,
      roles: {UserRole.requestOfficer, UserRole.procurementOfficer},
      to: ProcurementStatus.pendingDepartmentApproval,
    ),
    TransitionRule(
      from: ProcurementStatus.changesRequested,
      action: WorkflowAction.submitForApproval,
      roles: {UserRole.requestOfficer, UserRole.procurementOfficer},
      to: ProcurementStatus.pendingDepartmentApproval,
    ),
    TransitionRule(
      from: ProcurementStatus.pendingDepartmentApproval,
      action: WorkflowAction.approveDepartment,
      roles: {UserRole.departmentHead},
      to: ProcurementStatus.rfqPublished,
    ),
    TransitionRule(
      from: ProcurementStatus.pendingDepartmentApproval,
      action: WorkflowAction.requestChanges,
      roles: {UserRole.departmentHead},
      to: ProcurementStatus.changesRequested,
    ),
    TransitionRule(
      from: ProcurementStatus.pendingDepartmentApproval,
      action: WorkflowAction.reject,
      roles: {UserRole.departmentHead},
      to: ProcurementStatus.rejected,
    ),
    TransitionRule(
      from: ProcurementStatus.rfqPublished,
      action: WorkflowAction.publishRfq,
      roles: {UserRole.procurementOfficer, UserRole.orgAdmin},
      to: ProcurementStatus.bidding,
    ),
    TransitionRule(
      from: ProcurementStatus.bidding,
      action: WorkflowAction.openEvaluation,
      roles: {UserRole.procurementOfficer, UserRole.orgAdmin},
      to: ProcurementStatus.evaluating,
    ),
    // recommendVendor records a recommendation without changing status
    // (handled in service layer; not a status transition).
    TransitionRule(
      from: ProcurementStatus.evaluating,
      action: WorkflowAction.award,
      roles: {UserRole.approvingAuthority},
      to: ProcurementStatus.awarded,
    ),
    TransitionRule(
      from: ProcurementStatus.evaluating,
      action: WorkflowAction.reject,
      roles: {UserRole.approvingAuthority},
      to: ProcurementStatus.rejected,
    ),
    TransitionRule(
      from: ProcurementStatus.awarded,
      action: WorkflowAction.issuePo,
      roles: {UserRole.procurementOfficer, UserRole.orgAdmin},
      to: ProcurementStatus.poIssued,
    ),
    TransitionRule(
      from: ProcurementStatus.poIssued,
      action: WorkflowAction.markPreparing,
      roles: {UserRole.vendor},
      to: ProcurementStatus.preparing,
    ),
    TransitionRule(
      from: ProcurementStatus.preparing,
      action: WorkflowAction.markDispatched,
      roles: {UserRole.vendor},
      to: ProcurementStatus.dispatched,
    ),
    TransitionRule(
      from: ProcurementStatus.dispatched,
      action: WorkflowAction.markInTransit,
      roles: {UserRole.vendor},
      to: ProcurementStatus.inTransit,
    ),
    TransitionRule(
      from: ProcurementStatus.inTransit,
      action: WorkflowAction.markDelivered,
      roles: {UserRole.vendor},
      to: ProcurementStatus.delivered,
    ),
    TransitionRule(
      from: ProcurementStatus.delivered,
      action: WorkflowAction.receiveGoods,
      roles: {UserRole.requestOfficer, UserRole.procurementOfficer},
      to: ProcurementStatus.goodsReceived,
    ),
    TransitionRule(
      from: ProcurementStatus.goodsReceived,
      action: WorkflowAction.submitInvoice,
      roles: {UserRole.vendor},
      to: ProcurementStatus.invoiced,
    ),
    TransitionRule(
      from: ProcurementStatus.invoiced,
      action: WorkflowAction.approvePayment,
      roles: {UserRole.financeOfficer},
      to: ProcurementStatus.paid,
    ),
    TransitionRule(
      from: ProcurementStatus.invoiced,
      action: WorkflowAction.holdPaymentReview,
      roles: {UserRole.financeOfficer},
      to: ProcurementStatus.paymentReview,
    ),
    TransitionRule(
      from: ProcurementStatus.paymentReview,
      action: WorkflowAction.approvePayment,
      roles: {UserRole.financeOfficer},
      to: ProcurementStatus.paid,
    ),
    TransitionRule(
      from: ProcurementStatus.paid,
      action: WorkflowAction.complete,
      roles: {UserRole.procurementOfficer, UserRole.orgAdmin},
      to: ProcurementStatus.completed,
    ),
  ];

  /// Resolve next status or throw [WorkflowException].
  static ProcurementStatus transition({
    required ProcurementStatus from,
    required WorkflowAction action,
    required UserRole role,
  }) {
    if (from.isTerminal) {
      throw WorkflowException(
        'Cannot change status: procurement is already ${from.label}.',
      );
    }
    final match = rules.where((r) => r.from == from && r.action == action).toList();
    if (match.isEmpty) {
      throw WorkflowException(
        'Action ${action.name} is not allowed from ${from.label}.',
      );
    }
    final rule = match.first;
    if (!rule.roles.contains(role)) {
      throw WorkflowException(
        'Role ${role.label} cannot perform ${action.name} on ${from.label}.',
      );
    }
    return rule.to;
  }

  static bool can({
    required ProcurementStatus from,
    required WorkflowAction action,
    required UserRole role,
  }) {
    try {
      transition(from: from, action: action, role: role);
      return true;
    } on WorkflowException {
      return false;
    }
  }

  /// All roles that appear in any rule (for matrix tests).
  static Set<UserRole> get actingRoles => {
        for (final r in rules) ...r.roles,
      };
}
