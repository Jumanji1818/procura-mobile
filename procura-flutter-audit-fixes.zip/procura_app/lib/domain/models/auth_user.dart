import 'role.dart';

class AuthUser {
  final String id;
  final String email;
  final String displayName;
  final UserRole role;
  final String? departmentId;

  const AuthUser({
    required this.id,
    required this.email,
    required this.displayName,
    required this.role,
    this.departmentId,
  });

  AuthUser copyWith({
    String? id,
    String? email,
    String? displayName,
    UserRole? role,
    String? departmentId,
  }) {
    return AuthUser(
      id: id ?? this.id,
      email: email ?? this.email,
      displayName: displayName ?? this.displayName,
      role: role ?? this.role,
      departmentId: departmentId ?? this.departmentId,
    );
  }
}
