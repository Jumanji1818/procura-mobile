/// Forward-only procurement lifecycle states.
enum ProcurementStatus {
  draft,
  pendingDepartmentApproval,
  changesRequested,
  rejected,
  rfqPublished,
  bidding,
  evaluating,
  awarded,
  poIssued,
  preparing,
  dispatched,
  inTransit,
  delivered,
  goodsReceived,
  invoiced,
  paymentReview,
  paid,
  completed;

  String get label => switch (this) {
        ProcurementStatus.draft => 'Draft',
        ProcurementStatus.pendingDepartmentApproval => 'Awaiting department approval',
        ProcurementStatus.changesRequested => 'Changes requested',
        ProcurementStatus.rejected => 'Rejected',
        ProcurementStatus.rfqPublished => 'RFQ published',
        ProcurementStatus.bidding => 'Bidding open',
        ProcurementStatus.evaluating => 'Evaluating',
        ProcurementStatus.awarded => 'Awarded',
        ProcurementStatus.poIssued => 'PO issued',
        ProcurementStatus.preparing => 'Preparing',
        ProcurementStatus.dispatched => 'Dispatched',
        ProcurementStatus.inTransit => 'In transit',
        ProcurementStatus.delivered => 'Delivered',
        ProcurementStatus.goodsReceived => 'Goods received',
        ProcurementStatus.invoiced => 'Invoiced',
        ProcurementStatus.paymentReview => 'Payment review',
        ProcurementStatus.paid => 'Paid',
        ProcurementStatus.completed => 'Completed',
      };

  bool get isTerminal =>
      this == ProcurementStatus.rejected || this == ProcurementStatus.completed;

  static ProcurementStatus fromStorage(String value) => ProcurementStatus.values
      .firstWhere((s) => s.name == value, orElse: () => ProcurementStatus.draft);
}
