/// Organisation roles for Procura. Every user has exactly one role after approval.
enum UserRole {
  orgAdmin,
  requestOfficer,
  departmentHead,
  procurementOfficer,
  financeOfficer,
  approvingAuthority,
  vendor,
  pending; // self-registered staff awaiting admin assignment

  String get label => switch (this) {
        UserRole.orgAdmin => 'Org Admin',
        UserRole.requestOfficer => 'Request Officer',
        UserRole.departmentHead => 'Department Head',
        UserRole.procurementOfficer => 'Procurement Officer',
        UserRole.financeOfficer => 'Finance Officer',
        UserRole.approvingAuthority => 'Approving Authority',
        UserRole.vendor => 'Vendor',
        UserRole.pending => 'Pending approval',
      };

  static UserRole fromStorage(String value) =>
      UserRole.values.firstWhere((r) => r.name == value, orElse: () => UserRole.pending);
}
