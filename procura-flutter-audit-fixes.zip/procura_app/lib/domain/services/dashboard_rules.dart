import '../models/procurement_status.dart';
import '../models/role.dart';

/// Statuses in which [role] has something to do (drives the dashboard counter).
Set<ProcurementStatus> awaitingStatusesFor(UserRole role) {
  switch (role) {
    case UserRole.requestOfficer:
      return {
        ProcurementStatus.draft,
        ProcurementStatus.changesRequested,
        ProcurementStatus.delivered,
      };
    case UserRole.departmentHead:
      return {ProcurementStatus.pendingDepartmentApproval};
    case UserRole.procurementOfficer:
      return {
        ProcurementStatus.rfqPublished,
        ProcurementStatus.bidding,
        ProcurementStatus.awarded,
        ProcurementStatus.delivered,
        ProcurementStatus.paid,
      };
    case UserRole.approvingAuthority:
      return {ProcurementStatus.evaluating};
    case UserRole.financeOfficer:
      return {ProcurementStatus.invoiced, ProcurementStatus.paymentReview};
    case UserRole.orgAdmin:
      return {
        ProcurementStatus.rfqPublished,
        ProcurementStatus.awarded,
        ProcurementStatus.paid,
      };
    case UserRole.vendor:
    case UserRole.pending:
      return <ProcurementStatus>{};
  }
}
