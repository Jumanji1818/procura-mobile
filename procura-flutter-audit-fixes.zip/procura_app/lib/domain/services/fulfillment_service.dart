import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';

import '../../data/db/app_database.dart';
import '../models/auth_user.dart';
import '../models/procurement_status.dart';
import '../models/role.dart';
import '../workflow/workflow_action.dart';
import 'notification_service.dart';
import 'workflow_service.dart';

class FulfillmentException implements Exception {
  final String message;
  FulfillmentException(this.message);
  @override
  String toString() => message;
}

/// Award, PO, vendor delivery (forward-only), goods receipt.
///
/// Every multi-step operation runs the workflow transition FIRST inside one
/// database transaction, so a rejected role/state check leaves no partial data.
class FulfillmentService {
  FulfillmentService(this._db, this._workflow);
  final AppDatabase _db;
  final WorkflowService _workflow;
  static const _uuid = Uuid();

  /// Remaining category budget for the current year, or null if none is set.
  Future<int?> _remainingCategoryBudget(String categoryId) async {
    final year = DateTime.now().year;
    final row = await (_db.select(_db.categoryBudgets)
          ..where((b) => b.categoryId.equals(categoryId) & b.year.equals(year)))
        .getSingleOrNull();
    if (row == null) return null;
    return row.amountKobo - row.spentKobo;
  }

  Future<void> award({
    required AuthUser actor,
    required String procurementId,
    String? vendorId,
  }) async {
    final proc = await (_db.select(_db.procurements)..where((p) => p.id.equals(procurementId)))
        .getSingleOrNull();
    if (proc == null) throw FulfillmentException('Procurement not found.');

    final awardedVendor = vendorId ?? proc.recommendedVendorId;
    if (awardedVendor == null || awardedVendor.isEmpty) {
      throw FulfillmentException('Select or recommend a vendor before award.');
    }

    final bid = await (_db.select(_db.bids)
          ..where((b) => b.procurementId.equals(procurementId) & b.vendorId.equals(awardedVendor)))
        .getSingleOrNull();
    if (bid == null) {
      throw FulfillmentException('That vendor has not bid on this RFQ.');
    }

    if (proc.budgetKobo != null && bid.totalPriceKobo > proc.budgetKobo!) {
      throw FulfillmentException('Award blocked: bid total exceeds the request budget.');
    }
    final remaining = await _remainingCategoryBudget(proc.categoryId);
    if (remaining != null && bid.totalPriceKobo > remaining) {
      throw FulfillmentException('Award blocked: bid total exceeds the remaining category budget.');
    }

    await _db.transaction(() async {
      await _workflow.apply(
        procurementId: procurementId,
        action: WorkflowAction.award,
        actor: actor,
        detail: 'vendor=$awardedVendor total=${bid.totalPriceKobo}',
      );
      await (_db.update(_db.procurements)..where((p) => p.id.equals(procurementId))).write(
        ProcurementsCompanion(
          awardedVendorId: Value(awardedVendor),
          updatedAt: Value(DateTime.now().toUtc()),
        ),
      );

      final v = await (_db.select(_db.vendorProfiles)..where((x) => x.id.equals(awardedVendor)))
          .getSingleOrNull();
      if (v != null) {
        await NotificationService(_db).notifyUsers(
          [v.userId],
          title: 'You won ${proc.number}',
          body: proc.title,
          procurementId: procurementId,
          kind: 'awarded',
        );
      }
    });
  }

  Future<String> issuePo({
    required AuthUser actor,
    required String procurementId,
  }) async {
    final proc = await (_db.select(_db.procurements)..where((p) => p.id.equals(procurementId)))
        .getSingleOrNull();
    if (proc == null) throw FulfillmentException('Procurement not found.');
    if (proc.status != ProcurementStatus.awarded.name) {
      throw FulfillmentException('PO can only be issued after award.');
    }
    final vendorId = proc.awardedVendorId;
    if (vendorId == null) {
      throw FulfillmentException('No awarded vendor.');
    }

    final bid = await (_db.select(_db.bids)
          ..where((b) => b.procurementId.equals(procurementId) & b.vendorId.equals(vendorId)))
        .getSingleOrNull();
    if (bid == null) {
      throw FulfillmentException('The awarded vendor has no bid on file.');
    }
    final poId = _uuid.v4();

    await _db.transaction(() async {
      // Role/state check first — rolls everything back if the caller is not allowed.
      await _workflow.apply(
        procurementId: procurementId,
        action: WorkflowAction.issuePo,
        actor: actor,
      );
      final now = DateTime.now().toUtc();
      final number = await _db.nextDocumentNumber('PO');
      await _db.into(_db.purchaseOrders).insert(PurchaseOrdersCompanion.insert(
            id: poId,
            number: number,
            procurementId: procurementId,
            vendorId: vendorId,
            totalKobo: bid.totalPriceKobo,
            deliveryLocation: Value(proc.deliveryLocation),
            status: ProcurementStatus.poIssued.name,
            createdAt: now,
          ));
      await _db.into(_db.deliveries).insert(DeliveriesCompanion.insert(
            id: _uuid.v4(),
            poId: poId,
            procurementId: procurementId,
            vendorId: vendorId,
            status: ProcurementStatus.poIssued.name,
            updatedAt: now,
          ));
    });

    return poId;
  }

  Future<Procurement?> getProcurement(String id) async {
    return (_db.select(_db.procurements)..where((p) => p.id.equals(id))).getSingleOrNull();
  }

  Future<PurchaseOrder?> poFor(String procurementId) async {
    return (_db.select(_db.purchaseOrders)..where((p) => p.procurementId.equals(procurementId)))
        .getSingleOrNull();
  }

  Future<String> vendorName(String vendorId) async {
    final v = await (_db.select(_db.vendorProfiles)..where((x) => x.id.equals(vendorId)))
        .getSingleOrNull();
    return v?.businessName ?? 'Unknown vendor';
  }

  Future<VendorProfile?> _vendorForUser(String userId) async {
    return (_db.select(_db.vendorProfiles)..where((v) => v.userId.equals(userId))).getSingleOrNull();
  }

  /// Vendor's own POs only.
  Future<List<PurchaseOrder>> listVendorOrders(AuthUser actor) async {
    if (actor.role != UserRole.vendor) return [];
    final profile = await _vendorForUser(actor.id);
    if (profile == null) return [];
    return (_db.select(_db.purchaseOrders)
          ..where((p) => p.vendorId.equals(profile.id))
          ..orderBy([(t) => OrderingTerm.desc(t.createdAt)]))
        .get();
  }

  Future<void> advanceDelivery({
    required AuthUser actor,
    required String procurementId,
    required WorkflowAction action,
  }) async {
    if (actor.role != UserRole.vendor) {
      throw FulfillmentException('Only the assigned vendor can update delivery.');
    }
    final profile = await _vendorForUser(actor.id);
    if (profile == null) throw FulfillmentException('Vendor profile not found.');

    final proc = await (_db.select(_db.procurements)..where((p) => p.id.equals(procurementId)))
        .getSingleOrNull();
    if (proc == null) throw FulfillmentException('Not found.');
    if (proc.awardedVendorId != profile.id) {
      throw FulfillmentException('This order is not assigned to you.');
    }

    const allowed = {
      WorkflowAction.markPreparing,
      WorkflowAction.markDispatched,
      WorkflowAction.markInTransit,
      WorkflowAction.markDelivered,
    };
    if (!allowed.contains(action)) {
      throw FulfillmentException('Invalid delivery action.');
    }

    await _db.transaction(() async {
      final to = await _workflow.apply(
        procurementId: procurementId,
        action: action,
        actor: actor,
      );
      final now = DateTime.now().toUtc();
      await (_db.update(_db.deliveries)..where((d) => d.procurementId.equals(procurementId))).write(
        DeliveriesCompanion(status: Value(to.name), updatedAt: Value(now)),
      );
      await (_db.update(_db.purchaseOrders)..where((p) => p.procurementId.equals(procurementId)))
          .write(PurchaseOrdersCompanion(status: Value(to.name)));
    });
  }

  Future<void> receiveGoods({
    required AuthUser actor,
    required String procurementId,
    required int qtyReceived,
    int qtyDamaged = 0,
    int qtyMissing = 0,
    String? notes,
  }) async {
    // Matches the state machine: requester or procurement officer only.
    if (actor.role != UserRole.requestOfficer && actor.role != UserRole.procurementOfficer) {
      throw FulfillmentException('Only a request or procurement officer can record goods receipt.');
    }
    if (qtyReceived < 0 || qtyDamaged < 0 || qtyMissing < 0) {
      throw FulfillmentException('Quantities cannot be negative.');
    }

    final proc = await (_db.select(_db.procurements)..where((p) => p.id.equals(procurementId)))
        .getSingleOrNull();
    if (proc == null) throw FulfillmentException('Not found.');
    if (proc.status != ProcurementStatus.delivered.name) {
      throw FulfillmentException('Goods can only be received after vendor marks delivered.');
    }
    if (qtyReceived > proc.quantity) {
      throw FulfillmentException('Received quantity cannot exceed the ${proc.quantity} ordered.');
    }
    if (qtyDamaged > qtyReceived) {
      throw FulfillmentException('Damaged quantity cannot exceed the quantity received.');
    }

    final po = await poFor(procurementId);
    if (po == null) throw FulfillmentException('No purchase order.');

    await _db.transaction(() async {
      await _workflow.apply(
        procurementId: procurementId,
        action: WorkflowAction.receiveGoods,
        actor: actor,
        detail: 'received=$qtyReceived damaged=$qtyDamaged missing=$qtyMissing',
      );
      final now = DateTime.now().toUtc();
      await _db.into(_db.goodsReceipts).insert(GoodsReceiptsCompanion.insert(
            id: _uuid.v4(),
            procurementId: procurementId,
            poId: po.id,
            qtyOrdered: proc.quantity,
            qtyReceived: qtyReceived,
            qtyDamaged: Value(qtyDamaged),
            qtyMissing: Value(qtyMissing),
            notes: Value(notes),
            receivedByUserId: actor.id,
            createdAt: now,
          ));
      await (_db.update(_db.purchaseOrders)..where((p) => p.id.equals(po.id)))
          .write(PurchaseOrdersCompanion(status: Value(ProcurementStatus.goodsReceived.name)));

      // Vendor reliability: counted as a problem delivery when goods are missing
      // or more than 10% of the order arrived damaged.
      final vendorId = proc.awardedVendorId;
      if (vendorId != null) {
        final v = await (_db.select(_db.vendorProfiles)..where((x) => x.id.equals(vendorId)))
            .getSingleOrNull();
        if (v != null) {
          final completed = v.completedOrders + 1;
          final late = qtyMissing > 0 || qtyDamaged > proc.quantity * 0.1
              ? v.lateDeliveries + 1
              : v.lateDeliveries;
          final onTime = ((completed - late) / completed * 100).clamp(0, 100).toDouble();
          await (_db.update(_db.vendorProfiles)..where((x) => x.id.equals(vendorId))).write(
            VendorProfilesCompanion(
              completedOrders: Value(completed),
              lateDeliveries: Value(late),
              onTimeRate: Value(onTime),
              flagged: Value(late >= 3),
            ),
          );
        }
      }
    });
  }
}
