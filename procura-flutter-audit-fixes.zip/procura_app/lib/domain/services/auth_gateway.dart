import '../models/auth_user.dart';
import '../models/role.dart';

/// Session surface used by UI / SessionNotifier (testable without Drift).
abstract class AuthGateway {
  AuthUser? get currentUser;
  void setSession(AuthUser? user);
  void logout();
  Future<AuthUser> login({required String email, required String password});
  Future<AuthUser> register({
    required String email,
    required String displayName,
    required String password,
    required bool asVendor,
    List<String> categoryIds = const [],
    String? businessName,
    String? location,
  });
  Future<void> assignRole({
    required String actorUserId,
    required String targetUserId,
    required UserRole role,
    String? departmentId,
    bool clearDepartment = false,
  });
}
