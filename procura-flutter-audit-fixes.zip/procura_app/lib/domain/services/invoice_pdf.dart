import 'dart:typed_data';

import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../../data/db/app_database.dart';
import 'three_way_match.dart';

/// Printable invoice / three-way-match summary. ASCII only ("NGN") because the
/// built-in PDF fonts have no naira glyph.
class InvoicePdf {
  static String _ngn(int kobo) => 'NGN ${NumberFormat('#,##0.00').format(kobo / 100)}';

  static Future<Uint8List> build({
    required Invoice invoice,
    required PurchaseOrder po,
    required GoodsReceipt receipt,
    required ThreeWayMatchResult match,
    required String vendorName,
    required String requestNumber,
    required String requestTitle,
  }) async {
    final doc = pw.Document();
    final date = DateFormat('d MMM yyyy').format(invoice.createdAt.toLocal());

    pw.Widget row(String k, String v) => pw.Padding(
          padding: const pw.EdgeInsets.only(bottom: 6),
          child: pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.SizedBox(width: 160, child: pw.Text(k, style: pw.TextStyle(fontWeight: pw.FontWeight.bold))),
              pw.Expanded(child: pw.Text(v)),
            ],
          ),
        );

    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(40),
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text('INVOICE', style: pw.TextStyle(fontSize: 26, fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 4),
            pw.Text(invoice.number, style: const pw.TextStyle(fontSize: 14)),
            pw.Divider(),
            pw.SizedBox(height: 8),
            row('Date', date),
            row('Vendor', vendorName),
            row('Request', '$requestNumber - $requestTitle'),
            row('Purchase order', po.number),
            row('Invoiced amount', _ngn(invoice.amountKobo)),
            pw.SizedBox(height: 12),
            pw.Text('Three-way match', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 14)),
            pw.SizedBox(height: 6),
            row('PO total', _ngn(po.totalKobo)),
            row('Quantity ordered', '${receipt.qtyOrdered}'),
            row('Quantity received', '${receipt.qtyReceived}'),
            row('Damaged / missing', '${receipt.qtyDamaged} / ${receipt.qtyMissing}'),
            row('Supported by goods received', _ngn(match.expectedAmountKobo)),
            row('Result', match.ok ? 'MATCH' : 'MISMATCH'),
            row('Detail', match.detail),
            row('Payable', _ngn(ThreeWayMatch.payableKobo(match))),
            row('Status', invoice.status),
          ],
        ),
      ),
    );
    return doc.save();
  }
}
