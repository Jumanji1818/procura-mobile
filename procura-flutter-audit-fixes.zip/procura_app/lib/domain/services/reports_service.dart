import '../../data/db/app_database.dart';
import '../models/procurement_status.dart';

class SpendPoint {
  final String label;
  final double amountNaira;
  SpendPoint(this.label, this.amountNaira);
}

class CategorySpend {
  final String category;
  final double amountNaira;
  CategorySpend(this.category, this.amountNaira);
}

/// Offline spend insights from local payments / procurements.
class ReportsService {
  ReportsService(this._db);
  final AppDatabase _db;

  Future<List<CategorySpend>> spendByCategory() async {
    final payments = await _db.select(_db.payments).get();
    final procs = await _db.select(_db.procurements).get();
    final cats = await _db.select(_db.categories).get();
    final catName = {for (final c in cats) c.id: '${c.parentName} · ${c.subcategory}'};
    final procCat = {for (final p in procs) p.id: p.categoryId};

    final map = <String, int>{};
    for (final pay in payments) {
      final catId = procCat[pay.procurementId];
      if (catId == null) continue;
      map[catId] = (map[catId] ?? 0) + pay.amountKobo;
    }
    final list = map.entries
        .map((e) => CategorySpend(catName[e.key] ?? e.key, e.value / 100.0))
        .toList()
      ..sort((a, b) => b.amountNaira.compareTo(a.amountNaira));
    return list;
  }

  Future<List<SpendPoint>> monthlySpendTrend() async {
    final payments = await _db.select(_db.payments).get();
    final map = <String, int>{};
    for (final pay in payments) {
      final key =
          '${pay.paidAt.year}-${pay.paidAt.month.toString().padLeft(2, '0')}';
      map[key] = (map[key] ?? 0) + pay.amountKobo;
    }
    final keys = map.keys.toList()..sort();
    return keys.map((k) => SpendPoint(k, map[k]! / 100.0)).toList();
  }

  /// Simple moving-average forecast for next month (labelled estimate).
  Future<double?> nextMonthEstimateNaira() async {
    final trend = await monthlySpendTrend();
    if (trend.isEmpty) return null;
    final n = trend.length < 3 ? trend.length : 3;
    final slice = trend.sublist(trend.length - n);
    final avg = slice.map((e) => e.amountNaira).reduce((a, b) => a + b) / n;
    return avg;
  }

  Future<Map<String, int>> countByStatus() async {
    final all = await _db.select(_db.procurements).get();
    final map = <String, int>{};
    for (final p in all) {
      final label = ProcurementStatus.fromStorage(p.status).label;
      map[label] = (map[label] ?? 0) + 1;
    }
    return map;
  }
}
