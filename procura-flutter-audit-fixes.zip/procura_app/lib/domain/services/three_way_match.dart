/// Pure three-way match: PO vs goods receipt vs invoice (quantity + amount).
class ThreeWayMatchResult {
  final bool ok;
  final String detail;
  final int expectedAmountKobo;
  final int invoiceAmountKobo;
  final int qtyOrdered;
  final int qtyReceived;

  const ThreeWayMatchResult({
    required this.ok,
    required this.detail,
    required this.expectedAmountKobo,
    required this.invoiceAmountKobo,
    required this.qtyOrdered,
    required this.qtyReceived,
  });
}

class ThreeWayMatch {
  /// What may actually be paid: never more than the pro-rated PO value for the
  /// goods received, and never more than the vendor invoiced.
  static int payableKobo(ThreeWayMatchResult r) {
    final cap = r.expectedAmountKobo;
    if (cap <= 0) return 0;
    return r.invoiceAmountKobo < cap ? r.invoiceAmountKobo : cap;
  }

  /// Pro-rate PO total by received/ordered quantity when partial receipt.
  static ThreeWayMatchResult compare({
    required int poTotalKobo,
    required int qtyOrdered,
    required int qtyReceived,
    required int invoiceAmountKobo,
    int toleranceKobo = 100, // ₦1.00
  }) {
    if (qtyOrdered <= 0) {
      return ThreeWayMatchResult(
        ok: false,
        detail: 'Invalid ordered quantity.',
        expectedAmountKobo: 0,
        invoiceAmountKobo: invoiceAmountKobo,
        qtyOrdered: qtyOrdered,
        qtyReceived: qtyReceived,
      );
    }

    final expected = (poTotalKobo * qtyReceived / qtyOrdered).round();
    final amountOk = (invoiceAmountKobo - expected).abs() <= toleranceKobo;
    final qtyOk = qtyReceived > 0 && qtyReceived <= qtyOrdered;

    if (amountOk && qtyOk) {
      return ThreeWayMatchResult(
        ok: true,
        detail:
            'Match: invoice ₦${(invoiceAmountKobo / 100).toStringAsFixed(2)} aligns with '
            'received $qtyReceived/$qtyOrdered (expected ₦${(expected / 100).toStringAsFixed(2)}).',
        expectedAmountKobo: expected,
        invoiceAmountKobo: invoiceAmountKobo,
        qtyOrdered: qtyOrdered,
        qtyReceived: qtyReceived,
      );
    }

    final parts = <String>[];
    if (!qtyOk) {
      parts.add('quantity issue (received $qtyReceived of $qtyOrdered)');
    }
    if (!amountOk) {
      parts.add(
        'amount mismatch (invoice ₦${(invoiceAmountKobo / 100).toStringAsFixed(2)} vs '
        'expected ₦${(expected / 100).toStringAsFixed(2)})',
      );
    }
    return ThreeWayMatchResult(
      ok: false,
      detail: 'Mismatch: ${parts.join('; ')}. Routed to payment review.',
      expectedAmountKobo: expected,
      invoiceAmountKobo: invoiceAmountKobo,
      qtyOrdered: qtyOrdered,
      qtyReceived: qtyReceived,
    );
  }
}
