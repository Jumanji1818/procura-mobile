import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';

import '../../data/db/app_database.dart';
import '../models/auth_user.dart';
import '../models/procurement_status.dart';
import '../models/role.dart';
import 'dashboard_rules.dart';
import 'notification_service.dart';
import '../workflow/transition_policy.dart';
import '../workflow/workflow_action.dart';
import '../workflow/state_machine.dart';

/// Applies workflow transitions with role, self-approval and department checks,
/// writing the audit row in the same database transaction.
///
/// Callers that also write other rows should call [apply] FIRST inside their own
/// `_db.transaction`, so a rejected transition rolls the whole operation back.
class WorkflowService {
  WorkflowService(this._db);
  final AppDatabase _db;
  static const _uuid = Uuid();

  Future<ProcurementStatus> apply({
    required String procurementId,
    required WorkflowAction action,
    required AuthUser actor,
    String? detail,
  }) async {
    return _db.transaction(() async {
      final row = await (_db.select(_db.procurements)
            ..where((p) => p.id.equals(procurementId)))
          .getSingleOrNull();
      if (row == null) {
        throw WorkflowException('Procurement not found.');
      }

      final from = ProcurementStatus.fromStorage(row.status);

      final to = TransitionPolicy.nextStatus(
        from: from,
        action: action,
        actor: actor,
        createdByUserId: row.createdByUserId,
        departmentId: row.departmentId,
      );

      await (_db.update(_db.procurements)..where((p) => p.id.equals(procurementId))).write(
        ProcurementsCompanion(
          status: Value(to.name),
          updatedAt: Value(DateTime.now().toUtc()),
        ),
      );

      await _db.into(_db.auditLogs).insert(AuditLogsCompanion.insert(
            id: _uuid.v4(),
            procurementId: Value(procurementId),
            actorUserId: Value(actor.id),
            actorName: actor.displayName,
            action: action.name,
            oldState: Value(from.name),
            newState: Value(to.name),
            detail: Value(detail),
            createdAt: DateTime.now().toUtc(),
          ));

      await _notify(row: row, to: to, actor: actor);

      return to;
    });
  }

  /// Tells whoever now has work to do (and the requester / vendor where relevant).
  Future<void> _notify({
    required Procurement row,
    required ProcurementStatus to,
    required AuthUser actor,
  }) async {
    final ids = <String>{};
    final users = await (_db.select(_db.users)..where((u) => u.isActive.equals(true))).get();
    for (final u in users) {
      if (u.id == actor.id) continue;
      final role = UserRole.fromStorage(u.role);
      if (role == UserRole.orgAdmin || role == UserRole.vendor || role == UserRole.pending) continue;
      if (!awaitingStatusesFor(role).contains(to)) continue;
      if (role == UserRole.departmentHead) {
        if (u.departmentId == row.departmentId) ids.add(u.id);
      } else if (role == UserRole.requestOfficer) {
        if (u.id == row.createdByUserId) ids.add(u.id);
      } else {
        ids.add(u.id);
      }
    }

    const tellRequester = {
      ProcurementStatus.changesRequested,
      ProcurementStatus.rejected,
      ProcurementStatus.rfqPublished,
      ProcurementStatus.awarded,
      ProcurementStatus.completed,
    };
    if (tellRequester.contains(to) && row.createdByUserId != actor.id) {
      ids.add(row.createdByUserId);
    }

    const tellVendor = {
      ProcurementStatus.poIssued,
      ProcurementStatus.goodsReceived,
      ProcurementStatus.paid,
    };
    final vendorProfileId = row.awardedVendorId;
    if (vendorProfileId != null && tellVendor.contains(to)) {
      final v = await (_db.select(_db.vendorProfiles)..where((x) => x.id.equals(vendorProfileId)))
          .getSingleOrNull();
      if (v != null && v.userId != actor.id) ids.add(v.userId);
    }

    if (ids.isEmpty) return;
    await NotificationService(_db).notifyUsers(
      ids,
      title: '${row.number} · ${to.label}',
      body: row.title,
      procurementId: row.id,
      kind: to.name,
    );
  }
}
