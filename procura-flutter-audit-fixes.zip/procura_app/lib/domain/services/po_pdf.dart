import 'dart:typed_data';

import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../../data/db/app_database.dart';

/// Builds a printable purchase-order PDF.
/// Uses plain ASCII ("NGN") because the built-in PDF fonts have no ₦ glyph.
class PoPdf {
  static String _ngn(int kobo) => 'NGN ${NumberFormat('#,##0.00').format(kobo / 100)}';

  static Future<Uint8List> build({
    required PurchaseOrder po,
    required Procurement procurement,
    required String vendorName,
  }) async {
    final doc = pw.Document();
    final unitPrice = procurement.quantity > 0 ? (po.totalKobo / procurement.quantity).round() : 0;
    final issued = DateFormat('d MMM yyyy').format(po.createdAt.toLocal());

    pw.Widget row(String k, String v) => pw.Padding(
          padding: const pw.EdgeInsets.only(bottom: 6),
          child: pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.SizedBox(width: 130, child: pw.Text(k, style: pw.TextStyle(fontWeight: pw.FontWeight.bold))),
              pw.Expanded(child: pw.Text(v)),
            ],
          ),
        );

    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(40),
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text('PURCHASE ORDER', style: pw.TextStyle(fontSize: 26, fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 4),
            pw.Text(po.number, style: const pw.TextStyle(fontSize: 14)),
            pw.Divider(),
            pw.SizedBox(height: 8),
            row('Issued', issued),
            row('Vendor', vendorName),
            row('Request', '${procurement.number} - ${procurement.title}'),
            row('Item', procurement.itemDescription),
            row('Quantity', '${procurement.quantity} ${procurement.unit}'),
            row('Unit price', _ngn(unitPrice)),
            row('Total', _ngn(po.totalKobo)),
            if (po.deliveryLocation != null) row('Deliver to', po.deliveryLocation!),
            pw.SizedBox(height: 16),
            pw.Text('Terms', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 4),
            pw.Text(
              po.terms ??
                  'Delivery must match the quantity and specification above. Late delivery may attract '
                      'contractual penalties, as acknowledged by the vendor when bidding. Payment is made '
                      'against an invoice that matches this order and the goods received.',
            ),
          ],
        ),
      ),
    );
    return doc.save();
  }
}
