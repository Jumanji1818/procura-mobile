import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';

import '../../data/db/app_database.dart';
import '../models/auth_user.dart';
import '../models/procurement_status.dart';
import '../models/role.dart';
import '../workflow/workflow_action.dart';
import 'bid_rules.dart';
import 'notification_service.dart';
import 'scoring_engine.dart';
import 'workflow_service.dart';

class BidService {
  BidService(this._db, this._workflow);
  final AppDatabase _db;
  final WorkflowService _workflow;
  static const _uuid = Uuid();

  Future<VendorProfile?> vendorProfileForUser(String userId) async {
    return (_db.select(_db.vendorProfiles)..where((v) => v.userId.equals(userId))).getSingleOrNull();
  }

  Future<Procurement?> getProcurement(String id) async {
    return (_db.select(_db.procurements)..where((p) => p.id.equals(id))).getSingleOrNull();
  }

  /// RFQs open for bidding (deadline not passed) that match the vendor's categories.
  Future<List<Procurement>> listOpenRfqForVendor(AuthUser actor) async {
    if (actor.role != UserRole.vendor) return [];
    final profile = await vendorProfileForUser(actor.id);
    if (profile == null) return [];

    final links = await (_db.select(_db.vendorCategories)
          ..where((c) => c.vendorId.equals(profile.id)))
        .get();
    final catIds = links.map((l) => l.categoryId).toSet();
    if (catIds.isEmpty) return [];

    final now = DateTime.now().toUtc();
    final open = await (_db.select(_db.procurements)
          ..where((p) => p.status.equals(ProcurementStatus.bidding.name)))
        .get();
    return open
        .where((p) =>
            catIds.contains(p.categoryId) &&
            (p.closingDate == null || p.closingDate!.isAfter(now)))
        .toList();
  }

  Future<bool> categoryMatches({required String vendorId, required String categoryId}) async {
    final row = await (_db.select(_db.vendorCategories)
          ..where((c) => c.vendorId.equals(vendorId) & c.categoryId.equals(categoryId)))
        .getSingleOrNull();
    return row != null;
  }

  /// Has this vendor user already bid on the RFQ?
  Future<bool> hasBid({required AuthUser actor, required String procurementId}) async {
    final profile = await vendorProfileForUser(actor.id);
    if (profile == null) return false;
    final row = await (_db.select(_db.bids)
          ..where((b) => b.procurementId.equals(procurementId) & b.vendorId.equals(profile.id)))
        .getSingleOrNull();
    return row != null;
  }

  /// Vendors only see COUNT of other bids — never prices (enforced here).
  Future<int> bidCount(String procurementId) async {
    final rows = await (_db.select(_db.bids)..where((b) => b.procurementId.equals(procurementId))).get();
    return rows.length;
  }

  /// Staff (procurement) see full bids.
  Future<List<Bid>> listBidsForStaff(String procurementId) async {
    return (_db.select(_db.bids)..where((b) => b.procurementId.equals(procurementId))).get();
  }

  Future<void> submitBid({
    required AuthUser actor,
    required String procurementId,
    required int unitPriceKobo,
    required int deliveryDays,
    required int validityDays,
    required bool lateDeliveryAcknowledged,
    bool complianceComplete = true,
    String? notes,
  }) async {
    if (actor.role != UserRole.vendor) {
      throw BidValidationException('Only vendors can submit bids.');
    }
    if (validityDays <= 0) {
      throw BidValidationException('Validity must be at least 1 day.');
    }
    final profile = await vendorProfileForUser(actor.id);
    if (profile == null) {
      throw BidValidationException('Vendor profile not found.');
    }

    final proc = await getProcurement(procurementId);
    if (proc == null) throw BidValidationException('RFQ not found.');
    if (proc.status != ProcurementStatus.bidding.name) {
      throw BidValidationException('This RFQ is not open for bidding.');
    }

    final match = await categoryMatches(vendorId: profile.id, categoryId: proc.categoryId);
    final existing = await (_db.select(_db.bids)
          ..where((b) => b.procurementId.equals(procurementId) & b.vendorId.equals(profile.id)))
        .getSingleOrNull();

    BidRules.validateSubmission(
      closingDate: proc.closingDate,
      now: DateTime.now().toUtc(),
      unitPriceKobo: unitPriceKobo,
      deliveryDays: deliveryDays,
      lateDeliveryAcknowledged: lateDeliveryAcknowledged,
      categoryMatches: match,
      alreadyBid: existing != null,
    );

    final total = unitPriceKobo * proc.quantity;
    final now = DateTime.now().toUtc();

    await _db.transaction(() async {
      await _db.into(_db.bids).insert(BidsCompanion.insert(
            id: _uuid.v4(),
            procurementId: procurementId,
            vendorId: profile.id,
            unitPriceKobo: unitPriceKobo,
            totalPriceKobo: total,
            deliveryDays: deliveryDays,
            validityDays: validityDays,
            notes: Value(notes),
            complianceComplete: Value(complianceComplete),
            lateDeliveryAcknowledged: const Value(true),
            locked: const Value(true),
            createdAt: now,
          ));
      await _db.into(_db.auditLogs).insert(AuditLogsCompanion.insert(
            id: _uuid.v4(),
            procurementId: Value(procurementId),
            actorUserId: Value(actor.id),
            actorName: actor.displayName,
            action: 'submit_bid',
            detail: Value('unit=$unitPriceKobo days=$deliveryDays'),
            createdAt: now,
          ));
    });
  }

  Future<void> publishRfq({
    required AuthUser actor,
    required String procurementId,
    required DateTime closingDate,
  }) async {
    final proc = await getProcurement(procurementId);
    if (proc == null) throw BidValidationException('Request not found.');
    if (proc.status != ProcurementStatus.rfqPublished.name) {
      throw BidValidationException('Request must be approved (RFQ published) before opening bids.');
    }
    if (!closingDate.isAfter(DateTime.now().toUtc())) {
      throw BidValidationException('Closing date must be in the future.');
    }
    // Workflow check first: a rejected caller must not leave a closing date behind.
    await _db.transaction(() async {
      await _workflow.apply(
        procurementId: procurementId,
        action: WorkflowAction.publishRfq,
        actor: actor,
        detail: 'closes ${closingDate.toIso8601String()}',
      );
      await (_db.update(_db.procurements)..where((p) => p.id.equals(procurementId))).write(
        ProcurementsCompanion(closingDate: Value(closingDate)),
      );

      // Tell vendors that supply this category.
      final links = await (_db.select(_db.vendorCategories)
            ..where((c) => c.categoryId.equals(proc.categoryId)))
          .get();
      final userIds = <String>{};
      for (final l in links) {
        final v = await (_db.select(_db.vendorProfiles)..where((x) => x.id.equals(l.vendorId)))
            .getSingleOrNull();
        if (v != null) userIds.add(v.userId);
      }
      await NotificationService(_db).notifyUsers(
        userIds,
        title: 'New RFQ: ${proc.title}',
        body: '${proc.number} is open for bidding.',
        procurementId: procurementId,
        kind: 'rfq',
      );
    });
  }

  Future<void> openEvaluation({
    required AuthUser actor,
    required String procurementId,
  }) async {
    if (await bidCount(procurementId) == 0) {
      throw BidValidationException('No bids received yet — nothing to evaluate.');
    }
    await _workflow.apply(
      procurementId: procurementId,
      action: WorkflowAction.openEvaluation,
      actor: actor,
    );
  }

  Future<void> saveRecommendation({
    required AuthUser actor,
    required String procurementId,
    required String vendorId,
    required String reason,
  }) async {
    if (actor.role != UserRole.procurementOfficer && actor.role != UserRole.orgAdmin) {
      throw BidValidationException('Only procurement can save a recommendation.');
    }
    final proc = await getProcurement(procurementId);
    if (proc == null) throw BidValidationException('Request not found.');
    if (proc.status != ProcurementStatus.evaluating.name) {
      throw BidValidationException('Recommendations can only be saved while evaluating.');
    }
    final bid = await (_db.select(_db.bids)
          ..where((b) => b.procurementId.equals(procurementId) & b.vendorId.equals(vendorId)))
        .getSingleOrNull();
    if (bid == null) {
      throw BidValidationException('That vendor has not bid on this RFQ.');
    }
    final now = DateTime.now().toUtc();
    await _db.transaction(() async {
      await (_db.update(_db.procurements)..where((p) => p.id.equals(procurementId))).write(
        ProcurementsCompanion(
          recommendedVendorId: Value(vendorId),
          recommendationReason: Value(reason),
          updatedAt: Value(now),
        ),
      );
      await _db.into(_db.auditLogs).insert(AuditLogsCompanion.insert(
            id: _uuid.v4(),
            procurementId: Value(procurementId),
            actorUserId: Value(actor.id),
            actorName: actor.displayName,
            action: 'recommend_vendor',
            detail: Value(reason),
            createdAt: now,
          ));
    });
  }

  /// Build score inputs from DB rows for a procurement.
  Future<List<BidScoreInput>> scoreInputs(String procurementId) async {
    final bids = await listBidsForStaff(procurementId);
    final out = <BidScoreInput>[];
    for (final b in bids) {
      final v = await (_db.select(_db.vendorProfiles)..where((x) => x.id.equals(b.vendorId))).getSingleOrNull();
      if (v == null) continue;
      out.add(BidScoreInput(
        vendorId: v.id,
        vendorName: v.businessName,
        unitPriceKobo: b.unitPriceKobo,
        deliveryDays: b.deliveryDays,
        onTimeRate: v.onTimeRate,
        rating: v.rating,
        complianceComplete: b.complianceComplete,
        hasHistory: v.completedOrders > 0,
      ));
    }
    return out;
  }

  /// Weights saved by an Org Admin, or the built-in defaults.
  Future<ScoringWeights> loadWeights() async {
    final row = await (_db.select(_db.scoringWeights)..where((w) => w.id.equals('default')))
        .getSingleOrNull();
    if (row == null) return const ScoringWeights();
    final w = ScoringWeights(
      price: row.priceWeight,
      delivery: row.deliveryWeight,
      onTime: row.onTimeWeight,
      rating: row.ratingWeight,
      compliance: row.complianceWeight,
    );
    return w.isValid ? w : const ScoringWeights();
  }
}
