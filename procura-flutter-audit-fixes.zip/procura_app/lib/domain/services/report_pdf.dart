import 'dart:typed_data';

import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import 'reports_service.dart';

/// One-page procurement summary. ASCII only ("NGN") for the built-in PDF fonts.
class ReportPdf {
  static String _ngn(double naira) => 'NGN ${NumberFormat('#,##0').format(naira)}';

  static Future<Uint8List> build({
    required List<CategorySpend> byCategory,
    required List<SpendPoint> trend,
    required double? forecastNaira,
    required Map<String, int> statusCounts,
  }) async {
    final doc = pw.Document();
    final generated = DateFormat('d MMM yyyy, HH:mm').format(DateTime.now());

    pw.Widget heading(String t) => pw.Padding(
          padding: const pw.EdgeInsets.only(top: 14, bottom: 6),
          child: pw.Text(t, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 14)),
        );

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(40),
        build: (context) => [
          pw.Text('PROCUREMENT REPORT', style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
          pw.Text('Generated $generated'),
          pw.Divider(),
          heading('Spend by category (paid)'),
          if (byCategory.isEmpty) pw.Text('No payments yet.'),
          for (final c in byCategory) pw.Text('${c.category}: ${_ngn(c.amountNaira)}'),
          heading('Monthly spend'),
          if (trend.isEmpty) pw.Text('No payments yet.'),
          for (final t in trend) pw.Text('${t.label}: ${_ngn(t.amountNaira)}'),
          heading('Next-month estimate'),
          pw.Text(forecastNaira == null
              ? 'Insufficient history.'
              : '${_ngn(forecastNaira)} (3-month moving average; an estimate only)'),
          heading('Requests by status'),
          if (statusCounts.isEmpty) pw.Text('No requests yet.'),
          for (final e in statusCounts.entries) pw.Text('${e.key}: ${e.value}'),
        ],
      ),
    );
    return doc.save();
  }
}
