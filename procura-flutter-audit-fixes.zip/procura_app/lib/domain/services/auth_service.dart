import 'package:bcrypt/bcrypt.dart';
import 'package:drift/drift.dart';
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../../data/db/app_database.dart';
import '../models/role.dart';
import '../models/auth_user.dart';
import 'auth_gateway.dart';
import 'lockout_policy.dart';

class AuthException implements Exception {
  final String message;
  AuthException(this.message);
  @override
  String toString() => message;
}

/// Runs bcrypt hash off the UI isolate.
String _hashPasswordIsolate(String password) {
  return BCrypt.hashpw(password, BCrypt.gensalt());
}

/// Runs bcrypt verify off the UI isolate. Args: [password, hash].
bool _checkPasswordIsolate(List<String> args) {
  return BCrypt.checkpw(args[0], args[1]);
}

/// Local offline auth: salted bcrypt hashes, lockout, real accounts only.
class AuthService implements AuthGateway {
  AuthService(this._db);

  final AppDatabase _db;
  static const _uuid = Uuid();
  static const minPasswordLength = 8;
  static const maxFailedAttempts = 5;
  static const lockoutMinutes = 15;

  /// Session is owned by [SessionNotifier]; keep a mirror for non-UI callers.
  AuthUser? _current;
  AuthUser? get currentUser => _current;

  Future<AuthUser> register({
    required String email,
    required String displayName,
    required String password,
    required bool asVendor,
    List<String> categoryIds = const [],
    String? businessName,
    String? location,
  }) async {
    final normalized = email.trim().toLowerCase();
    if (normalized.isEmpty || !normalized.contains('@')) {
      throw AuthException('Enter a valid email address.');
    }
    if (password.length < minPasswordLength) {
      throw AuthException('Password must be at least $minPasswordLength characters.');
    }
    if (displayName.trim().length < 2) {
      throw AuthException('Enter your full name.');
    }
    if (asVendor) {
      if (categoryIds.isEmpty || categoryIds.length > 3) {
        throw AuthException('Vendors must select 1–3 categories.');
      }
      for (final catId in categoryIds) {
        final cat = await (_db.select(_db.categories)..where((c) => c.id.equals(catId))).getSingleOrNull();
        if (cat == null) {
          throw AuthException('Invalid category selection.');
        }
      }
    }

    final existing =
        await (_db.select(_db.users)..where((u) => u.email.equals(normalized))).getSingleOrNull();
    if (existing != null) {
      throw AuthException('An account with this email already exists.');
    }

    final hash = await compute(_hashPasswordIsolate, password);
    final id = _uuid.v4();
    final role = asVendor ? UserRole.vendor : UserRole.pending;
    final now = DateTime.now().toUtc();

    await _db.transaction(() async {
      await _db.into(_db.users).insert(UsersCompanion.insert(
            id: id,
            email: normalized,
            displayName: displayName.trim(),
            passwordHash: hash,
            role: role.name,
            createdAt: now,
          ));
      if (asVendor) {
        final vendorId = _uuid.v4();
        await _db.into(_db.vendorProfiles).insert(VendorProfilesCompanion.insert(
              id: vendorId,
              userId: id,
              businessName: (businessName ?? displayName).trim(),
              location: Value(location),
            ));
        for (final catId in categoryIds.take(3)) {
          await _db.into(_db.vendorCategories).insert(VendorCategoriesCompanion.insert(
                id: _uuid.v4(),
                vendorId: vendorId,
                categoryId: catId,
              ));
        }
      }
    });

    return login(email: normalized, password: password);
  }

  Future<AuthUser> login({required String email, required String password}) async {
    final normalized = email.trim().toLowerCase();
    final row =
        await (_db.select(_db.users)..where((u) => u.email.equals(normalized))).getSingleOrNull();
    if (row == null) {
      throw AuthException('Invalid email or password.');
    }
    final now = DateTime.now().toUtc();
    // Clear expired lockout and reset failure counter so one mistake does not re-lock.
    if (LockoutPolicy.shouldClearLockout(row.lockedUntil, now)) {
      await (_db.update(_db.users)..where((u) => u.id.equals(row.id))).write(
        const UsersCompanion(failedLogins: Value(0), lockedUntil: Value(null)),
      );
    } else if (row.lockedUntil != null && row.lockedUntil!.isAfter(now)) {
      throw AuthException('Account temporarily locked after failed attempts. Try again later.');
    }

    // Re-read after possible lockout clear
    final fresh =
        await (_db.select(_db.users)..where((u) => u.id.equals(row.id))).getSingle();

    final ok = await compute(_checkPasswordIsolate, [password, fresh.passwordHash]);
    if (!ok) {
      final fails = fresh.failedLogins + 1;
      await (_db.update(_db.users)..where((u) => u.id.equals(fresh.id))).write(
        UsersCompanion(
          failedLogins: Value(fails),
          lockedUntil: Value(LockoutPolicy.nextLockUntil(fails, now)),
        ),
      );
      throw AuthException('Invalid email or password.');
    }

    await (_db.update(_db.users)..where((u) => u.id.equals(fresh.id))).write(
      const UsersCompanion(failedLogins: Value(0), lockedUntil: Value(null)),
    );

    // Only someone who knows the password learns the account is disabled.
    if (!fresh.isActive) {
      throw AuthException('This account is disabled. Contact an administrator.');
    }

    final user = AuthUser(
      id: fresh.id,
      email: fresh.email,
      displayName: fresh.displayName,
      role: UserRole.fromStorage(fresh.role),
      departmentId: fresh.departmentId,
    );
    _current = user;
    return user;
  }

  void logout() {
    _current = null;
  }

  /// Used by SessionNotifier after login/logout.
  void setSession(AuthUser? user) => _current = user;

  Future<void> assignRole({
    required String actorUserId,
    required String targetUserId,
    required UserRole role,
    String? departmentId,
    bool clearDepartment = false, // ignore: avoid_positional
  }) async {
    final actor = await (_db.select(_db.users)..where((u) => u.id.equals(actorUserId))).getSingle();
    if (UserRole.fromStorage(actor.role) != UserRole.orgAdmin) {
      throw AuthException('Only Org Admin can assign roles.');
    }
    if (role == UserRole.pending) {
      throw AuthException('Assign a concrete role, not pending.');
    }
    if (role == UserRole.vendor) {
      throw AuthException(
        'Cannot assign Vendor role to staff. Vendors register separately with a vendor profile.',
      );
    }

    final target =
        await (_db.select(_db.users)..where((u) => u.id.equals(targetUserId))).getSingleOrNull();
    if (target == null) {
      throw AuthException('User not found.');
    }

    // Do not convert vendor accounts into staff (orphans vendor profile).
    if (UserRole.fromStorage(target.role) == UserRole.vendor) {
      throw AuthException(
        'Cannot assign a staff role to a vendor account. Vendors keep the Vendor role.',
      );
    }

    if (role == UserRole.departmentHead || role == UserRole.requestOfficer) {
      final dept = clearDepartment ? null : (departmentId ?? target.departmentId);
      if (dept == null || dept.isEmpty) {
        throw AuthException('${role.label} requires a department.');
      }
      final d = await (_db.select(_db.departments)..where((x) => x.id.equals(dept))).getSingleOrNull();
      if (d == null) {
        throw AuthException('Department does not exist.');
      }
    } else if (departmentId != null) {
      final d = await (_db.select(_db.departments)..where((x) => x.id.equals(departmentId))).getSingleOrNull();
      if (d == null) {
        throw AuthException('Department does not exist.');
      }
    }

    // Block demoting the last Org Admin.
    if (UserRole.fromStorage(target.role) == UserRole.orgAdmin && role != UserRole.orgAdmin) {
      final admins = await (_db.select(_db.users)
            ..where((u) => u.role.equals(UserRole.orgAdmin.name) & u.isActive.equals(true)))
          .get();
      if (admins.length <= 1) {
        throw AuthException('Cannot demote the last Org Admin.');
      }
    }

    // Keep existing department when not supplied (unless explicitly cleared).
    final nextDept = clearDepartment
        ? null
        : (departmentId ?? target.departmentId);

    await (_db.update(_db.users)..where((u) => u.id.equals(targetUserId))).write(
      UsersCompanion(
        role: Value(role.name),
        departmentId: Value(nextDept),
      ),
    );
  }

  /// Enable or disable a staff account (Org Admin only).
  Future<void> setActive({
    required String actorUserId,
    required String targetUserId,
    required bool active,
  }) async {
    final actor = await (_db.select(_db.users)..where((u) => u.id.equals(actorUserId))).getSingle();
    if (UserRole.fromStorage(actor.role) != UserRole.orgAdmin) {
      throw AuthException('Only Org Admin can enable or disable accounts.');
    }
    if (actorUserId == targetUserId && !active) {
      throw AuthException('You cannot disable your own account.');
    }
    final target =
        await (_db.select(_db.users)..where((u) => u.id.equals(targetUserId))).getSingleOrNull();
    if (target == null) throw AuthException('User not found.');

    if (!active && UserRole.fromStorage(target.role) == UserRole.orgAdmin) {
      final admins = await (_db.select(_db.users)
            ..where((u) => u.role.equals(UserRole.orgAdmin.name) & u.isActive.equals(true)))
          .get();
      if (admins.length <= 1) {
        throw AuthException('Cannot disable the last Org Admin.');
      }
    }
    await (_db.update(_db.users)..where((u) => u.id.equals(targetUserId))).write(
      UsersCompanion(isActive: Value(active)),
    );
  }
}
