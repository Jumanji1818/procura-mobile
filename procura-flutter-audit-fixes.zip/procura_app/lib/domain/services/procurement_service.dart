import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';

import '../../data/db/app_database.dart';
import '../models/auth_user.dart';
import '../models/procurement_status.dart';
import '../models/role.dart';
import '../workflow/workflow_action.dart';
import 'workflow_service.dart';

class ProcurementException implements Exception {
  final String message;
  ProcurementException(this.message);
  @override
  String toString() => message;
}

/// Create/edit requests and drive department approval via WorkflowService.
class ProcurementService {
  ProcurementService(this._db, this._workflow);
  final AppDatabase _db;
  final WorkflowService _workflow;
  static const _uuid = Uuid();

  static void _validateFields({
    required String title,
    required String itemDescription,
    required int quantity,
    required String unit,
    int? budgetKobo,
  }) {
    if (title.trim().length < 3) {
      throw ProcurementException('Title must be at least 3 characters.');
    }
    if (itemDescription.trim().length < 5) {
      throw ProcurementException('Describe the item in more detail.');
    }
    if (quantity <= 0) {
      throw ProcurementException('Quantity must be greater than zero.');
    }
    if (unit.trim().isEmpty) {
      throw ProcurementException('Unit is required.');
    }
    if (budgetKobo != null && budgetKobo < 0) {
      throw ProcurementException('Budget cannot be negative.');
    }
  }

  static String? _blankToNull(String? v) {
    final t = v?.trim();
    return (t == null || t.isEmpty) ? null : t;
  }

  Future<String> createRequest({
    required AuthUser actor,
    required String title,
    required String itemDescription,
    required String categoryId,
    required String departmentId,
    required int quantity,
    required String unit,
    int? budgetKobo,
    String? deliveryLocation,
    DateTime? requiredDate,
  }) async {
    // Org Admin administers the system; it is not a requester (it cannot submit
    // for approval under the separation-of-duties rules).
    if (actor.role != UserRole.requestOfficer && actor.role != UserRole.procurementOfficer) {
      throw ProcurementException('Only request or procurement officers can create requests.');
    }
    _validateFields(
      title: title,
      itemDescription: itemDescription,
      quantity: quantity,
      unit: unit,
      budgetKobo: budgetKobo,
    );

    final cat = await (_db.select(_db.categories)..where((c) => c.id.equals(categoryId))).getSingleOrNull();
    if (cat == null) throw ProcurementException('Invalid category.');

    final dept = await (_db.select(_db.departments)..where((d) => d.id.equals(departmentId))).getSingleOrNull();
    if (dept == null) throw ProcurementException('Invalid department.');

    // Request officers may only create for their own department.
    if (actor.role == UserRole.requestOfficer) {
      if (actor.departmentId == null || actor.departmentId != departmentId) {
        throw ProcurementException('You can only create requests for your own department.');
      }
    }

    final now = DateTime.now().toUtc();
    final id = _uuid.v4();

    await _db.transaction(() async {
      final number = await _db.nextDocumentNumber('REQ');
      await _db.into(_db.procurements).insert(ProcurementsCompanion.insert(
            id: id,
            number: number,
            title: title.trim(),
            itemDescription: itemDescription.trim(),
            categoryId: categoryId,
            departmentId: departmentId,
            createdByUserId: actor.id,
            quantity: quantity,
            unit: unit.trim(),
            budgetKobo: Value(budgetKobo),
            deliveryLocation: Value(_blankToNull(deliveryLocation)),
            requiredDate: Value(requiredDate),
            status: ProcurementStatus.draft.name,
            createdAt: now,
            updatedAt: now,
          ));
      await _db.into(_db.auditLogs).insert(AuditLogsCompanion.insert(
            id: _uuid.v4(),
            procurementId: Value(id),
            actorUserId: Value(actor.id),
            actorName: actor.displayName,
            action: 'create',
            oldState: const Value(null),
            newState: Value(ProcurementStatus.draft.name),
            createdAt: now,
          ));
    });
    return id;
  }

  /// Creator edits a draft, or a request the department head sent back.
  Future<void> updateRequest({
    required AuthUser actor,
    required String procurementId,
    required String title,
    required String itemDescription,
    required String categoryId,
    required int quantity,
    required String unit,
    int? budgetKobo,
    String? deliveryLocation,
  }) async {
    final row = await getById(procurementId);
    if (row == null) throw ProcurementException('Request not found.');
    if (row.createdByUserId != actor.id) {
      throw ProcurementException('Only the person who created this request can edit it.');
    }
    final st = ProcurementStatus.fromStorage(row.status);
    if (st != ProcurementStatus.draft && st != ProcurementStatus.changesRequested) {
      throw ProcurementException('This request can no longer be edited.');
    }
    _validateFields(
      title: title,
      itemDescription: itemDescription,
      quantity: quantity,
      unit: unit,
      budgetKobo: budgetKobo,
    );
    final cat = await (_db.select(_db.categories)..where((c) => c.id.equals(categoryId))).getSingleOrNull();
    if (cat == null) throw ProcurementException('Invalid category.');

    final now = DateTime.now().toUtc();
    await _db.transaction(() async {
      await (_db.update(_db.procurements)..where((p) => p.id.equals(procurementId))).write(
        ProcurementsCompanion(
          title: Value(title.trim()),
          itemDescription: Value(itemDescription.trim()),
          categoryId: Value(categoryId),
          quantity: Value(quantity),
          unit: Value(unit.trim()),
          budgetKobo: Value(budgetKobo),
          deliveryLocation: Value(_blankToNull(deliveryLocation)),
          updatedAt: Value(now),
        ),
      );
      await _db.into(_db.auditLogs).insert(AuditLogsCompanion.insert(
            id: _uuid.v4(),
            procurementId: Value(procurementId),
            actorUserId: Value(actor.id),
            actorName: actor.displayName,
            action: 'edit',
            oldState: Value(st.name),
            newState: Value(st.name),
            createdAt: now,
          ));
    });
  }

  Future<void> submitForApproval({
    required String procurementId,
    required AuthUser actor,
  }) async {
    await _workflow.apply(
      procurementId: procurementId,
      action: WorkflowAction.submitForApproval,
      actor: actor,
    );
  }

  Future<void> approveDepartment({
    required String procurementId,
    required AuthUser actor,
  }) async {
    await _workflow.apply(
      procurementId: procurementId,
      action: WorkflowAction.approveDepartment,
      actor: actor,
    );
  }

  static String _requireNote(String? note, String what) {
    final t = note?.trim() ?? '';
    if (t.length < 3) {
      throw ProcurementException('Please explain $what (at least 3 characters).');
    }
    return t;
  }

  Future<void> requestChanges({
    required String procurementId,
    required AuthUser actor,
    required String note,
  }) async {
    final reason = _requireNote(note, 'what needs to change');
    await _workflow.apply(
      procurementId: procurementId,
      action: WorkflowAction.requestChanges,
      actor: actor,
      detail: reason,
    );
  }

  Future<void> reject({
    required String procurementId,
    required AuthUser actor,
    required String note,
  }) async {
    final reason = _requireNote(note, 'why it is rejected');
    await _workflow.apply(
      procurementId: procurementId,
      action: WorkflowAction.reject,
      actor: actor,
      detail: reason,
    );
  }

  /// Lists procurements visible to the actor.
  Future<List<Procurement>> listFor(AuthUser actor) async {
    final q = _db.select(_db.procurements)..orderBy([(t) => OrderingTerm.desc(t.updatedAt)]);
    final all = await q.get();

    if (actor.role == UserRole.orgAdmin ||
        actor.role == UserRole.procurementOfficer ||
        actor.role == UserRole.approvingAuthority ||
        actor.role == UserRole.financeOfficer) {
      return all;
    }
    if (actor.role == UserRole.departmentHead) {
      return all.where((p) => p.departmentId == actor.departmentId).toList();
    }
    if (actor.role == UserRole.requestOfficer) {
      return all
          .where((p) => p.createdByUserId == actor.id || p.departmentId == actor.departmentId)
          .toList();
    }
    // Vendors see nothing at request stage
    return [];
  }

  Future<Procurement?> getById(String id) async {
    return (_db.select(_db.procurements)..where((p) => p.id.equals(id))).getSingleOrNull();
  }

  /// Audit trail for one procurement, oldest first.
  Future<List<AuditLog>> history(String procurementId) async {
    return (_db.select(_db.auditLogs)
          ..where((a) => a.procurementId.equals(procurementId))
          ..orderBy([(a) => OrderingTerm.asc(a.createdAt)]))
        .get();
  }
}
