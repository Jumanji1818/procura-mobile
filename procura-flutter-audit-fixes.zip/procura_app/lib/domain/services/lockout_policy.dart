/// Lockout helpers used by [AuthService].
class LockoutPolicy {
  static const maxFailedAttempts = 5;
  static const lockoutMinutes = 15;

  /// Whether an expired lock should be cleared (and failures reset).
  static bool shouldClearLockout(DateTime? lockedUntil, DateTime now) {
    if (lockedUntil == null) return false;
    return !lockedUntil.isAfter(now);
  }

  static DateTime? nextLockUntil(int failedLogins, DateTime now) {
    if (failedLogins >= maxFailedAttempts) {
      return now.add(const Duration(minutes: lockoutMinutes));
    }
    return null;
  }
}
