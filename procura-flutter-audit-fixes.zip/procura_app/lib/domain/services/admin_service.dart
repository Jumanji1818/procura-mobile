import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';

import '../../data/db/app_database.dart';
import '../models/auth_user.dart';
import '../models/role.dart';
import 'scoring_engine.dart';

class AdminException implements Exception {
  final String message;
  AdminException(this.message);
  @override
  String toString() => message;
}

/// Org Admin maintenance: departments, categories, category budgets, scoring weights.
class AdminService {
  AdminService(this._db);
  final AppDatabase _db;
  static const _uuid = Uuid();

  void _requireAdmin(AuthUser actor) {
    if (actor.role != UserRole.orgAdmin) {
      throw AdminException('Only Org Admin can change organisation settings.');
    }
  }

  Future<void> addDepartment({
    required AuthUser actor,
    required String name,
    required String code,
  }) async {
    _requireAdmin(actor);
    final n = name.trim();
    final c = code.trim().toUpperCase();
    if (n.length < 2) throw AdminException('Department name is too short.');
    if (c.length < 2 || c.length > 8) {
      throw AdminException('Department code must be 2–8 characters.');
    }
    final clash = await (_db.select(_db.departments)
          ..where((d) => d.code.equals(c) | d.name.equals(n)))
        .get();
    if (clash.isNotEmpty) throw AdminException('A department with that name or code already exists.');
    await _db.into(_db.departments).insert(
          DepartmentsCompanion.insert(id: _uuid.v4(), name: n, code: c),
        );
  }

  Future<void> addCategory({
    required AuthUser actor,
    required String parentName,
    required String subcategory,
  }) async {
    _requireAdmin(actor);
    final p = parentName.trim();
    final s = subcategory.trim();
    if (p.length < 2 || s.length < 2) {
      throw AdminException('Enter both a category and a subcategory.');
    }
    final clash = await (_db.select(_db.categories)
          ..where((c) => c.parentName.equals(p) & c.subcategory.equals(s)))
        .get();
    if (clash.isNotEmpty) throw AdminException('That category already exists.');
    await _db.into(_db.categories).insert(
          CategoriesCompanion.insert(id: _uuid.v4(), parentName: p, subcategory: s),
        );
  }

  /// Sets this year's budget for a category. Cannot go below what is already spent.
  Future<void> setCategoryBudget({
    required AuthUser actor,
    required String categoryId,
    required int amountKobo,
  }) async {
    _requireAdmin(actor);
    if (amountKobo < 0) throw AdminException('Budget cannot be negative.');
    final year = DateTime.now().year;
    final row = await (_db.select(_db.categoryBudgets)
          ..where((b) => b.categoryId.equals(categoryId) & b.year.equals(year)))
        .getSingleOrNull();
    if (row == null) {
      await _db.into(_db.categoryBudgets).insert(CategoryBudgetsCompanion.insert(
            id: _uuid.v4(),
            categoryId: categoryId,
            year: year,
            amountKobo: amountKobo,
          ));
      return;
    }
    if (amountKobo < row.spentKobo) {
      throw AdminException('Budget cannot be lower than the amount already spent.');
    }
    await (_db.update(_db.categoryBudgets)..where((b) => b.id.equals(row.id))).write(
      CategoryBudgetsCompanion(amountKobo: Value(amountKobo)),
    );
  }

  Future<List<CategoryBudget>> budgetsForYear([int? year]) {
    final y = year ?? DateTime.now().year;
    return (_db.select(_db.categoryBudgets)..where((b) => b.year.equals(y))).get();
  }

  Future<void> saveWeights({
    required AuthUser actor,
    required ScoringWeights weights,
  }) async {
    _requireAdmin(actor);
    if (!weights.isValid) {
      throw AdminException('Weights must be zero or more, and at least one must be above zero.');
    }
    final now = DateTime.now().toUtc();
    final existing = await (_db.select(_db.scoringWeights)..where((w) => w.id.equals('default')))
        .getSingleOrNull();
    if (existing == null) {
      await _db.into(_db.scoringWeights).insert(ScoringWeightsCompanion.insert(
            id: 'default',
            priceWeight: weights.price,
            deliveryWeight: weights.delivery,
            onTimeWeight: weights.onTime,
            ratingWeight: weights.rating,
            complianceWeight: weights.compliance,
            updatedByUserId: Value(actor.id),
            updatedAt: now,
          ));
      return;
    }
    await (_db.update(_db.scoringWeights)..where((w) => w.id.equals('default'))).write(
      ScoringWeightsCompanion(
        priceWeight: Value(weights.price),
        deliveryWeight: Value(weights.delivery),
        onTimeWeight: Value(weights.onTime),
        ratingWeight: Value(weights.rating),
        complianceWeight: Value(weights.compliance),
        updatedByUserId: Value(actor.id),
        updatedAt: Value(now),
      ),
    );
  }
}
