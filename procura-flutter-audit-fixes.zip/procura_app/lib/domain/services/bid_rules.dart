class BidValidationException implements Exception {
  final String message;
  BidValidationException(this.message);
  @override
  String toString() => message;
}

/// Pure bid submission rules — enforced before any DB write.
class BidRules {
  static void validateSubmission({
    required DateTime? closingDate,
    required DateTime now,
    required int unitPriceKobo,
    required int deliveryDays,
    required bool lateDeliveryAcknowledged,
    required bool categoryMatches,
    required bool alreadyBid,
  }) {
    if (!categoryMatches) {
      throw BidValidationException('Your registered categories do not match this RFQ.');
    }
    if (closingDate != null && !now.isBefore(closingDate)) {
      throw BidValidationException('The bidding deadline has passed.');
    }
    if (unitPriceKobo <= 0) {
      throw BidValidationException('Unit price must be greater than zero.');
    }
    if (deliveryDays <= 0) {
      throw BidValidationException('Delivery days must be greater than zero.');
    }
    if (!lateDeliveryAcknowledged) {
      throw BidValidationException(
        'You must acknowledge late-delivery / legal terms to submit a bid.',
      );
    }
    if (alreadyBid) {
      throw BidValidationException('You have already submitted a bid for this RFQ.');
    }
  }
}
