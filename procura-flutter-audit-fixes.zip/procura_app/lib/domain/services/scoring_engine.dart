import 'dart:math' as math;

/// Adjustable weights (Procurement Officer can change defaults in settings later).
class ScoringWeights {
  final double price;
  final double delivery;
  final double onTime;
  final double rating;
  final double compliance;

  const ScoringWeights({
    this.price = 0.35,
    this.delivery = 0.20,
    this.onTime = 0.20,
    this.rating = 0.15,
    this.compliance = 0.10,
  });

  double get sum => price + delivery + onTime + rating + compliance;

  /// True when every weight is non-negative and at least one is positive.
  bool get isValid =>
      price >= 0 && delivery >= 0 && onTime >= 0 && rating >= 0 && compliance >= 0 && sum > 0;
}

class BidScoreInput {
  final String vendorId;
  final String vendorName;
  final int unitPriceKobo;
  final int deliveryDays;
  final double onTimeRate; // 0–100
  final double rating; // 0–5
  final bool complianceComplete;

  /// False for vendors with no completed orders: their reliability numbers are
  /// placeholders, so they get a neutral score instead of a misleading 0 or 100.
  final bool hasHistory;

  const BidScoreInput({
    required this.vendorId,
    required this.vendorName,
    required this.unitPriceKobo,
    required this.deliveryDays,
    required this.onTimeRate,
    required this.rating,
    required this.complianceComplete,
    this.hasHistory = true,
  });
}

class BidScoreResult {
  final String vendorId;
  final String vendorName;
  final double total; // 0–100
  final double priceScore;
  final double deliveryScore;
  final double onTimeScore;
  final double ratingScore;
  final double complianceScore;
  final String explanation;

  const BidScoreResult({
    required this.vendorId,
    required this.vendorName,
    required this.total,
    required this.priceScore,
    required this.deliveryScore,
    required this.onTimeScore,
    required this.ratingScore,
    required this.complianceScore,
    required this.explanation,
  });
}

class PriceAnomaly {
  final String vendorId;
  final String vendorName;
  final String kind; // low | high
  final String explanation;

  const PriceAnomaly({
    required this.vendorId,
    required this.vendorName,
    required this.kind,
    required this.explanation,
  });
}

/// Offline smart scoring — plain weighted algorithms, explanations from numbers.
class ScoringEngine {
  /// Score given to reliability/rating for vendors with no track record yet.
  static const double neutralHistoryScore = 50;

  /// Rank bids. Lowest price and shorter delivery score higher.
  static List<BidScoreResult> rank(
    List<BidScoreInput> bids, {
    ScoringWeights weights = const ScoringWeights(),
  }) {
    if (bids.isEmpty) return [];

    final prices = bids.map((b) => b.unitPriceKobo.toDouble()).toList();
    final days = bids.map((b) => b.deliveryDays.toDouble()).toList();
    final minP = prices.reduce(math.min);
    final maxP = prices.reduce(math.max);
    final minD = days.reduce(math.min);
    final maxD = days.reduce(math.max);

    double normLowBest(double v, double min, double max) {
      if (max <= min) return 100;
      return 100 * (max - v) / (max - min);
    }

    final w = weights.sum <= 0 ? const ScoringWeights() : weights;
    final results = <BidScoreResult>[];

    for (final b in bids) {
      final priceScore = normLowBest(b.unitPriceKobo.toDouble(), minP, maxP);
      final deliveryScore = normLowBest(b.deliveryDays.toDouble(), minD, maxD);
      final onTimeScore = b.hasHistory ? b.onTimeRate.clamp(0, 100).toDouble() : neutralHistoryScore;
      final ratingScore =
          b.hasHistory ? (b.rating / 5.0 * 100).clamp(0, 100).toDouble() : neutralHistoryScore;
      final complianceScore = b.complianceComplete ? 100.0 : 40.0;

      final total = (priceScore * w.price +
              deliveryScore * w.delivery +
              onTimeScore * w.onTime +
              ratingScore * w.rating +
              complianceScore * w.compliance) /
          w.sum;

      final explanation = _explain(
        b: b,
        priceScore: priceScore,
        deliveryScore: deliveryScore,
        onTimeScore: onTimeScore,
        ratingScore: ratingScore,
        complianceScore: complianceScore,
        total: total,
        minPrice: minP,
        maxPrice: maxP,
      );

      results.add(BidScoreResult(
        vendorId: b.vendorId,
        vendorName: b.vendorName,
        total: double.parse(total.toStringAsFixed(1)),
        priceScore: double.parse(priceScore.toStringAsFixed(1)),
        deliveryScore: double.parse(deliveryScore.toStringAsFixed(1)),
        onTimeScore: double.parse(onTimeScore.toStringAsFixed(1)),
        ratingScore: double.parse(ratingScore.toStringAsFixed(1)),
        complianceScore: double.parse(complianceScore.toStringAsFixed(1)),
        explanation: explanation,
      ));
    }

    results.sort((a, b) => b.total.compareTo(a.total));
    return results;
  }

  static String _explain({
    required BidScoreInput b,
    required double priceScore,
    required double deliveryScore,
    required double onTimeScore,
    required double ratingScore,
    required double complianceScore,
    required double total,
    required double minPrice,
    required double maxPrice,
  }) {
    final naira = (b.unitPriceKobo / 100).toStringAsFixed(2);
    final priceNote = b.unitPriceKobo.toDouble() <= minPrice + 0.01
        ? 'lowest unit price (₦$naira)'
        : b.unitPriceKobo.toDouble() >= maxPrice - 0.01
            ? 'highest unit price (₦$naira)'
            : 'unit price ₦$naira (score ${priceScore.toStringAsFixed(0)})';
    final delNote = '${b.deliveryDays} day delivery (score ${deliveryScore.toStringAsFixed(0)})';
    final hist = b.hasHistory
        ? 'on-time ${b.onTimeRate.toStringAsFixed(0)}%, rating ${b.rating.toStringAsFixed(1)}/5'
        : 'new vendor with no delivery history (neutral score)';
    final comp = b.complianceComplete ? 'documents complete' : 'documents incomplete';
    return '${b.vendorName} scores ${total.toStringAsFixed(1)}/100: $priceNote; $delNote; $hist; $comp.';
  }

  /// Flag prices more than [zThreshold] stddevs from the mean of this RFQ.
  static List<PriceAnomaly> detectAnomalies(
    List<BidScoreInput> bids, {
    double zThreshold = 1.5,
  }) {
    if (bids.length < 3) return [];
    final prices = bids.map((b) => b.unitPriceKobo.toDouble()).toList();
    final mean = prices.reduce((a, b) => a + b) / prices.length;
    final variance =
        prices.map((p) => math.pow(p - mean, 2)).reduce((a, b) => a + b) / prices.length;
    final std = math.sqrt(variance);
    if (std < 1) return [];

    final out = <PriceAnomaly>[];
    for (final b in bids) {
      final z = (b.unitPriceKobo - mean) / std;
      if (z <= -zThreshold) {
        out.add(PriceAnomaly(
          vendorId: b.vendorId,
          vendorName: b.vendorName,
          kind: 'low',
          explanation:
              '${b.vendorName} is unusually low (₦${(b.unitPriceKobo / 100).toStringAsFixed(2)} vs mean ₦${(mean / 100).toStringAsFixed(2)}, z=${z.toStringAsFixed(2)}).',
        ));
      } else if (z >= zThreshold) {
        out.add(PriceAnomaly(
          vendorId: b.vendorId,
          vendorName: b.vendorName,
          kind: 'high',
          explanation:
              '${b.vendorName} is unusually high (₦${(b.unitPriceKobo / 100).toStringAsFixed(2)} vs mean ₦${(mean / 100).toStringAsFixed(2)}, z=${z.toStringAsFixed(2)}).',
        ));
      }
    }
    return out;
  }
}
