import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';

import '../../data/db/app_database.dart';

/// In-app notifications (offline; stored in the local database).
class NotificationService {
  NotificationService(this._db);
  final AppDatabase _db;
  static const _uuid = Uuid();

  /// Deep-link marker stored in `href` for a procurement.
  static String hrefFor(String procurementId) => 'procurement:$procurementId';

  static String? procurementIdFromHref(String? href) {
    if (href == null || !href.startsWith('procurement:')) return null;
    return href.substring('procurement:'.length);
  }

  Future<void> notifyUsers(
    Iterable<String> userIds, {
    required String title,
    String? body,
    String? procurementId,
    String? kind,
  }) async {
    final now = DateTime.now().toUtc();
    for (final id in userIds.toSet()) {
      await _db.into(_db.notifications).insert(NotificationsCompanion.insert(
            id: _uuid.v4(),
            userId: id,
            title: title,
            body: Value(body),
            kind: Value(kind),
            href: Value(procurementId == null ? null : hrefFor(procurementId)),
            createdAt: now,
          ));
    }
  }

  Future<List<Notification>> listFor(String userId) {
    return (_db.select(_db.notifications)
          ..where((n) => n.userId.equals(userId))
          ..orderBy([(n) => OrderingTerm.desc(n.createdAt)])
          ..limit(100))
        .get();
  }

  Future<int> unreadCount(String userId) async {
    final rows = await (_db.select(_db.notifications)
          ..where((n) => n.userId.equals(userId) & n.read.equals(false)))
        .get();
    return rows.length;
  }

  Future<void> markRead(String notificationId) async {
    await (_db.update(_db.notifications)..where((n) => n.id.equals(notificationId)))
        .write(const NotificationsCompanion(read: Value(true)));
  }

  Future<void> markAllRead(String userId) async {
    await (_db.update(_db.notifications)
          ..where((n) => n.userId.equals(userId) & n.read.equals(false)))
        .write(const NotificationsCompanion(read: Value(true)));
  }
}
