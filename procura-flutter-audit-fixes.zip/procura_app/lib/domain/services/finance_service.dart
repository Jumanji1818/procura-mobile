import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';

import '../../data/db/app_database.dart';
import '../../shared/utils/money.dart';
import '../models/auth_user.dart';
import '../models/procurement_status.dart';
import '../models/role.dart';
import '../workflow/workflow_action.dart';
import 'three_way_match.dart';
import 'workflow_service.dart';

class FinanceException implements Exception {
  final String message;
  FinanceException(this.message);
  @override
  String toString() => message;
}

/// Everything finance needs to see before releasing money.
class PaymentPreview {
  final Invoice invoice;
  final PurchaseOrder po;
  final GoodsReceipt receipt;
  final ThreeWayMatchResult match;
  final int payableKobo;

  const PaymentPreview({
    required this.invoice,
    required this.po,
    required this.receipt,
    required this.match,
    required this.payableKobo,
  });
}

/// Vendor invoice (own amount), three-way match, finance payment, complete.
class FinanceService {
  FinanceService(this._db, this._workflow);
  final AppDatabase _db;
  final WorkflowService _workflow;
  static const _uuid = Uuid();

  Future<VendorProfile?> _vendorForUser(String userId) async {
    return (_db.select(_db.vendorProfiles)..where((v) => v.userId.equals(userId))).getSingleOrNull();
  }

  Future<void> _setPoStatus(String procurementId, ProcurementStatus status) async {
    await (_db.update(_db.purchaseOrders)..where((p) => p.procurementId.equals(procurementId)))
        .write(PurchaseOrdersCompanion(status: Value(status.name)));
  }

  /// Vendor enters its own invoice amount — never copied from PO.
  Future<ThreeWayMatchResult> submitInvoice({
    required AuthUser actor,
    required String procurementId,
    required int amountKobo,
  }) async {
    if (actor.role != UserRole.vendor) {
      throw FinanceException('Only the vendor can submit an invoice.');
    }
    if (amountKobo <= 0) {
      throw FinanceException('Invoice amount must be greater than zero.');
    }

    final profile = await _vendorForUser(actor.id);
    if (profile == null) throw FinanceException('Vendor profile not found.');

    final proc = await (_db.select(_db.procurements)..where((p) => p.id.equals(procurementId)))
        .getSingleOrNull();
    if (proc == null) throw FinanceException('Procurement not found.');
    if (proc.status != ProcurementStatus.goodsReceived.name) {
      throw FinanceException('Invoice only after goods receipt.');
    }
    if (proc.awardedVendorId != profile.id) {
      throw FinanceException('This procurement is not yours.');
    }

    final po = await (_db.select(_db.purchaseOrders)
          ..where((p) => p.procurementId.equals(procurementId)))
        .getSingleOrNull();
    if (po == null) throw FinanceException('No purchase order.');

    final grn = await (_db.select(_db.goodsReceipts)
          ..where((g) => g.procurementId.equals(procurementId)))
        .getSingleOrNull();
    if (grn == null) throw FinanceException('No goods receipt on file.');

    final existing = await invoiceFor(procurementId);
    if (existing != null) throw FinanceException('An invoice was already submitted.');

    final match = ThreeWayMatch.compare(
      poTotalKobo: po.totalKobo,
      qtyOrdered: grn.qtyOrdered,
      qtyReceived: grn.qtyReceived,
      invoiceAmountKobo: amountKobo,
    );

    // One transaction: transition, invoice row, PO status and mismatch routing
    // succeed or fail together.
    await _db.transaction(() async {
      await _workflow.apply(
        procurementId: procurementId,
        action: WorkflowAction.submitInvoice,
        actor: actor,
        detail: 'amount=${formatNaira(amountKobo)}',
      );
      final now = DateTime.now().toUtc();
      final invNumber = await _db.nextDocumentNumber('INV');
      await _db.into(_db.invoices).insert(InvoicesCompanion.insert(
            id: _uuid.v4(),
            number: invNumber,
            procurementId: procurementId,
            poId: po.id,
            vendorId: profile.id,
            amountKobo: amountKobo,
            status: match.ok ? 'submitted' : 'mismatch',
            matchResult: Value(match.ok ? 'ready' : 'mismatch'),
            matchDetail: Value(match.detail),
            createdAt: now,
          ));

      var poStatus = ProcurementStatus.invoiced;
      // Automatic route: quantity/amount mismatch → payment review.
      if (!match.ok) {
        poStatus = ProcurementStatus.paymentReview;
        await (_db.update(_db.procurements)..where((p) => p.id.equals(procurementId))).write(
          ProcurementsCompanion(
            status: Value(ProcurementStatus.paymentReview.name),
            updatedAt: Value(now),
          ),
        );
        await _db.into(_db.auditLogs).insert(AuditLogsCompanion.insert(
              id: _uuid.v4(),
              procurementId: Value(procurementId),
              actorUserId: Value(actor.id),
              actorName: 'three-way-match',
              action: 'auto_payment_review',
              oldState: Value(ProcurementStatus.invoiced.name),
              newState: Value(ProcurementStatus.paymentReview.name),
              detail: Value(match.detail),
              createdAt: now,
            ));
      }
      await _setPoStatus(procurementId, poStatus);
    });

    return match;
  }

  /// Invoice, PO, receipt and match result for the finance officer's review.
  Future<PaymentPreview?> paymentPreview(String procurementId) async {
    final inv = await invoiceFor(procurementId);
    if (inv == null) return null;
    final po = await (_db.select(_db.purchaseOrders)
          ..where((p) => p.procurementId.equals(procurementId)))
        .getSingleOrNull();
    final grn = await (_db.select(_db.goodsReceipts)
          ..where((g) => g.procurementId.equals(procurementId)))
        .getSingleOrNull();
    if (po == null || grn == null) return null;
    final match = ThreeWayMatch.compare(
      poTotalKobo: po.totalKobo,
      qtyOrdered: grn.qtyOrdered,
      qtyReceived: grn.qtyReceived,
      invoiceAmountKobo: inv.amountKobo,
    );
    return PaymentPreview(
      invoice: inv,
      po: po,
      receipt: grn,
      match: match,
      payableKobo: ThreeWayMatch.payableKobo(match),
    );
  }

  /// Send an invoiced item to manual payment review.
  Future<void> holdPayment({
    required AuthUser actor,
    required String procurementId,
    required String reason,
  }) async {
    if (actor.role != UserRole.financeOfficer) {
      throw FinanceException('Only Finance Officer can hold a payment.');
    }
    if (reason.trim().length < 3) {
      throw FinanceException('Please give a reason for holding the payment.');
    }
    await _workflow.apply(
      procurementId: procurementId,
      action: WorkflowAction.holdPaymentReview,
      actor: actor,
      detail: reason.trim(),
    );
  }

  /// Pays at most the amount supported by the PO and the goods actually received.
  Future<void> approvePayment({
    required AuthUser actor,
    required String procurementId,
    String? method,
    String? reference,
  }) async {
    if (actor.role != UserRole.financeOfficer) {
      throw FinanceException('Only Finance Officer can approve payment.');
    }

    final preview = await paymentPreview(procurementId);
    if (preview == null) throw FinanceException('No invoice found.');
    if (preview.invoice.status == 'paid') {
      throw FinanceException('This invoice has already been paid.');
    }
    final payAmount = preview.payableKobo;
    if (payAmount <= 0) {
      throw FinanceException('Nothing is payable: no goods were received against this order.');
    }

    final proc = await (_db.select(_db.procurements)..where((p) => p.id.equals(procurementId)))
        .getSingleOrNull();
    if (proc == null) throw FinanceException('Procurement not found.');

    await _db.transaction(() async {
      // Transition first: a duplicate tap or wrong state throws here and nothing is written.
      await _workflow.apply(
        procurementId: procurementId,
        action: WorkflowAction.approvePayment,
        actor: actor,
        detail: 'paid ${formatNaira(payAmount)} of invoiced ${formatNaira(preview.invoice.amountKobo)}',
      );
      final now = DateTime.now().toUtc();
      await _db.into(_db.payments).insert(PaymentsCompanion.insert(
            id: _uuid.v4(),
            invoiceId: preview.invoice.id,
            procurementId: procurementId,
            amountKobo: payAmount,
            method: Value(method),
            reference: Value(reference),
            approvedByUserId: actor.id,
            paidAt: now,
          ));
      await (_db.update(_db.invoices)..where((i) => i.id.equals(preview.invoice.id))).write(
        const InvoicesCompanion(status: Value('paid')),
      );
      await _setPoStatus(procurementId, ProcurementStatus.paid);

      // Count the payment against this year's category budget.
      final year = now.year;
      final budget = await (_db.select(_db.categoryBudgets)
            ..where((b) => b.categoryId.equals(proc.categoryId) & b.year.equals(year)))
          .getSingleOrNull();
      if (budget != null) {
        await (_db.update(_db.categoryBudgets)..where((b) => b.id.equals(budget.id))).write(
          CategoryBudgetsCompanion(spentKobo: Value(budget.spentKobo + payAmount)),
        );
      }
    });
  }

  Future<void> complete({
    required AuthUser actor,
    required String procurementId,
  }) async {
    await _db.transaction(() async {
      await _workflow.apply(
        procurementId: procurementId,
        action: WorkflowAction.complete,
        actor: actor,
      );
      await _setPoStatus(procurementId, ProcurementStatus.completed);
    });
  }

  Future<Invoice?> invoiceFor(String procurementId) async {
    return (_db.select(_db.invoices)..where((i) => i.procurementId.equals(procurementId)))
        .getSingleOrNull();
  }
}
