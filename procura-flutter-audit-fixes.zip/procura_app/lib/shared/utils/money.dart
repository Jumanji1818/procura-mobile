import 'package:intl/intl.dart';

final NumberFormat _nairaFormat = NumberFormat('#,##0.00');

/// Formats an integer kobo amount as naira, e.g. 150000 -> ₦1,500.00.
String formatNaira(int kobo) => '₦${_nairaFormat.format(kobo / 100)}';
