import 'package:flutter/material.dart';

/// Dark / gold premium theme — not default Material.
class ProcuraColors {
  static const canvas = Color(0xFF0F1412);
  static const surface = Color(0xFF1A221F);
  static const surface2 = Color(0xFF24302B);
  static const gold = Color(0xFFC9A227);
  static const goldSoft = Color(0xFF3D3420);
  static const text = Color(0xFFF5F0E6);
  static const muted = Color(0xFF9A9488);
  static const danger = Color(0xFFC45C4A);
  static const success = Color(0xFF3D8B6E);
  static const border = Color(0xFF2E3A35);
}

class ProcuraTheme {
  static ThemeData get dark {
    final base = ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: const ColorScheme.dark(
        primary: ProcuraColors.gold,
        onPrimary: ProcuraColors.canvas,
        secondary: ProcuraColors.goldSoft,
        surface: ProcuraColors.surface,
        onSurface: ProcuraColors.text,
        error: ProcuraColors.danger,
      ),
      scaffoldBackgroundColor: ProcuraColors.canvas,
    );
    return base.copyWith(
      appBarTheme: const AppBarTheme(
        backgroundColor: ProcuraColors.surface,
        foregroundColor: ProcuraColors.text,
        elevation: 0,
        centerTitle: false,
      ),
      cardTheme: CardThemeData(
        color: ProcuraColors.surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: ProcuraColors.border),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: ProcuraColors.surface2,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: ProcuraColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: ProcuraColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: ProcuraColors.gold, width: 1.5),
        ),
        labelStyle: const TextStyle(color: ProcuraColors.muted),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: ProcuraColors.gold,
          foregroundColor: ProcuraColors.canvas,
          minimumSize: const Size.fromHeight(48),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
      navigationRailTheme: const NavigationRailThemeData(
        backgroundColor: ProcuraColors.surface,
        selectedIconTheme: IconThemeData(color: ProcuraColors.gold),
        selectedLabelTextStyle: TextStyle(color: ProcuraColors.gold),
        unselectedIconTheme: IconThemeData(color: ProcuraColors.muted),
      ),
      dividerColor: ProcuraColors.border,
    );
  }
}
