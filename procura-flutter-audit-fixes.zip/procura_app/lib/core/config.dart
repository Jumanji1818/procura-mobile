/// Build-time switches. Override with `--dart-define=NAME=value`.
///
/// Shows the demo login hint on the sign-in screen. Turn it off for the final
/// build: `flutter build apk --release --dart-define=SHOW_DEMO_HINT=false`
const bool showDemoHint = bool.fromEnvironment('SHOW_DEMO_HINT', defaultValue: true);
