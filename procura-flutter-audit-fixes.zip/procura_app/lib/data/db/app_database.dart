import 'dart:io';

import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'tables.dart';

part 'app_database.g.dart';

@DriftDatabase(tables: [
  Users,
  Departments,
  Categories,
  CategoryBudgets,
  VendorProfiles,
  VendorCategories,
  Procurements,
  Bids,
  PurchaseOrders,
  Deliveries,
  GoodsReceipts,
  Invoices,
  Payments,
  AuditLogs,
  DocumentCounters,
  Notifications,
  ScoringWeights,
])
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());

  AppDatabase.forTesting(super.e);

  @override
  int get schemaVersion => 1;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (m) async {
          await m.createAll();
          await customStatement('PRAGMA foreign_keys = ON');
          // Business CHECKs (SQLite enforces when enabled)
          await customStatement(
            'CREATE TRIGGER IF NOT EXISTS trg_proc_qty_pos '
            'BEFORE INSERT ON procurements '
            'BEGIN SELECT CASE WHEN NEW.quantity <= 0 THEN '
            "RAISE(ABORT, 'quantity must be > 0') END; END;",
          );
          await customStatement(
            'CREATE TRIGGER IF NOT EXISTS trg_bid_price_pos '
            'BEFORE INSERT ON bids '
            'BEGIN SELECT CASE WHEN NEW.unit_price_kobo <= 0 OR NEW.total_price_kobo <= 0 '
            "OR NEW.delivery_days <= 0 THEN RAISE(ABORT, 'bid price/days must be > 0') END; END;",
          );

          await customStatement(
            'CREATE TRIGGER IF NOT EXISTS trg_proc_qty_pos_upd '
            'BEFORE UPDATE ON procurements '
            'BEGIN SELECT CASE WHEN NEW.quantity <= 0 THEN '
            "RAISE(ABORT, 'quantity must be > 0') END; END;",
          );
          await customStatement(
            'CREATE TRIGGER IF NOT EXISTS trg_bid_price_pos_upd '
            'BEFORE UPDATE ON bids '
            'BEGIN SELECT CASE WHEN NEW.unit_price_kobo <= 0 OR NEW.total_price_kobo <= 0 '
            "OR NEW.delivery_days <= 0 THEN RAISE(ABORT, 'bid price/days must be > 0') END; END;",
          );
        },
        beforeOpen: (details) async {
          await customStatement('PRAGMA foreign_keys = ON');
        },
      );

  /// Next document number inside a transaction, e.g. PO-2026-001.
  Future<String> nextDocumentNumber(String prefix) async {
    final year = DateTime.now().year;
    final key = '$prefix:$year';
    return transaction(() async {
      final existing = await (select(documentCounters)..where((t) => t.id.equals(key))).getSingleOrNull();
      final next = (existing?.lastValue ?? 0) + 1;
      if (existing == null) {
        await into(documentCounters).insert(
          DocumentCountersCompanion.insert(
            id: key,
            prefix: prefix,
            year: year,
            lastValue: next,
          ),
        );
      } else {
        await (update(documentCounters)..where((t) => t.id.equals(key))).write(
          DocumentCountersCompanion(lastValue: Value(next)),
        );
      }
      final padded = next.toString().padLeft(3, '0');
      return '$prefix-$year-$padded';
    });
  }
}

LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    final dir = await getApplicationSupportDirectory();
    final file = File(p.join(dir.path, 'procura.sqlite'));
    return NativeDatabase.createInBackground(file);
  });
}
