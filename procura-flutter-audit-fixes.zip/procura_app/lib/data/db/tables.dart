import 'package:drift/drift.dart';

/// Users — every person has a real login (no ghost teammates).
class Users extends Table {
  TextColumn get id => text()();
  TextColumn get email => text().unique()();
  TextColumn get displayName => text()();
  TextColumn get passwordHash => text()();
  TextColumn get role => text()(); // UserRole.name
  TextColumn get departmentId => text().nullable()();
  IntColumn get failedLogins => integer().withDefault(const Constant(0))();
  DateTimeColumn get lockedUntil => dateTime().nullable()();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class Departments extends Table {
  TextColumn get id => text()();
  TextColumn get name => text()();
  TextColumn get code => text().unique()();

  @override
  Set<Column> get primaryKey => {id};
}

class Categories extends Table {
  TextColumn get id => text()();
  TextColumn get parentName => text()();
  TextColumn get subcategory => text()();

  @override
  Set<Column> get primaryKey => {id};
}

class CategoryBudgets extends Table {
  TextColumn get id => text()();
  TextColumn get categoryId => text().references(Categories, #id)();
  IntColumn get year => integer()();
  IntColumn get amountKobo => integer()(); // store money as integer kobo
  IntColumn get spentKobo => integer().withDefault(const Constant(0))();

  @override
  Set<Column> get primaryKey => {id};
}

/// Vendor profile linked 1:1 to a user with role=vendor.
class VendorProfiles extends Table {
  TextColumn get id => text()();
  TextColumn get userId => text().references(Users, #id)();
  TextColumn get businessName => text()();
  TextColumn get location => text().nullable()();
  TextColumn get regions => text().nullable()();
  RealColumn get rating => real().withDefault(const Constant(0.0))();
  RealColumn get onTimeRate => real().withDefault(const Constant(100.0))();
  IntColumn get completedOrders => integer().withDefault(const Constant(0))();
  IntColumn get lateDeliveries => integer().withDefault(const Constant(0))();
  BoolColumn get flagged => boolean().withDefault(const Constant(false))();

  @override
  Set<Column> get primaryKey => {id};
}

class VendorCategories extends Table {
  TextColumn get id => text()();
  TextColumn get vendorId => text().references(VendorProfiles, #id)();
  TextColumn get categoryId => text().references(Categories, #id)();

  @override
  Set<Column> get primaryKey => {id};
}

class Procurements extends Table {
  TextColumn get id => text()();
  TextColumn get number => text().unique()();
  TextColumn get title => text()();
  TextColumn get itemDescription => text()();
  TextColumn get categoryId => text().references(Categories, #id)();
  TextColumn get departmentId => text().references(Departments, #id)();
  TextColumn get createdByUserId => text().references(Users, #id)();
  IntColumn get quantity => integer()();
  TextColumn get unit => text()();
  IntColumn get budgetKobo => integer().nullable()();
  TextColumn get deliveryLocation => text().nullable()();
  DateTimeColumn get requiredDate => dateTime().nullable()();
  DateTimeColumn get closingDate => dateTime().nullable()();
  TextColumn get status => text()(); // ProcurementStatus.name
  TextColumn get recommendedVendorId => text().nullable()();
  TextColumn get recommendationReason => text().nullable()();
  TextColumn get awardedVendorId => text().nullable()();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class Bids extends Table {
  TextColumn get id => text()();
  TextColumn get procurementId => text().references(Procurements, #id)();
  TextColumn get vendorId => text().references(VendorProfiles, #id)();
  IntColumn get unitPriceKobo => integer()();
  IntColumn get totalPriceKobo => integer()();
  IntColumn get deliveryDays => integer()();
  IntColumn get validityDays => integer()();
  TextColumn get notes => text().nullable()();
  BoolColumn get complianceComplete => boolean().withDefault(const Constant(true))();
  BoolColumn get lateDeliveryAcknowledged => boolean().withDefault(const Constant(false))();
  BoolColumn get locked => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};

  @override
  List<Set<Column>> get uniqueKeys => [
        {procurementId, vendorId}, // one bid per vendor per RFQ
      ];
}

class PurchaseOrders extends Table {
  TextColumn get id => text()();
  TextColumn get number => text().unique()();
  TextColumn get procurementId => text().references(Procurements, #id)();
  TextColumn get vendorId => text().references(VendorProfiles, #id)();
  IntColumn get totalKobo => integer()();
  TextColumn get deliveryLocation => text().nullable()();
  DateTimeColumn get deliveryDate => dateTime().nullable()();
  TextColumn get terms => text().nullable()();
  TextColumn get status => text()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};

  @override
  List<Set<Column>> get uniqueKeys => [
        {procurementId}, // one PO per procurement
      ];
}

class Deliveries extends Table {
  TextColumn get id => text()();
  TextColumn get poId => text().references(PurchaseOrders, #id)();
  TextColumn get procurementId => text().references(Procurements, #id)();
  TextColumn get vendorId => text().references(VendorProfiles, #id)();
  TextColumn get status => text()();
  DateTimeColumn get eta => dateTime().nullable()();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};

  @override
  List<Set<Column>> get uniqueKeys => [
        {procurementId}, // one delivery record per procurement
      ];
}

class GoodsReceipts extends Table {
  TextColumn get id => text()();
  TextColumn get procurementId => text().references(Procurements, #id)();
  TextColumn get poId => text().references(PurchaseOrders, #id)();
  IntColumn get qtyOrdered => integer()();
  IntColumn get qtyReceived => integer()();
  IntColumn get qtyDamaged => integer().withDefault(const Constant(0))();
  IntColumn get qtyMissing => integer().withDefault(const Constant(0))();
  TextColumn get notes => text().nullable()();
  TextColumn get receivedByUserId => text().references(Users, #id)();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};

  @override
  List<Set<Column>> get uniqueKeys => [
        {procurementId}, // one goods receipt per procurement
      ];
}

class Invoices extends Table {
  TextColumn get id => text()();
  TextColumn get number => text().unique()();
  TextColumn get procurementId => text().references(Procurements, #id)();
  TextColumn get poId => text().references(PurchaseOrders, #id)();
  TextColumn get vendorId => text().references(VendorProfiles, #id)();
  IntColumn get amountKobo => integer()(); // vendor-entered, NOT copied from PO
  TextColumn get status => text()();
  TextColumn get matchResult => text().nullable()();
  TextColumn get matchDetail => text().nullable()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};

  @override
  List<Set<Column>> get uniqueKeys => [
        {procurementId}, // one invoice per procurement
      ];
}

class Payments extends Table {
  TextColumn get id => text()();
  TextColumn get invoiceId => text().references(Invoices, #id)();
  TextColumn get procurementId => text().references(Procurements, #id)();
  IntColumn get amountKobo => integer()();
  TextColumn get method => text().nullable()();
  TextColumn get reference => text().nullable()();
  TextColumn get approvedByUserId => text().references(Users, #id)();
  DateTimeColumn get paidAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};

  @override
  List<Set<Column>> get uniqueKeys => [
        {invoiceId}, // an invoice can only be paid once
      ];
}

class AuditLogs extends Table {
  TextColumn get id => text()();
  TextColumn get procurementId => text().nullable()();
  TextColumn get actorUserId => text().nullable()();
  TextColumn get actorName => text()();
  TextColumn get action => text()();
  TextColumn get oldState => text().nullable()();
  TextColumn get newState => text().nullable()();
  TextColumn get detail => text().nullable()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Per-year document number counters (PO-2026-001 etc.) — updated inside transactions.
class DocumentCounters extends Table {
  TextColumn get id => text()(); // e.g. "PO:2026"
  TextColumn get prefix => text()();
  IntColumn get year => integer()();
  IntColumn get lastValue => integer()();

  @override
  Set<Column> get primaryKey => {id};
}

class Notifications extends Table {
  TextColumn get id => text()();
  TextColumn get userId => text().references(Users, #id)();
  TextColumn get title => text()();
  TextColumn get body => text().nullable()();
  TextColumn get kind => text().nullable()();
  TextColumn get href => text().nullable()();
  BoolColumn get read => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

class ScoringWeights extends Table {
  TextColumn get id => text()();
  RealColumn get priceWeight => real()();
  RealColumn get deliveryWeight => real()();
  RealColumn get onTimeWeight => real()();
  RealColumn get ratingWeight => real()();
  RealColumn get complianceWeight => real()();
  TextColumn get updatedByUserId => text().nullable()();
  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}
