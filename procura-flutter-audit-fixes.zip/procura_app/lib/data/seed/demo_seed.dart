import 'package:bcrypt/bcrypt.dart';
import 'package:drift/drift.dart';
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../../domain/models/role.dart';
import '../db/app_database.dart';

String _hashDemoPassword(String password) => BCrypt.hashpw(password, BCrypt.gensalt());

/// Seeds demo accounts, departments, categories and budgets once per install.
class DemoSeed {
  DemoSeed(this.db);
  final AppDatabase db;
  static const _uuid = Uuid();

  Future<void> ensureSeeded() async {
    final existing = await (db.select(db.users)..limit(1)).get();
    if (existing.isNotEmpty) return;
    await seedAll();
  }

  Future<void> seedAll() async {
    final now = DateTime.now().toUtc();
    // bcrypt is slow: keep it off the UI isolate so the splash screen stays responsive.
    final hash = await compute(_hashDemoPassword, 'Procura1!');

    await db.transaction(() async {
      final depts = {
        'ops': ('Operations', 'OPS'),
        'fin': ('Finance', 'FIN'),
        'eng': ('Engineering', 'ENG'),
      };
      final deptIds = <String, String>{};
      for (final e in depts.entries) {
        final id = _uuid.v4();
        deptIds[e.key] = id;
        await db.into(db.departments).insert(DepartmentsCompanion.insert(
              id: id,
              name: e.value.$1,
              code: e.value.$2,
            ));
      }

      final cats = <String, String>{};
      final catDefs = [
        ('Building & Construction', 'Cement'),
        ('Building & Construction', 'Sand'),
        ('Building & Construction', 'Steel'),
        ('IT & Office', 'Computers'),
        ('IT & Office', 'Stationery'),
        ('Facilities', 'Cleaning'),
        ('Facilities', 'Security'),
        ('Catering', 'Meals'),
        ('Medical & Healthcare', 'Consumables'),
        ('Medical & Healthcare', 'Equipment'),
        ('Hospitality', 'Linen & Bedding'),
        ('Hospitality', 'Toiletries'),
      ];
      for (final c in catDefs) {
        final id = _uuid.v4();
        cats['${c.$1}|${c.$2}'] = id;
        await db.into(db.categories).insert(CategoriesCompanion.insert(
              id: id,
              parentName: c.$1,
              subcategory: c.$2,
            ));
        await db.into(db.categoryBudgets).insert(CategoryBudgetsCompanion.insert(
              id: _uuid.v4(),
              categoryId: id,
              year: now.year,
              amountKobo: 5000000000,
            ));
      }

      Future<String> user(
        String email,
        String name,
        UserRole role, {
        String? dept,
      }) async {
        final id = _uuid.v4();
        await db.into(db.users).insert(UsersCompanion.insert(
              id: id,
              email: email,
              displayName: name,
              passwordHash: hash,
              role: role.name,
              departmentId: Value(dept),
              createdAt: now,
            ));
        return id;
      }

      await user('admin@procura.local', 'Ada Org Admin', UserRole.orgAdmin);
      await user('request@procura.local', 'Chidi Request', UserRole.requestOfficer,
          dept: deptIds['ops']);
      // One Department Head per department
      await user('head.ops@procura.local', 'Ngozi Head Ops', UserRole.departmentHead,
          dept: deptIds['ops']);
      await user('head.fin@procura.local', 'Yusuf Head Finance', UserRole.departmentHead,
          dept: deptIds['fin']);
      await user('head.eng@procura.local', 'Amaka Head Engineering', UserRole.departmentHead,
          dept: deptIds['eng']);
      // Legacy alias for docs
      await user('head@procura.local', 'Ngozi Dept Head', UserRole.departmentHead,
          dept: deptIds['ops']);
      await user('procure@procura.local', 'Emeka Procurement', UserRole.procurementOfficer);
      await user('finance@procura.local', 'Fatima Finance', UserRole.financeOfficer);
      await user('approve@procura.local', 'Ibrahim Approver', UserRole.approvingAuthority);

      final vendorDefs = [
        ('Apex Cement Distributors', 'Abuja', 'Building & Construction', 'Cement'),
        ('Sahel Building Materials', 'Kaduna', 'Building & Construction', 'Cement'),
        ('Northern Steel Works', 'Kano', 'Building & Construction', 'Steel'),
        ('OfficePro Nigeria', 'Lagos', 'IT & Office', 'Computers'),
        ('CleanCity Facilities', 'Abuja', 'Facilities', 'Cleaning'),
        ('Kaduna Cement Depot', 'Kaduna', 'Building & Construction', 'Cement'),
        ('Sandpit Aggregates', 'Kaduna', 'Building & Construction', 'Sand'),
        ('Stationers Hub', 'Abuja', 'IT & Office', 'Stationery'),
        ('Guardline Security', 'Abuja', 'Facilities', 'Security'),
        ('FreshMeals Catering', 'Kaduna', 'Catering', 'Meals'),
        ('MedSupply Nigeria', 'Abuja', 'Medical & Healthcare', 'Consumables'),
        ('PharmaLink Supplies', 'Abuja', 'Medical & Healthcare', 'Consumables'),
        ('HotelLinen Co', 'Lagos', 'Hospitality', 'Linen & Bedding'),
      ];
      for (final v in vendorDefs) {
        final uid = _uuid.v4();
        final vid = _uuid.v4();
        final email = '${v.$1.toLowerCase().replaceAll(' ', '.')}@vendor.local';
        await db.into(db.users).insert(UsersCompanion.insert(
              id: uid,
              email: email,
              displayName: v.$1,
              passwordHash: hash,
              role: UserRole.vendor.name,
              createdAt: now,
            ));
        await db.into(db.vendorProfiles).insert(VendorProfilesCompanion.insert(
              id: vid,
              userId: uid,
              businessName: v.$1,
              location: Value(v.$2),
              rating: const Value(4.2),
              onTimeRate: const Value(90.0),
              completedOrders: const Value(8),
            ));
        final catId = cats['${v.$3}|${v.$4}'];
        if (catId != null) {
          await db.into(db.vendorCategories).insert(VendorCategoriesCompanion.insert(
                id: _uuid.v4(),
                vendorId: vid,
                categoryId: catId,
              ));
        }
      }

      await db.into(db.scoringWeights).insert(ScoringWeightsCompanion.insert(
            id: 'default',
            priceWeight: 0.35,
            deliveryWeight: 0.20,
            onTimeWeight: 0.20,
            ratingWeight: 0.15,
            complianceWeight: 0.10,
            updatedAt: now,
          ));
    });
  }
}
