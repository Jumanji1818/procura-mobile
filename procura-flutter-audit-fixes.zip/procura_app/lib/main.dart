import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/theme/procura_theme.dart';
import 'features/splash/splash_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ProviderScope(child: ProcuraApp()));
}

class ProcuraApp extends StatelessWidget {
  const ProcuraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Procura',
      debugShowCheckedModeBanner: false,
      theme: ProcuraTheme.dark,
      home: const SplashPage(),
    );
  }
}
