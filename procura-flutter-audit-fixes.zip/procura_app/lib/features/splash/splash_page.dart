import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/procura_theme.dart';
import '../../data/seed/demo_seed.dart';
import '../auth/auth_providers.dart';
import '../auth/login_page.dart';

class SplashPage extends ConsumerStatefulWidget {
  const SplashPage({super.key});

  @override
  ConsumerState<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends ConsumerState<SplashPage> {
  String _status = 'Starting Procura…';

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    try {
      setState(() => _status = 'Preparing local database…');
      final db = ref.read(databaseProvider);
      setState(() => _status = 'Loading demo data if needed…');
      await DemoSeed(db).ensureSeeded();
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const LoginPage()),
      );
    } catch (e) {
      setState(() => _status = 'Startup error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ProcuraColors.canvas,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.account_balance, size: 72, color: ProcuraColors.gold),
            const SizedBox(height: 16),
            const Text(
              'Procura',
              style: TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.w600,
                color: ProcuraColors.gold,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Smart Procurement Management',
              style: TextStyle(color: ProcuraColors.muted),
            ),
            const SizedBox(height: 32),
            const SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(strokeWidth: 2, color: ProcuraColors.gold),
            ),
            const SizedBox(height: 16),
            Text(_status, style: const TextStyle(color: ProcuraColors.muted, fontSize: 13)),
          ],
        ),
      ),
    );
  }
}
