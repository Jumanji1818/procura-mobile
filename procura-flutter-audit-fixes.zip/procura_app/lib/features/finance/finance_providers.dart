import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/services/finance_service.dart';
import '../../domain/services/reports_service.dart';
import '../auth/auth_providers.dart';
import '../requests/requests_providers.dart';

final financeServiceProvider = Provider<FinanceService>((ref) {
  return FinanceService(
    ref.watch(databaseProvider),
    ref.watch(workflowServiceProvider),
  );
});

final reportsServiceProvider = Provider<ReportsService>((ref) {
  return ReportsService(ref.watch(databaseProvider));
});
