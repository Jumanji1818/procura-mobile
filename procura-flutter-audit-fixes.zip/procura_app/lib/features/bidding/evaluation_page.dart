import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/procura_theme.dart';
import '../../data/db/app_database.dart';
import '../../domain/services/scoring_engine.dart';
import '../../shared/utils/money.dart';
import '../auth/auth_providers.dart';
import '../delivery/fulfillment_providers.dart';
import '../requests/requests_providers.dart';
import 'bid_providers.dart';

/// procurement: score bids and save a recommendation.
/// approver: see every bid, the recommendation and the budget, then award or reject.
enum EvaluationMode { procurement, approver }

class EvaluationPage extends ConsumerStatefulWidget {
  final String procurementId;
  final EvaluationMode mode;
  const EvaluationPage({
    super.key,
    required this.procurementId,
    this.mode = EvaluationMode.procurement,
  });

  @override
  ConsumerState<EvaluationPage> createState() => _EvaluationPageState();
}

class _EvaluationPageState extends ConsumerState<EvaluationPage> {
  List<BidScoreResult> _scores = [];
  List<PriceAnomaly> _anomalies = [];
  Map<String, Bid> _bidByVendor = {};
  Procurement? _proc;
  bool _loading = true;
  bool _busy = false;
  String? _error;

  bool get _isApprover => widget.mode == EvaluationMode.approver;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final bidSvc = ref.read(bidServiceProvider);
      final inputs = await bidSvc.scoreInputs(widget.procurementId);
      final weights = await bidSvc.loadWeights();
      final bids = await bidSvc.listBidsForStaff(widget.procurementId);
      final proc = await bidSvc.getProcurement(widget.procurementId);
      if (!mounted) return;
      setState(() {
        _scores = ScoringEngine.rank(inputs, weights: weights);
        _anomalies = ScoringEngine.detectAnomalies(inputs);
        _bidByVendor = {for (final b in bids) b.vendorId: b};
        _proc = proc;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _recommend(BidScoreResult s) async {
    final user = ref.read(currentUserProvider);
    if (user == null || _busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(bidServiceProvider).saveRecommendation(
            actor: user,
            procurementId: widget.procurementId,
            vendorId: s.vendorId,
            reason: s.explanation,
          );
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Recommended ${s.vendorName}')),
        );
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<bool> _confirm(String title, String body, String action) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(action)),
        ],
      ),
    );
    return ok == true;
  }

  Future<void> _award(BidScoreResult s) async {
    final user = ref.read(currentUserProvider);
    if (user == null || _busy) return;
    final bid = _bidByVendor[s.vendorId];
    final ok = await _confirm(
      'Award to ${s.vendorName}?',
      bid == null ? 'This cannot be undone.' : 'Contract value ${formatNaira(bid.totalPriceKobo)}. This cannot be undone.',
      'Award',
    );
    if (!ok) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref
          .read(fulfillmentServiceProvider)
          .award(actor: user, procurementId: widget.procurementId, vendorId: s.vendorId);
      ref.invalidate(requestsListProvider);
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _reject() async {
    final user = ref.read(currentUserProvider);
    if (user == null || _busy) return;
    final c = TextEditingController();
    final note = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Reject request'),
        content: TextField(
          controller: c,
          maxLines: 3,
          decoration: const InputDecoration(labelText: 'Reason for rejection'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('Reject')),
        ],
      ),
    );
    if (note == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref
          .read(procurementServiceProvider)
          .reject(procurementId: widget.procurementId, actor: user, note: note);
      ref.invalidate(requestsListProvider);
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final recommended = _proc?.recommendedVendorId;
    return Scaffold(
      appBar: AppBar(title: Text(_isApprover ? 'Review bids' : 'Evaluation')),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: ProcuraColors.gold))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (_proc != null) ...[
                  Text(_proc!.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  Text(
                    '${_proc!.quantity} ${_proc!.unit}'
                    '${_proc!.budgetKobo != null ? ' · Budget ${formatNaira(_proc!.budgetKobo!)}' : ' · No budget set'}',
                    style: const TextStyle(color: ProcuraColors.muted),
                  ),
                  const SizedBox(height: 16),
                ],
                if (_error != null) ...[
                  Text(_error!, style: const TextStyle(color: ProcuraColors.danger)),
                  const SizedBox(height: 8),
                ],
                const Text(
                  'Ranked bids',
                  style: TextStyle(fontWeight: FontWeight.w600, color: ProcuraColors.gold),
                ),
                const SizedBox(height: 8),
                if (_scores.isEmpty)
                  const Text('No bids to score.', style: TextStyle(color: ProcuraColors.muted)),
                ..._scores.map((s) {
                  final bid = _bidByVendor[s.vendorId];
                  final isRec = s.vendorId == recommended;
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(s.vendorName,
                                    style: const TextStyle(fontWeight: FontWeight.w600)),
                              ),
                              Text(s.total.toStringAsFixed(0),
                                  style: const TextStyle(
                                      fontSize: 20,
                                      color: ProcuraColors.gold,
                                      fontWeight: FontWeight.w700)),
                            ],
                          ),
                          if (isRec)
                            const Padding(
                              padding: EdgeInsets.only(top: 4),
                              child: Text('Recommended by procurement',
                                  style: TextStyle(color: ProcuraColors.success, fontSize: 12)),
                            ),
                          if (bid != null) ...[
                            const SizedBox(height: 6),
                            Text(
                              '${formatNaira(bid.totalPriceKobo)} total · ${bid.deliveryDays} day(s) delivery',
                              style: const TextStyle(fontSize: 13),
                            ),
                          ],
                          const SizedBox(height: 8),
                          Text(s.explanation,
                              style: const TextStyle(fontSize: 13, color: ProcuraColors.muted)),
                          const SizedBox(height: 8),
                          Text(
                            'Price ${s.priceScore.toStringAsFixed(0)} · Delivery ${s.deliveryScore.toStringAsFixed(0)} · '
                            'On-time ${s.onTimeScore.toStringAsFixed(0)} · Rating ${s.ratingScore.toStringAsFixed(0)} · '
                            'Compliance ${s.complianceScore.toStringAsFixed(0)}',
                            style: const TextStyle(fontSize: 11, color: ProcuraColors.muted),
                          ),
                          const SizedBox(height: 10),
                          if (_isApprover)
                            ElevatedButton(
                              onPressed: _busy ? null : () => _award(s),
                              child: Text('Award to ${s.vendorName}'),
                            )
                          else if (!isRec)
                            OutlinedButton(
                              onPressed: _busy ? null : () => _recommend(s),
                              child: const Text('Save as recommendation'),
                            ),
                        ],
                      ),
                    ),
                  );
                }),
                if (_anomalies.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  const Text('Price anomalies',
                      style: TextStyle(fontWeight: FontWeight.w600, color: ProcuraColors.gold)),
                  const SizedBox(height: 8),
                  ..._anomalies.map((a) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Text(a.explanation, style: const TextStyle(fontSize: 13)),
                      )),
                ],
                if (_isApprover) ...[
                  const SizedBox(height: 16),
                  TextButton(
                    onPressed: _busy ? null : _reject,
                    child: const Text('Reject this request',
                        style: TextStyle(color: ProcuraColors.danger)),
                  ),
                ],
              ],
            ),
    );
  }
}
