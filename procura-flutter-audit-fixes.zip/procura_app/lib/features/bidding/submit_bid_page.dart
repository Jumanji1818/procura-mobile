import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:intl/intl.dart';

import '../../core/theme/procura_theme.dart';
import '../../data/db/app_database.dart';
import '../../domain/services/bid_rules.dart';
import '../auth/auth_providers.dart';
import 'bid_providers.dart';

class SubmitBidPage extends ConsumerStatefulWidget {
  final String procurementId;
  const SubmitBidPage({super.key, required this.procurementId});

  @override
  ConsumerState<SubmitBidPage> createState() => _SubmitBidPageState();
}

class _SubmitBidPageState extends ConsumerState<SubmitBidPage> {
  final _price = TextEditingController();
  final _days = TextEditingController();
  final _validity = TextEditingController(text: '30');
  bool _ack = false;
  bool _docsComplete = true;
  String? _error;
  bool _busy = false;
  int? _otherBids;
  Procurement? _rfq;
  bool _alreadyBid = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final svc = ref.read(bidServiceProvider);
    final user = ref.read(currentUserProvider);
    final n = await svc.bidCount(widget.procurementId);
    final rfq = await svc.getProcurement(widget.procurementId);
    final already = user == null
        ? false
        : await svc.hasBid(actor: user, procurementId: widget.procurementId);
    if (mounted) {
      setState(() {
        _otherBids = n;
        _rfq = rfq;
        _alreadyBid = already;
      });
    }
  }

  @override
  void dispose() {
    _price.dispose();
    _days.dispose();
    _validity.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final user = ref.read(currentUserProvider);
    if (user == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final naira = double.tryParse(_price.text.trim().replaceAll(',', ''));
      if (naira == null) throw BidValidationException('Enter a valid unit price.');
      final unitKobo = (naira * 100).round();
      final days = int.tryParse(_days.text.trim()) ?? 0;
      final validity = int.tryParse(_validity.text.trim()) ?? 30;

      await ref.read(bidServiceProvider).submitBid(
            actor: user,
            procurementId: widget.procurementId,
            unitPriceKobo: unitKobo,
            deliveryDays: days,
            validityDays: validity,
            lateDeliveryAcknowledged: _ack,
            complianceComplete: _docsComplete,
          );
      if (!mounted) return;
      Navigator.of(context).pop();
    } on BidValidationException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Submit bid')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (_rfq != null) ...[
            Text(_rfq!.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(_rfq!.number, style: const TextStyle(color: ProcuraColors.muted, fontSize: 12)),
            const SizedBox(height: 10),
            Text(_rfq!.itemDescription),
            const SizedBox(height: 8),
            Text('Quantity: ${_rfq!.quantity} ${_rfq!.unit}'),
            if (_rfq!.deliveryLocation != null) Text('Deliver to: ${_rfq!.deliveryLocation}'),
            if (_rfq!.closingDate != null)
              Text('Closes: ${DateFormat('d MMM y, HH:mm').format(_rfq!.closingDate!.toLocal())}'),
            const SizedBox(height: 16),
          ],
          if (_alreadyBid)
            const Padding(
              padding: EdgeInsets.only(bottom: 12),
              child: Text('You have already submitted a bid for this RFQ. Bids are locked.',
                  style: TextStyle(color: ProcuraColors.success)),
            ),
          Text(
            _otherBids == null
                ? 'Loading bid activity…'
                : '$_otherBids bid(s) received so far (prices are private).',
            style: const TextStyle(color: ProcuraColors.muted),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _price,
            decoration: const InputDecoration(labelText: 'Unit price (₦)'),
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _days,
            decoration: const InputDecoration(labelText: 'Delivery days'),
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _validity,
            decoration: const InputDecoration(labelText: 'Validity (days)'),
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          ),
          const SizedBox(height: 16),
          CheckboxListTile(
            value: _ack,
            activeColor: ProcuraColors.gold,
            onChanged: (v) => setState(() => _ack = v ?? false),
            title: const Text(
              'I acknowledge late delivery may attract contractual penalties and legal action under the purchase terms.',
              style: TextStyle(fontSize: 13),
            ),
            controlAffinity: ListTileControlAffinity.leading,
          ),
          CheckboxListTile(
            value: _docsComplete,
            activeColor: ProcuraColors.gold,
            onChanged: (v) => setState(() => _docsComplete = v ?? false),
            title: const Text(
              'My bid documents (registration, tax, specifications) are complete.',
              style: TextStyle(fontSize: 13),
            ),
            controlAffinity: ListTileControlAffinity.leading,
          ),
          if (_error != null) ...[
            const SizedBox(height: 8),
            Text(_error!, style: const TextStyle(color: ProcuraColors.danger)),
          ],
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: (_busy || _alreadyBid) ? null : _submit,
            child: Text(_busy ? 'Submitting…' : 'Submit locked bid'),
          ),
        ],
      ),
    );
  }
}
