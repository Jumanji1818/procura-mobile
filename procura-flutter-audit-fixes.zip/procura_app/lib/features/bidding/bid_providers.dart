import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/db/app_database.dart';
import '../../domain/services/bid_service.dart';
import '../auth/auth_providers.dart';
import '../requests/requests_providers.dart';

final bidServiceProvider = Provider<BidService>((ref) {
  return BidService(
    ref.watch(databaseProvider),
    ref.watch(workflowServiceProvider),
  );
});

final openRfqProvider = FutureProvider<List<Procurement>>((ref) async {
  final user = ref.watch(currentUserProvider);
  if (user == null) return [];
  return ref.watch(bidServiceProvider).listOpenRfqForVendor(user);
});
