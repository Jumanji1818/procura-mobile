import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/db/app_database.dart';
import '../../domain/models/auth_user.dart';
import '../../domain/services/auth_gateway.dart';
import '../../domain/services/auth_service.dart';
import 'session_notifier.dart';

export 'session_notifier.dart';

final databaseProvider = Provider<AppDatabase>((ref) {
  final db = AppDatabase();
  ref.onDispose(db.close);
  return db;
});

final authServiceProvider = Provider<AuthService>((ref) {
  return AuthService(ref.watch(databaseProvider));
});

final authGatewayProvider = Provider<AuthGateway>((ref) {
  return ref.watch(authServiceProvider);
});

final sessionProvider = StateNotifierProvider<SessionNotifier, AuthUser?>((ref) {
  return SessionNotifier(ref.watch(authGatewayProvider));
});

final currentUserProvider = Provider<AuthUser?>((ref) => ref.watch(sessionProvider));
