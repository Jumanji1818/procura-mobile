import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/models/auth_user.dart';
import '../../domain/services/auth_gateway.dart';

/// Reactive session — updates on login/logout so role menus switch correctly.
class SessionNotifier extends StateNotifier<AuthUser?> {
  SessionNotifier(this._auth) : super(_auth.currentUser);

  final AuthGateway _auth;

  Future<void> login({required String email, required String password}) async {
    final user = await _auth.login(email: email, password: password);
    _auth.setSession(user);
    state = user;
  }

  Future<void> register({
    required String email,
    required String displayName,
    required String password,
    required bool asVendor,
    List<String> categoryIds = const [],
    String? businessName,
    String? location,
  }) async {
    final user = await _auth.register(
      email: email,
      displayName: displayName,
      password: password,
      asVendor: asVendor,
      categoryIds: categoryIds,
      businessName: businessName,
      location: location,
    );
    _auth.setSession(user);
    state = user;
  }

  void logout() {
    _auth.logout();
    state = null;
  }
}
