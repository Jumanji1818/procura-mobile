import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/procura_theme.dart';
import '../../domain/models/procurement_status.dart';
import '../../domain/models/role.dart';
import '../auth/auth_providers.dart';
import 'new_request_page.dart';
import 'request_detail_page.dart';
import 'requests_providers.dart';

class RequestsPage extends ConsumerWidget {
  const RequestsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    final asyncList = ref.watch(requestsListProvider);
    final canCreate = user != null &&
        (user.role == UserRole.requestOfficer || user.role == UserRole.procurementOfficer);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Requests'),
        actions: [
          if (canCreate)
            IconButton(
              tooltip: 'New request',
              onPressed: () async {
                await Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const NewRequestPage()),
                );
                ref.invalidate(requestsListProvider);
              },
              icon: const Icon(Icons.add, color: ProcuraColors.gold),
            ),
        ],
      ),
      body: asyncList.when(
        loading: () => const Center(child: CircularProgressIndicator(color: ProcuraColors.gold)),
        error: (e, _) => Center(child: Text('Could not load requests: $e')),
        data: (items) {
          if (items.isEmpty) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.description_outlined, size: 48, color: ProcuraColors.muted),
                  const SizedBox(height: 12),
                  const Text('No requests yet', style: TextStyle(color: ProcuraColors.muted)),
                  if (canCreate) ...[
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () async {
                        await Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const NewRequestPage()),
                        );
                        ref.invalidate(requestsListProvider);
                      },
                      child: const Text('Create request'),
                    ),
                  ],
                ],
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final p = items[i];
              final st = ProcurementStatus.fromStorage(p.status);
              return Card(
                child: ListTile(
                  title: Text(p.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(
                    '${p.number} · ${st.label}',
                    style: const TextStyle(color: ProcuraColors.muted, fontSize: 12),
                  ),
                  trailing: const Icon(Icons.chevron_right, color: ProcuraColors.muted),
                  onTap: () async {
                    await Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => RequestDetailPage(id: p.id)),
                    );
                    ref.invalidate(requestsListProvider);
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
