import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:printing/printing.dart';

import '../../core/theme/procura_theme.dart';
import '../../data/db/app_database.dart';
import '../../domain/models/procurement_status.dart';
import '../../domain/models/role.dart';
import '../../domain/services/po_pdf.dart';
import '../../domain/workflow/state_machine.dart';
import '../../domain/workflow/workflow_action.dart';
import '../../shared/utils/money.dart';
import '../auth/auth_providers.dart';
import '../bidding/bid_providers.dart';
import '../bidding/evaluation_page.dart';
import '../delivery/fulfillment_providers.dart';
import '../finance/finance_providers.dart';
import 'new_request_page.dart';
import 'requests_providers.dart';

class RequestDetailPage extends ConsumerStatefulWidget {
  final String id;
  const RequestDetailPage({super.key, required this.id});

  @override
  ConsumerState<RequestDetailPage> createState() => _RequestDetailPageState();
}

class _RequestDetailPageState extends ConsumerState<RequestDetailPage> {
  String? _error;
  bool _busy = false;
  late Future<Procurement?> _future;
  late Future<List<AuditLog>> _history;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  /// Refetches the request and its history once (not on every rebuild).
  void _reload() {
    final svc = ref.read(procurementServiceProvider);
    _future = svc.getById(widget.id);
    _history = svc.history(widget.id);
  }

  /// Runs an action with a busy guard, then refreshes this page and the lists.
  Future<void> _run(Future<void> Function() job) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await job();
      ref.invalidate(requestsListProvider);
      if (mounted) setState(_reload);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<String?> _askNote(String title, String label) async {
    final c = TextEditingController();
    final res = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: c,
          maxLines: 3,
          decoration: InputDecoration(labelText: label),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('Confirm')),
        ],
      ),
    );
    return res;
  }

  Future<int?> _pickBiddingDays() {
    return showDialog<int>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('Bidding stays open for'),
        children: [
          for (final d in const [3, 7, 14])
            SimpleDialogOption(
              onPressed: () => Navigator.pop(ctx, d),
              child: Text('$d days'),
            ),
        ],
      ),
    );
  }

  Future<({int received, int damaged, int missing})?> _askReceipt(int ordered) {
    final received = TextEditingController(text: '$ordered');
    final damaged = TextEditingController(text: '0');
    final missing = TextEditingController(text: '0');
    return showDialog<({int received, int damaged, int missing})>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Goods received'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Ordered: $ordered', style: const TextStyle(color: ProcuraColors.muted)),
            const SizedBox(height: 12),
            TextField(
              controller: received,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Quantity received'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: damaged,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Of which damaged'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: missing,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Missing'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, (
              received: int.tryParse(received.text.trim()) ?? 0,
              damaged: int.tryParse(damaged.text.trim()) ?? 0,
              missing: int.tryParse(missing.text.trim()) ?? 0,
            )),
            child: const Text('Confirm'),
          ),
        ],
      ),
    );
  }

  Future<void> _openPoPdf(Procurement p) async {
    final ful = ref.read(fulfillmentServiceProvider);
    final po = await ful.poFor(p.id);
    if (po == null) throw Exception('No purchase order has been issued yet.');
    final vendor = await ful.vendorName(po.vendorId);
    final bytes = await PoPdf.build(po: po, procurement: p, vendorName: vendor);
    await Printing.layoutPdf(onLayout: (_) async => bytes, name: po.number);
  }

  String _actionLabel(String a) => switch (a) {
        'create' => 'Created',
        'edit' => 'Edited',
        'submitForApproval' => 'Submitted for approval',
        'approveDepartment' => 'Approved by department',
        'requestChanges' => 'Changes requested',
        'reject' => 'Rejected',
        'publishRfq' => 'Opened for bidding',
        'openEvaluation' => 'Bidding closed, evaluating',
        'submit_bid' => 'Bid received',
        'recommend_vendor' => 'Vendor recommended',
        'award' => 'Awarded',
        'issuePo' => 'Purchase order issued',
        'markPreparing' => 'Vendor preparing order',
        'markDispatched' => 'Dispatched',
        'markInTransit' => 'In transit',
        'markDelivered' => 'Delivered',
        'receiveGoods' => 'Goods received',
        'submitInvoice' => 'Invoice submitted',
        'auto_payment_review' => 'Sent to payment review (match failed)',
        'holdPaymentReview' => 'Payment held for review',
        'approvePayment' => 'Payment approved',
        'complete' => 'Completed',
        _ => a,
      };

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Request')),
      body: FutureBuilder<Procurement?>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator(color: ProcuraColors.gold));
          }
          final p = snap.data;
          if (p == null || user == null) {
            return const Center(child: Text('Request not found'));
          }
          final st = ProcurementStatus.fromStorage(p.status);
          final role = user.role;
          final isStaffBuyer = role == UserRole.procurementOfficer || role == UserRole.orgAdmin;

          final canSubmit = p.createdByUserId == user.id &&
              ProcurementStateMachine.can(
                from: st,
                action: WorkflowAction.submitForApproval,
                role: role,
              );
          final canEdit = p.createdByUserId == user.id &&
              (st == ProcurementStatus.draft || st == ProcurementStatus.changesRequested);
          final canApprove = ProcurementStateMachine.can(
                from: st,
                action: WorkflowAction.approveDepartment,
                role: role,
              ) &&
              p.createdByUserId != user.id &&
              user.departmentId == p.departmentId;
          final canReceive = st == ProcurementStatus.delivered &&
              (role == UserRole.requestOfficer || role == UserRole.procurementOfficer);
          final canSeePo = st.index >= ProcurementStatus.poIssued.index &&
              role != UserRole.vendor &&
              role != UserRole.pending;

          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Text(p.number, style: const TextStyle(color: ProcuraColors.muted, fontSize: 13)),
              const SizedBox(height: 4),
              Text(p.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: ProcuraColors.goldSoft,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(st.label, style: const TextStyle(color: ProcuraColors.gold, fontSize: 12)),
                ),
              ),
              const SizedBox(height: 16),
              Text(p.itemDescription),
              const SizedBox(height: 12),
              _row('Quantity', '${p.quantity} ${p.unit}'),
              if (p.budgetKobo != null) _row('Budget', formatNaira(p.budgetKobo!)),
              if (p.deliveryLocation != null) _row('Location', p.deliveryLocation!),
              if (p.closingDate != null && st == ProcurementStatus.bidding)
                _row('Bids close', DateFormat('d MMM y, HH:mm').format(p.closingDate!.toLocal())),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(color: ProcuraColors.danger)),
              ],
              const SizedBox(height: 24),

              if (canEdit)
                OutlinedButton(
                  onPressed: _busy
                      ? null
                      : () async {
                          await Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => NewRequestPage(existing: p)),
                          );
                          ref.invalidate(requestsListProvider);
                          if (mounted) setState(_reload);
                        },
                  child: const Text('Edit request'),
                ),
              if (canSubmit) ...[
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: _busy
                      ? null
                      : () => _run(() => ref
                          .read(procurementServiceProvider)
                          .submitForApproval(procurementId: widget.id, actor: user)),
                  child: const Text('Submit for approval'),
                ),
              ],
              if (canApprove) ...[
                ElevatedButton(
                  onPressed: _busy
                      ? null
                      : () => _run(() => ref
                          .read(procurementServiceProvider)
                          .approveDepartment(procurementId: widget.id, actor: user)),
                  child: const Text('Approve'),
                ),
                const SizedBox(height: 8),
                OutlinedButton(
                  onPressed: _busy
                      ? null
                      : () async {
                          final note = await _askNote('Request changes', 'What needs to change?');
                          if (note == null) return;
                          await _run(() => ref.read(procurementServiceProvider).requestChanges(
                                procurementId: widget.id,
                                actor: user,
                                note: note,
                              ));
                        },
                  child: const Text('Request changes'),
                ),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: _busy
                      ? null
                      : () async {
                          final note = await _askNote('Reject request', 'Reason for rejection');
                          if (note == null) return;
                          await _run(() => ref.read(procurementServiceProvider).reject(
                                procurementId: widget.id,
                                actor: user,
                                note: note,
                              ));
                        },
                  child: const Text('Reject', style: TextStyle(color: ProcuraColors.danger)),
                ),
              ],

              if (st == ProcurementStatus.rfqPublished && isStaffBuyer) ...[
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: _busy
                      ? null
                      : () async {
                          final days = await _pickBiddingDays();
                          if (days == null) return;
                          await _run(() => ref.read(bidServiceProvider).publishRfq(
                                actor: user,
                                procurementId: widget.id,
                                closingDate: DateTime.now().toUtc().add(Duration(days: days)),
                              ));
                        },
                  child: const Text('Open for bidding'),
                ),
              ],
              if (st == ProcurementStatus.bidding && isStaffBuyer) ...[
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: _busy
                      ? null
                      : () => _run(() => ref
                          .read(bidServiceProvider)
                          .openEvaluation(actor: user, procurementId: widget.id)),
                  child: const Text('Close bidding & evaluate'),
                ),
              ],
              if (st == ProcurementStatus.evaluating && isStaffBuyer) ...[
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () async {
                    await Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => EvaluationPage(
                          procurementId: widget.id,
                          mode: EvaluationMode.procurement,
                        ),
                      ),
                    );
                    ref.invalidate(requestsListProvider);
                    if (mounted) setState(_reload);
                  },
                  child: const Text('Open evaluation & scores'),
                ),
              ],
              if (st == ProcurementStatus.evaluating && role == UserRole.approvingAuthority) ...[
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () async {
                    await Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => EvaluationPage(
                          procurementId: widget.id,
                          mode: EvaluationMode.approver,
                        ),
                      ),
                    );
                    ref.invalidate(requestsListProvider);
                    if (mounted) setState(_reload);
                  },
                  child: const Text('Review bids & decide'),
                ),
              ],
              if (st == ProcurementStatus.awarded && isStaffBuyer) ...[
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: _busy
                      ? null
                      : () => _run(() async {
                            await ref
                                .read(fulfillmentServiceProvider)
                                .issuePo(actor: user, procurementId: widget.id);
                          }),
                  child: const Text('Issue purchase order'),
                ),
              ],
              if (canReceive) ...[
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: _busy
                      ? null
                      : () async {
                          final r = await _askReceipt(p.quantity);
                          if (r == null) return;
                          await _run(() => ref.read(fulfillmentServiceProvider).receiveGoods(
                                actor: user,
                                procurementId: widget.id,
                                qtyReceived: r.received,
                                qtyDamaged: r.damaged,
                                qtyMissing: r.missing,
                              ));
                        },
                  child: const Text('Record goods received'),
                ),
              ],
              if (st == ProcurementStatus.paid && isStaffBuyer) ...[
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: _busy
                      ? null
                      : () => _run(() => ref
                          .read(financeServiceProvider)
                          .complete(actor: user, procurementId: widget.id)),
                  child: const Text('Mark completed'),
                ),
              ],
              if (canSeePo) ...[
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: _busy ? null : () => _run(() => _openPoPdf(p)),
                  icon: const Icon(Icons.picture_as_pdf_outlined),
                  label: const Text('View / print purchase order (PDF)'),
                ),
              ],

              const SizedBox(height: 28),
              const Text('History',
                  style: TextStyle(fontWeight: FontWeight.w600, color: ProcuraColors.gold)),
              const SizedBox(height: 8),
              FutureBuilder<List<AuditLog>>(
                future: _history,
                builder: (context, hs) {
                  final rows = hs.data;
                  if (rows == null) return const SizedBox.shrink();
                  if (rows.isEmpty) {
                    return const Text('No activity yet.', style: TextStyle(color: ProcuraColors.muted));
                  }
                  return Column(
                    children: [
                      for (final a in rows.reversed)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Padding(
                                padding: EdgeInsets.only(top: 3, right: 10),
                                child: Icon(Icons.circle, size: 8, color: ProcuraColors.gold),
                              ),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(_actionLabel(a.action)),
                                    Text(
                                      '${a.actorName} · ${DateFormat('d MMM y, HH:mm').format(a.createdAt.toLocal())}',
                                      style: const TextStyle(color: ProcuraColors.muted, fontSize: 12),
                                    ),
                                    if (a.detail != null &&
                                        a.detail!.isNotEmpty &&
                                        (a.action == 'requestChanges' ||
                                            a.action == 'reject' ||
                                            a.action == 'holdPaymentReview' ||
                                            a.action == 'auto_payment_review'))
                                      Padding(
                                        padding: const EdgeInsets.only(top: 2),
                                        child: Text(a.detail!, style: const TextStyle(fontSize: 13)),
                                      ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _row(String k, String v) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 100, child: Text(k, style: const TextStyle(color: ProcuraColors.muted))),
          Expanded(child: Text(v)),
        ],
      ),
    );
  }
}
