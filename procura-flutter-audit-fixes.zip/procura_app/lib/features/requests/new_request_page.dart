import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/procura_theme.dart';
import '../../data/db/app_database.dart';
import '../../domain/models/role.dart';
import '../../domain/services/procurement_service.dart';
import '../auth/auth_providers.dart';
import 'requests_providers.dart';

/// Create a request, or edit a draft / a request sent back for changes.
class NewRequestPage extends ConsumerStatefulWidget {
  final Procurement? existing;
  const NewRequestPage({super.key, this.existing});

  @override
  ConsumerState<NewRequestPage> createState() => _NewRequestPageState();
}

class _NewRequestPageState extends ConsumerState<NewRequestPage> {
  final _title = TextEditingController();
  final _desc = TextEditingController();
  final _qty = TextEditingController(text: '1');
  final _unit = TextEditingController(text: 'unit');
  final _budget = TextEditingController();
  final _location = TextEditingController();
  String? _categoryId;
  String? _departmentId;
  String? _error;
  bool _busy = false;

  /// Set once a new request has been saved, so a retry updates it instead of
  /// creating a duplicate.
  String? _createdId;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    if (e != null) {
      _title.text = e.title;
      _desc.text = e.itemDescription;
      _qty.text = '${e.quantity}';
      _unit.text = e.unit;
      if (e.budgetKobo != null) {
        _budget.text = (e.budgetKobo! / 100).toStringAsFixed(2);
      }
      _location.text = e.deliveryLocation ?? '';
      _categoryId = e.categoryId;
      _departmentId = e.departmentId;
    }
  }

  @override
  void dispose() {
    _title.dispose();
    _desc.dispose();
    _qty.dispose();
    _unit.dispose();
    _budget.dispose();
    _location.dispose();
    super.dispose();
  }

  Future<void> _save({required bool submit}) async {
    final user = ref.read(currentUserProvider);
    if (user == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final qty = int.tryParse(_qty.text.trim()) ?? 0;
      int? budgetKobo;
      if (_budget.text.trim().isNotEmpty) {
        final naira = double.tryParse(_budget.text.trim().replaceAll(',', ''));
        if (naira == null || naira < 0) {
          throw ProcurementException('Budget must be a valid amount in naira.');
        }
        budgetKobo = (naira * 100).round();
      }
      final dept = _departmentId ?? user.departmentId;
      if (dept == null) {
        throw ProcurementException('Select a department.');
      }
      if (_categoryId == null) {
        throw ProcurementException('Select a category.');
      }

      final svc = ref.read(procurementServiceProvider);
      final existingId = widget.existing?.id ?? _createdId;
      final String id;
      if (existingId != null) {
        id = existingId;
        await svc.updateRequest(
          actor: user,
          procurementId: id,
          title: _title.text,
          itemDescription: _desc.text,
          categoryId: _categoryId!,
          quantity: qty,
          unit: _unit.text,
          budgetKobo: budgetKobo,
          deliveryLocation: _location.text,
        );
      } else {
        id = await svc.createRequest(
          actor: user,
          title: _title.text,
          itemDescription: _desc.text,
          categoryId: _categoryId!,
          departmentId: dept,
          quantity: qty,
          unit: _unit.text,
          budgetKobo: budgetKobo,
          deliveryLocation: _location.text,
        );
        _createdId = id;
      }
      if (submit) {
        await svc.submitForApproval(procurementId: id, actor: user);
      }
      if (!mounted) return;
      Navigator.of(context).pop();
    } on ProcurementException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider);
    final cats = ref.watch(categoriesProvider);
    final depts = ref.watch(departmentsProvider);
    final editing = widget.existing != null;
    final lockDept = editing || (user?.role == UserRole.requestOfficer && user?.departmentId != null);

    return Scaffold(
      appBar: AppBar(title: Text(editing ? 'Edit request' : 'New request')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(controller: _title, decoration: const InputDecoration(labelText: 'Title')),
          const SizedBox(height: 12),
          TextField(
            controller: _desc,
            decoration: const InputDecoration(labelText: 'Item description'),
            maxLines: 3,
          ),
          const SizedBox(height: 12),
          cats.when(
            loading: () => const LinearProgressIndicator(),
            error: (e, _) => Text('$e'),
            data: (list) => DropdownButtonFormField<String>(
              value: _categoryId,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Category'),
              items: list
                  .map((c) => DropdownMenuItem(
                        value: c.id,
                        child: Text('${c.parentName} · ${c.subcategory}',
                            overflow: TextOverflow.ellipsis),
                      ))
                  .toList(),
              onChanged: (v) => setState(() => _categoryId = v),
            ),
          ),
          const SizedBox(height: 12),
          depts.when(
            loading: () => const SizedBox.shrink(),
            error: (e, _) => Text('$e'),
            data: (list) {
              final initial = lockDept ? (_departmentId ?? user?.departmentId) : _departmentId;
              return DropdownButtonFormField<String>(
                value: initial,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Department'),
                items: list
                    .map((d) => DropdownMenuItem(value: d.id, child: Text(d.name)))
                    .toList(),
                onChanged: lockDept ? null : (v) => setState(() => _departmentId = v),
              );
            },
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _qty,
                  decoration: const InputDecoration(labelText: 'Quantity'),
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(controller: _unit, decoration: const InputDecoration(labelText: 'Unit')),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _budget,
            decoration: const InputDecoration(labelText: 'Budget (₦, optional)'),
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _location,
            decoration: const InputDecoration(labelText: 'Delivery location (optional)'),
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: ProcuraColors.danger)),
          ],
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _busy ? null : () => _save(submit: true),
            child: Text(_busy ? 'Saving…' : (editing ? 'Save & resubmit' : 'Submit for approval')),
          ),
          const SizedBox(height: 8),
          OutlinedButton(
            onPressed: _busy ? null : () => _save(submit: false),
            child: Text(editing ? 'Save changes' : 'Save as draft'),
          ),
        ],
      ),
    );
  }
}
