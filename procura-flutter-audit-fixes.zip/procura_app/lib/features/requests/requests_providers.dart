import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/db/app_database.dart';
import '../../domain/services/procurement_service.dart';
import '../../domain/services/workflow_service.dart';
import '../auth/auth_providers.dart';

final workflowServiceProvider = Provider<WorkflowService>((ref) {
  return WorkflowService(ref.watch(databaseProvider));
});

final procurementServiceProvider = Provider<ProcurementService>((ref) {
  return ProcurementService(
    ref.watch(databaseProvider),
    ref.watch(workflowServiceProvider),
  );
});

final requestsListProvider = FutureProvider<List<Procurement>>((ref) async {
  final user = ref.watch(currentUserProvider);
  if (user == null) return [];
  return ref.watch(procurementServiceProvider).listFor(user);
});

final categoriesProvider = FutureProvider((ref) async {
  final db = ref.watch(databaseProvider);
  return db.select(db.categories).get();
});

final departmentsProvider = FutureProvider((ref) async {
  final db = ref.watch(databaseProvider);
  return db.select(db.departments).get();
});
