import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/db/app_database.dart';
import '../../domain/services/admin_service.dart';
import '../auth/auth_providers.dart';

final adminServiceProvider = Provider<AdminService>((ref) {
  return AdminService(ref.watch(databaseProvider));
});

final categoryBudgetsProvider = FutureProvider.autoDispose<List<CategoryBudget>>((ref) {
  return ref.watch(adminServiceProvider).budgetsForYear();
});
