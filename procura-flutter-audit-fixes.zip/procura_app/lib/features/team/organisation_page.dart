import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/procura_theme.dart';
import '../../data/db/app_database.dart';
import '../../domain/services/scoring_engine.dart';
import '../../shared/utils/money.dart';
import '../auth/auth_providers.dart';
import '../bidding/bid_providers.dart';
import '../requests/requests_providers.dart';
import 'admin_providers.dart';

/// Org Admin: departments, categories, yearly category budgets, scoring weights.
class OrganisationPage extends ConsumerStatefulWidget {
  const OrganisationPage({super.key});

  @override
  ConsumerState<OrganisationPage> createState() => _OrganisationPageState();
}

class _OrganisationPageState extends ConsumerState<OrganisationPage> {
  static const _weightLabels = [
    'Price',
    'Delivery time',
    'On-time history',
    'Vendor rating',
    'Documents complete',
  ];
  final List<TextEditingController> _w = List.generate(5, (_) => TextEditingController());
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _loadWeights();
  }

  @override
  void dispose() {
    for (final c in _w) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _loadWeights() async {
    final w = await ref.read(bidServiceProvider).loadWeights();
    final values = [w.price, w.delivery, w.onTime, w.rating, w.compliance];
    if (!mounted) return;
    setState(() {
      for (var i = 0; i < 5; i++) {
        _w[i].text = (values[i] * 100).toStringAsFixed(0);
      }
    });
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _run(Future<void> Function() job, {String? done}) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await job();
      if (done != null) _toast(done);
    } catch (e) {
      _toast('$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<List<String>?> _prompt(String title, List<String> labels) {
    final controllers = labels.map((_) => TextEditingController()).toList();
    return showDialog<List<String>>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (var i = 0; i < labels.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: TextField(
                  controller: controllers[i],
                  decoration: InputDecoration(labelText: labels[i]),
                ),
              ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, controllers.map((c) => c.text).toList()),
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _addDepartment() async {
    final user = ref.read(currentUserProvider);
    final v = await _prompt('New department', ['Name', 'Code (e.g. HR)']);
    if (v == null || user == null) return;
    await _run(() async {
      await ref.read(adminServiceProvider).addDepartment(actor: user, name: v[0], code: v[1]);
      ref.invalidate(departmentsProvider);
    }, done: 'Department added.');
  }

  Future<void> _addCategory() async {
    final user = ref.read(currentUserProvider);
    final v = await _prompt('New category', ['Category (e.g. Medical & Healthcare)', 'Subcategory']);
    if (v == null || user == null) return;
    await _run(() async {
      await ref.read(adminServiceProvider).addCategory(actor: user, parentName: v[0], subcategory: v[1]);
      ref.invalidate(categoriesProvider);
    }, done: 'Category added.');
  }

  Future<void> _editBudget(Category c, CategoryBudget? current) async {
    final user = ref.read(currentUserProvider);
    final initial = current == null ? '' : (current.amountKobo / 100).toStringAsFixed(0);
    final controller = TextEditingController(text: initial);
    final res = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('${c.parentName} · ${c.subcategory}'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(labelText: 'Budget for ${DateTime.now().year} (₦)'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Save')),
        ],
      ),
    );
    if (res == null || user == null) return;
    final naira = double.tryParse(res.replaceAll(',', ''));
    if (naira == null) {
      _toast('Enter a valid amount.');
      return;
    }
    await _run(() async {
      await ref.read(adminServiceProvider).setCategoryBudget(
            actor: user,
            categoryId: c.id,
            amountKobo: (naira * 100).round(),
          );
      ref.invalidate(categoryBudgetsProvider);
    }, done: 'Budget saved.');
  }

  Future<void> _saveWeights() async {
    final user = ref.read(currentUserProvider);
    if (user == null) return;
    final vals = _w.map((c) => double.tryParse(c.text.trim())).toList();
    if (vals.any((v) => v == null || v < 0)) {
      _toast('Enter each weight as a number, zero or more.');
      return;
    }
    final w = ScoringWeights(
      price: vals[0]! / 100,
      delivery: vals[1]! / 100,
      onTime: vals[2]! / 100,
      rating: vals[3]! / 100,
      compliance: vals[4]! / 100,
    );
    await _run(
      () => ref.read(adminServiceProvider).saveWeights(actor: user, weights: w),
      done: 'Scoring weights saved. They are normalised, so they need not add up to 100.',
    );
  }

  Widget _sectionTitle(String t, {VoidCallback? onAdd}) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 8),
        child: Row(
          children: [
            Expanded(
              child: Text(t, style: const TextStyle(fontWeight: FontWeight.w600, color: ProcuraColors.gold)),
            ),
            if (onAdd != null)
              IconButton(
                tooltip: 'Add',
                onPressed: _busy ? null : onAdd,
                icon: const Icon(Icons.add_circle_outline, color: ProcuraColors.gold),
              ),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final depts = ref.watch(departmentsProvider).valueOrNull ?? const <Department>[];
    final cats = ref.watch(categoriesProvider).valueOrNull ?? const <Category>[];
    final budgets = ref.watch(categoryBudgetsProvider).valueOrNull ?? const <CategoryBudget>[];
    final budgetByCat = {for (final b in budgets) b.categoryId: b};

    return Scaffold(
      appBar: AppBar(title: const Text('Organisation')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _sectionTitle('Departments', onAdd: _addDepartment),
          for (final d in depts)
            Card(child: ListTile(title: Text(d.name), subtitle: Text(d.code))),
          _sectionTitle('Categories & ${DateTime.now().year} budgets', onAdd: _addCategory),
          for (final c in cats)
            Card(
              child: ListTile(
                title: Text('${c.parentName} · ${c.subcategory}'),
                subtitle: Text(
                  budgetByCat[c.id] == null
                      ? 'No budget set (not enforced)'
                      : '${formatNaira(budgetByCat[c.id]!.spentKobo)} spent of ${formatNaira(budgetByCat[c.id]!.amountKobo)}',
                  style: const TextStyle(color: ProcuraColors.muted, fontSize: 12),
                ),
                trailing: const Icon(Icons.edit_outlined, size: 18),
                onTap: _busy ? null : () => _editBudget(c, budgetByCat[c.id]),
              ),
            ),
          _sectionTitle('Bid scoring weights (%)'),
          for (var i = 0; i < 5; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: TextField(
                controller: _w[i],
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: _weightLabels[i]),
              ),
            ),
          const SizedBox(height: 4),
          ElevatedButton(
            onPressed: _busy ? null : _saveWeights,
            child: const Text('Save weights'),
          ),
        ],
      ),
    );
  }
}
