import 'package:flutter/material.dart';
import 'package:drift/drift.dart' show OrderingTerm;
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/procura_theme.dart';
import '../../data/db/app_database.dart';
import '../../domain/models/role.dart';
import '../auth/auth_providers.dart';
import '../requests/requests_providers.dart';
import 'organisation_page.dart';

final teamProvider = FutureProvider.autoDispose<List<User>>((ref) async {
  final db = ref.watch(databaseProvider);
  final all = await (db.select(db.users)..orderBy([(u) => OrderingTerm.asc(u.displayName)])).get();
  return all.where((u) => UserRole.fromStorage(u.role) != UserRole.vendor).toList();
});

/// Org Admin: assign roles/departments to staff and enable/disable accounts.
class TeamPage extends ConsumerStatefulWidget {
  const TeamPage({super.key});

  @override
  ConsumerState<TeamPage> createState() => _TeamPageState();
}

class _TeamPageState extends ConsumerState<TeamPage> {
  bool _busy = false;

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _assign(User target, List<Department> depts) async {
    final me = ref.read(currentUserProvider);
    if (me == null || _busy) return;

    const assignable = [
      UserRole.requestOfficer,
      UserRole.departmentHead,
      UserRole.procurementOfficer,
      UserRole.financeOfficer,
      UserRole.approvingAuthority,
      UserRole.orgAdmin,
    ];
    var role = UserRole.fromStorage(target.role);
    if (!assignable.contains(role)) role = UserRole.requestOfficer;
    String? dept = target.departmentId;
    String? err;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: Text(target.displayName),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<UserRole>(
                value: role,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Role'),
                items: assignable.map((r) => DropdownMenuItem(value: r, child: Text(r.label))).toList(),
                onChanged: (v) => setD(() => role = v ?? role),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String?>(
                value: dept,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Department'),
                items: [
                  const DropdownMenuItem<String?>(value: null, child: Text('None')),
                  ...depts.map((d) => DropdownMenuItem<String?>(value: d.id, child: Text(d.name))),
                ],
                onChanged: (v) => setD(() => dept = v),
              ),
              if (err != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(err!, style: const TextStyle(color: ProcuraColors.danger, fontSize: 12)),
                ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            TextButton(
              onPressed: () {
                if ((role == UserRole.requestOfficer || role == UserRole.departmentHead) && dept == null) {
                  setD(() => err = '${role.label} needs a department.');
                  return;
                }
                Navigator.pop(ctx, true);
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;

    setState(() => _busy = true);
    try {
      await ref.read(authServiceProvider).assignRole(
            actorUserId: me.id,
            targetUserId: target.id,
            role: role,
            departmentId: dept,
            clearDepartment: dept == null,
          );
      ref.invalidate(teamProvider);
      _toast('Role updated. ${target.displayName} must sign in again to see it.');
    } catch (e) {
      _toast('$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toggleActive(User target) async {
    final me = ref.read(currentUserProvider);
    if (me == null || _busy) return;
    setState(() => _busy = true);
    try {
      await ref.read(authServiceProvider).setActive(
            actorUserId: me.id,
            targetUserId: target.id,
            active: !target.isActive,
          );
      ref.invalidate(teamProvider);
    } catch (e) {
      _toast('$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final team = ref.watch(teamProvider);
    final depts = ref.watch(departmentsProvider).valueOrNull ?? const <Department>[];
    final deptName = {for (final d in depts) d.id: d.name};

    return Scaffold(
      appBar: AppBar(
        title: const Text('Team'),
        actions: [
          IconButton(
            tooltip: 'Organisation settings',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const OrganisationPage()),
            ),
          ),
        ],
      ),
      body: team.when(
        loading: () => const Center(child: CircularProgressIndicator(color: ProcuraColors.gold)),
        error: (e, _) => Center(child: Text('$e')),
        data: (users) {
          if (users.isEmpty) {
            return const Center(child: Text('No staff accounts yet.'));
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: users.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final u = users[i];
              final role = UserRole.fromStorage(u.role);
              return Card(
                child: ListTile(
                  title: Text(u.displayName),
                  subtitle: Text(
                    '${u.email}\n${role.label}'
                    '${u.departmentId != null ? ' · ${deptName[u.departmentId] ?? ''}' : ''}'
                    '${u.isActive ? '' : ' · disabled'}',
                    style: const TextStyle(color: ProcuraColors.muted, fontSize: 12),
                  ),
                  isThreeLine: true,
                  trailing: PopupMenuButton<String>(
                    enabled: !_busy,
                    onSelected: (v) => v == 'role' ? _assign(u, depts) : _toggleActive(u),
                    itemBuilder: (_) => [
                      const PopupMenuItem(value: 'role', child: Text('Assign role / department')),
                      PopupMenuItem(value: 'active', child: Text(u.isActive ? 'Disable account' : 'Enable account')),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
