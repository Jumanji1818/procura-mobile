import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../core/theme/procura_theme.dart';
import '../../domain/models/role.dart';
import '../../domain/services/notification_service.dart';
import '../auth/auth_providers.dart';
import '../requests/request_detail_page.dart';
import 'notification_providers.dart';

class NotificationsPage extends ConsumerWidget {
  const NotificationsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    final async = ref.watch(notificationsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          TextButton(
            onPressed: user == null
                ? null
                : () async {
                    await ref.read(notificationServiceProvider).markAllRead(user.id);
                    ref.invalidate(notificationsProvider);
                    ref.invalidate(unreadCountProvider);
                  },
            child: const Text('Mark all read'),
          ),
        ],
      ),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator(color: ProcuraColors.gold)),
        error: (e, _) => Center(child: Text('$e')),
        data: (items) {
          if (items.isEmpty) {
            return const Center(
              child: Text('Nothing yet.', style: TextStyle(color: ProcuraColors.muted)),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final n = items[i];
              final procId = NotificationService.procurementIdFromHref(n.href);
              final canOpen = procId != null && user != null && user.role != UserRole.vendor;
              return Card(
                child: ListTile(
                  leading: Icon(
                    n.read ? Icons.notifications_none : Icons.notifications_active,
                    color: n.read ? ProcuraColors.muted : ProcuraColors.gold,
                  ),
                  title: Text(n.title,
                      style: TextStyle(fontWeight: n.read ? FontWeight.normal : FontWeight.w600)),
                  subtitle: Text(
                    '${n.body ?? ''}\n${DateFormat('d MMM y, HH:mm').format(n.createdAt.toLocal())}',
                    style: const TextStyle(color: ProcuraColors.muted, fontSize: 12),
                  ),
                  isThreeLine: true,
                  onTap: () async {
                    await ref.read(notificationServiceProvider).markRead(n.id);
                    ref.invalidate(notificationsProvider);
                    ref.invalidate(unreadCountProvider);
                    if (canOpen && context.mounted) {
                      await Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => RequestDetailPage(id: procId)),
                      );
                    }
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
