import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/db/app_database.dart';
import '../../domain/services/notification_service.dart';
import '../auth/auth_providers.dart';

final notificationServiceProvider = Provider<NotificationService>((ref) {
  return NotificationService(ref.watch(databaseProvider));
});

/// Re-queried whenever the screen showing it is rebuilt from scratch.
final unreadCountProvider = FutureProvider.autoDispose<int>((ref) async {
  final user = ref.watch(currentUserProvider);
  if (user == null) return 0;
  return ref.watch(notificationServiceProvider).unreadCount(user.id);
});

final notificationsProvider = FutureProvider.autoDispose<List<Notification>>((ref) async {
  final user = ref.watch(currentUserProvider);
  if (user == null) return <Notification>[];
  return ref.watch(notificationServiceProvider).listFor(user.id);
});
