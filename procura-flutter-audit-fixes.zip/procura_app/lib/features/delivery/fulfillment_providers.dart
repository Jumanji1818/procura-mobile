import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/db/app_database.dart';
import '../../domain/services/fulfillment_service.dart';
import '../auth/auth_providers.dart';
import '../requests/requests_providers.dart';

final fulfillmentServiceProvider = Provider<FulfillmentService>((ref) {
  return FulfillmentService(
    ref.watch(databaseProvider),
    ref.watch(workflowServiceProvider),
  );
});

final vendorOrdersProvider = FutureProvider<List<PurchaseOrder>>((ref) async {
  final user = ref.watch(currentUserProvider);
  if (user == null) return [];
  return ref.watch(fulfillmentServiceProvider).listVendorOrders(user);
});
