import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/procura_theme.dart';
import '../../domain/models/procurement_status.dart';
import '../../shared/utils/money.dart';
import '../../domain/workflow/workflow_action.dart';
import '../auth/auth_providers.dart';
import 'fulfillment_providers.dart';
import '../finance/finance_providers.dart';

class OrdersPage extends ConsumerWidget {
  const OrdersPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(vendorOrdersProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Orders')),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator(color: ProcuraColors.gold)),
        error: (e, _) => Center(child: Text('$e')),
        data: (orders) {
          if (orders.isEmpty) {
            return const Center(
              child: Text('No purchase orders yet.', style: TextStyle(color: ProcuraColors.muted)),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: orders.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final po = orders[i];
              return Card(
                child: ListTile(
                  title: Text(po.number),
                  subtitle: Text(
                    '${formatNaira(po.totalKobo)} · ${ProcurementStatus.fromStorage(po.status).label}',
                    style: const TextStyle(color: ProcuraColors.muted, fontSize: 12),
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => OrderDetailPage(
                          procurementId: po.procurementId,
                          poNumber: po.number,
                        ),
                      ),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class OrderDetailPage extends ConsumerStatefulWidget {
  final String procurementId;
  final String poNumber;
  const OrderDetailPage({super.key, required this.procurementId, required this.poNumber});

  @override
  ConsumerState<OrderDetailPage> createState() => _OrderDetailPageState();
}

class _OrderDetailPageState extends ConsumerState<OrderDetailPage> {
  String? _error;
  bool _busy = false;
  String? _status;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final p = await ref.read(fulfillmentServiceProvider).getProcurement(widget.procurementId);
    if (mounted && p != null) setState(() => _status = p.status);
  }

  Future<void> _advance(WorkflowAction action) async {
    final user = ref.read(currentUserProvider);
    if (user == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(fulfillmentServiceProvider).advanceDelivery(
            actor: user,
            procurementId: widget.procurementId,
            action: action,
          );
      await _refresh();
      ref.invalidate(vendorOrdersProvider);
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final st = _status != null ? ProcurementStatus.fromStorage(_status!) : null;
    WorkflowAction? next;
    if (st == ProcurementStatus.poIssued) next = WorkflowAction.markPreparing;
    if (st == ProcurementStatus.preparing) next = WorkflowAction.markDispatched;
    if (st == ProcurementStatus.dispatched) next = WorkflowAction.markInTransit;
    if (st == ProcurementStatus.inTransit) next = WorkflowAction.markDelivered;

    return Scaffold(
      appBar: AppBar(title: Text(widget.poNumber)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            st?.label ?? '…',
            style: const TextStyle(color: ProcuraColors.gold, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 12),
          const Text(
            'Update delivery forward only. Buyers confirm receipt after you mark delivered.',
            style: TextStyle(color: ProcuraColors.muted, fontSize: 13),
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: ProcuraColors.danger)),
          ],
          const SizedBox(height: 24),
          if (next != null)
            ElevatedButton(
              onPressed: _busy ? null : () => _advance(next!),
              child: Text(_busy ? 'Updating…' : _label(next)),
            ),
          if (st == ProcurementStatus.delivered)
            const Text('Waiting for buyer goods receipt before you can invoice.',
                style: TextStyle(color: ProcuraColors.muted)),
          if (st == ProcurementStatus.goodsReceived) ...[
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: _busy
                  ? null
                  : () async {
                      final controller = TextEditingController();
                      final amount = await showDialog<double>(
                        context: context,
                        builder: (ctx) => AlertDialog(
                          title: const Text('Invoice amount (₦)'),
                          content: TextField(
                            controller: controller,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            decoration: const InputDecoration(labelText: 'Your invoice total'),
                          ),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
                            TextButton(
                              onPressed: () =>
                                  Navigator.pop(ctx, double.tryParse(controller.text.replaceAll(',', ''))),
                              child: const Text('Submit'),
                            ),
                          ],
                        ),
                      );
                      if (amount == null || amount <= 0) return;
                      setState(() {
                        _busy = true;
                        _error = null;
                      });
                      try {
                        final user = ref.read(currentUserProvider)!;
                        final match = await ref.read(financeServiceProvider).submitInvoice(
                              actor: user,
                              procurementId: widget.procurementId,
                              amountKobo: (amount * 100).round(),
                            );
                        await _refresh();
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(match.detail)),
                          );
                        }
                      } catch (e) {
                        setState(() => _error = e.toString());
                      } finally {
                        if (mounted) setState(() => _busy = false);
                      }
                    },
              child: const Text('Submit invoice (your amount)'),
            ),
          ],
          if (st == ProcurementStatus.completed)
            const Text('Order completed.', style: TextStyle(color: ProcuraColors.muted)),
        ],
      ),
    );
  }

  String _label(WorkflowAction a) => switch (a) {
        WorkflowAction.markPreparing => 'Mark preparing',
        WorkflowAction.markDispatched => 'Mark dispatched',
        WorkflowAction.markInTransit => 'Mark in transit',
        WorkflowAction.markDelivered => 'Mark delivered',
        _ => a.name,
      };
}
