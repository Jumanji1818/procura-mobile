# CHANGELOG — Procura (native rebuild)

Maps the 11 failures of the previous web build to status in this Flutter/SQLite product.

| # | Previous problem | Status |
|---|------------------|--------|
| 1 | Web app with broken dependency install / 500s | **Fixed (Stage 1)** — Native Flutter (Windows + Android). Offline SQLite via Drift. |
| 2 | Only owner could log in; teammates were placeholders | **Fixed (Stage 1)** — Real bcrypt accounts per role; staff self-register as `pending` until Org Admin assigns role. |
| 3 | Auto-generated fake bids + hardcoded recommendation | **Fixed (Stage 3 code)** — No auto-bids; `ScoringEngine` ranks real inputs with generated explanations. |
| 4 | “PDF” rows were names only | **Partial** — Purchase-order PDF (view/print) now exists; invoice/report PDFs not built. |
| 5 | Cross-org data leak by ID | **Planned, Stage 2+** — Single org + role-scoped queries as features land. |
| 6 | Bid rules not enforced | **Fixed (Stage 3 code)** — `BidRules` + `BidService` enforce category, deadline, price, days, ack, one-bid. |
| 7 | No role checks / no state machine | **Fixed (Stage 1)** — `ProcurementStateMachine` transition table; terminal states blocked; SoD on approve/award/pay. |
| 8 | Invoice amount copied from PO | **Fixed (Stage 5 code)** — Vendor enters amount; `ThreeWayMatch` on qty + amount. |
| 9 | PO/invoice numbers count+1 hardcoded year | **Fixed (Stage 1 schema)** — `DocumentCounters` per prefix/year inside transactions. |
| 10 | No validation / no transactions | **Fixed (audit pass)** — Multi-step services run the workflow check first inside one transaction; unique DB constraints block duplicate PO/receipt/invoice/payment. |
| 11 | No tests on real workflow/scoring | **Partial** — Transition matrix, scoring, bid rules, lockout, payable-amount and dashboard rules are unit-tested. No database/service integration tests yet. |

## Stage progress

- [x] **Stage 1** — Structure, schema, auth, roles, shell, seed, state machine, baseline tests (corrected after review)
- [x] **Stage 2 (code)** — Request create/list/detail + department approve/changes/reject via WorkflowService (compile still needs Drift gen on Windows)
- [x] **Stage 3 (code)** — Bid rules, vendor RFQ list, submit bid, scoring engine + anomalies, evaluation UI
- [x] **Stage 4 (code)** — Award, issue PO, vendor delivery tracking, goods receipt, reliability update
- [x] **Stage 5 (code)** — Vendor invoice amount, three-way match, finance pay, complete, reports insights
- [x] **Stage 6** — Responsive phone layout, safe-area handling, compact rail, and breakpoint tests
- [x] **Stage 7 (configuration)** — Release scripts, Android keystore support, Windows Inno Setup definition, and packaging documentation

Stage 7 still requires the Flutter SDK, Android SDK, and (for the installer)
Inno Setup on the build machine. The archive does not contain a prebuilt APK,
Windows bundle, or installer.

## Stage 1 review fixes (this revision)

1. Reactive `sessionProvider` (StateNotifier) — login/logout updates role menus
2. Lockout: `failedLogins` reset when `lockedUntil` has expired
3. Removed default counter `widget_test.dart`; added smoke + matrix tests
4. Vendor registration requires 1–3 categories from DB
5. State machine: SoD (no Org Admin on dept approve / award / pay); every rule tested
6. `assignRole`: keep department, reject vendor assignment to staff, block last-admin demotion
7. bcrypt via `compute` (isolate)
8. Department Head seeded for Operations, Finance, Engineering
9. Repo hygiene + `.gitignore`
10. CHANGELOG honesty (planned vs fixed)

## Audit pass (this revision)

Fixes made from the static audit (nothing here has been compiled or run yet;
run `flutter pub get`, `dart run build_runner build --delete-conflicting-outputs`,
`flutter analyze`, `flutter test`, then the demo on an Android emulator):

- Finance sees invoice, PO, receipt and match result before paying; payment is capped at what the PO and goods received support; Hold action added; double-pay blocked.
- Workflow check runs first, in one transaction, for award, PO, receipt, invoice, payment, publish. Unique constraints added.
- Sign-out on phone (new Account tab); pending users can sign out.
- Approving Authority sees all bids, scores, budget and the recommendation, and can award any bidder or reject. Award requires an actual bid.
- Team screen (assign role/department, enable/disable), real dashboard counts.
- Complete action, PO status kept in sync, category budgets checked at award and updated at payment.
- Request changes/reject need a reason; requester can edit and resubmit; history shown on request page.
- Vendors see RFQ details, expired RFQs hidden, bid documents checkbox, duplicate bids blocked; bidding window selectable; cannot close bidding with zero bids.
- Partial/damaged/missing goods entry; PO PDF; spend charts; scrollable login; system font; Android label.
- Org Admin no longer creates requests or records receipts (matches the state machine).
- More categories (medical, hospitality) and vendors in the demo seed. Existing installs must clear app data to re-seed.

### Second pass (additions after the audit report)

- Organisation screen (Team tab → settings icon): add departments and categories, set yearly category budgets, edit bid scoring weights. Scoring now uses the saved weights.
- New vendors with no delivery history get a neutral reliability/rating score instead of 0 rating and 100% on-time.
- In-app notifications: bell on Home with unread badge and an inbox. Sent on workflow changes (whoever has work next, the requester, the awarded vendor), when an RFQ opens (matching vendors) and on award.
- Invoice PDF (Payments → Review → Print PDF) and report PDF (Reports → PDF icon).
- App icon (gold P on dark green) for Android.
- Login: a disabled account is only revealed after the correct password. The demo login hint is controlled by `SHOW_DEMO_HINT` (default on); for the final build use `flutter build apk --release --dart-define=SHOW_DEMO_HINT=false`.
- A syntax check (tree-sitter) passes on every Dart file, and every import, provider and service call was cross-checked. This is not a compile or type check.

Not done: database integration tests, encrypted SQLite, refreshing a signed-in user's role without signing out again, and separate locked-account wording.
