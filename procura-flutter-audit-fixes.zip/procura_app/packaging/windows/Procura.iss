; Build the Flutter Windows bundle first:
;   flutter build windows --release
; Then compile this file with Inno Setup (ISCC.exe).

#define MyAppName "Procura"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Procura"
#define MyAppExeName "procura.exe"

[Setup]
AppId={{A1A94C4B-0D5C-4A4A-9E3D-7F26E72B4E3A}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Procura
DefaultGroupName={#MyAppName}
OutputDir=..\..\dist
OutputBaseFilename=Procura-Setup
Compression=lzma
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=admin
WizardStyle=modern
UninstallDisplayIcon={app}\{#MyAppExeName}

[Files]
Source: "..\..\build\windows\x64\runner\Release\*"; DestDir: "{app}"; \
  Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; \
  Flags: nowait postinstall skipifsilent