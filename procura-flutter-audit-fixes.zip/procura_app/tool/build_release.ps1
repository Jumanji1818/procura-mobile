param(
    [switch]$SkipTests,
    [switch]$WindowsInstaller
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location $ProjectRoot

Write-Host "Preparing Procura release from $ProjectRoot"
flutter pub get
dart run build_runner build --delete-conflicting-outputs

if (-not $SkipTests) {
    flutter analyze --no-fatal-infos
    flutter test
}

flutter build windows --release
flutter build apk --release

if ($WindowsInstaller) {
    $iscc = Get-Command iscc.exe -ErrorAction SilentlyContinue
    if ($null -eq $iscc) {
        throw "Inno Setup was not found. Install it or rerun without -WindowsInstaller."
    }
    & $iscc.Source (Join-Path $ProjectRoot "packaging\windows\Procura.iss")
}

Write-Host ""
Write-Host "Release outputs:"
Write-Host "  Windows bundle: build\windows\x64\runner\Release"
Write-Host "  Android APK:    build\app\outputs\flutter-apk\app-release.apk"
if ($WindowsInstaller) {
    Write-Host "  Installer:      dist\Procura-Setup.exe"
}