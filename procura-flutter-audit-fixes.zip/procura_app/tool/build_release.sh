#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.."

flutter pub get
dart run build_runner build --delete-conflicting-outputs
flutter analyze --no-fatal-infos
flutter test
flutter build apk --release

printf '\nAndroid release output:\n'
printf '  build/app/outputs/flutter-apk/app-release.apk\n'
printf '\nWindows packaging is run on Windows with tool/build_release.ps1.\n'