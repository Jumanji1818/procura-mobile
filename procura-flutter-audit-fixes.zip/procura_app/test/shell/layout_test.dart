import 'package:flutter_test/flutter_test.dart';
import 'package:procura/features/shell/app_shell.dart';

void main() {
  group('shell layout breakpoints', () {
    test('phone layout is used below 600 logical pixels', () {
      expect(shellLayoutForWidth(599), ShellLayout.phone);
    });

    test('compact rail is used between phone and desktop widths', () {
      expect(shellLayoutForWidth(600), ShellLayout.compactRail);
      expect(shellLayoutForWidth(959), ShellLayout.compactRail);
    });

    test('desktop rail is used at wide desktop widths', () {
      expect(shellLayoutForWidth(960), ShellLayout.desktopRail);
      expect(shellLayoutForWidth(1440), ShellLayout.desktopRail);
    });

    test('selected navigation index stays inside the destination list', () {
      expect(shellSelectedIndex(-1, 4), 0);
      expect(shellSelectedIndex(2, 4), 2);
      expect(shellSelectedIndex(8, 4), 3);
      expect(shellSelectedIndex(8, 0), 0);
    });
  });
}