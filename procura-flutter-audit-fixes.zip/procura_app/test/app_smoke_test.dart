import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:procura/core/theme/procura_theme.dart';
import 'package:procura/domain/models/role.dart';
import 'package:procura/domain/workflow/state_machine.dart';

void main() {
  test('Procura theme builds MaterialApp without crash', () {
    final app = MaterialApp(
      title: 'Procura',
      theme: ProcuraTheme.dark,
      home: const Scaffold(body: Text('Procura')),
    );
    expect(app.title, 'Procura');
    expect(ProcuraTheme.dark.colorScheme.primary, ProcuraColors.gold);
  });

  test('state machine has at least 15 rules', () {
    expect(ProcurementStateMachine.rules.length, greaterThanOrEqualTo(15));
  });

  test('all acting roles are concrete (not pending)', () {
    for (final r in ProcurementStateMachine.actingRoles) {
      expect(r, isNot(UserRole.pending));
    }
  });
}
