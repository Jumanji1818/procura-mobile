import 'package:flutter_test/flutter_test.dart';
import 'package:procura/domain/models/procurement_status.dart';
import 'package:procura/domain/models/role.dart';
import 'package:procura/domain/workflow/state_machine.dart';
import 'package:procura/domain/workflow/workflow_action.dart';

void main() {
  group('every transition rule is executable by its roles', () {
    for (final rule in ProcurementStateMachine.rules) {
      for (final role in rule.roles) {
        test('${rule.from.name} + ${rule.action.name} by ${role.name} → ${rule.to.name}', () {
          final next = ProcurementStateMachine.transition(
            from: rule.from,
            action: rule.action,
            role: role,
          );
          expect(next, rule.to);
        });
      }
    }
  });

  group('role-versus-action matrix (forbidden samples)', () {
    final cases = <(ProcurementStatus, WorkflowAction, UserRole)>[
      (ProcurementStatus.pendingDepartmentApproval, WorkflowAction.approveDepartment, UserRole.vendor),
      (ProcurementStatus.pendingDepartmentApproval, WorkflowAction.approveDepartment, UserRole.orgAdmin),
      (ProcurementStatus.pendingDepartmentApproval, WorkflowAction.approveDepartment, UserRole.requestOfficer),
      (ProcurementStatus.evaluating, WorkflowAction.award, UserRole.procurementOfficer),
      (ProcurementStatus.evaluating, WorkflowAction.award, UserRole.orgAdmin),
      (ProcurementStatus.invoiced, WorkflowAction.approvePayment, UserRole.requestOfficer),
      (ProcurementStatus.invoiced, WorkflowAction.approvePayment, UserRole.orgAdmin),
      (ProcurementStatus.inTransit, WorkflowAction.markDelivered, UserRole.procurementOfficer),
      (ProcurementStatus.paid, WorkflowAction.markDelivered, UserRole.vendor),
      (ProcurementStatus.rejected, WorkflowAction.submitForApproval, UserRole.requestOfficer),
      (ProcurementStatus.draft, WorkflowAction.award, UserRole.approvingAuthority),
    ];

    for (final c in cases) {
      test('FORBIDDEN: ${c.$3.name} cannot ${c.$2.name} from ${c.$1.name}', () {
        expect(
          () => ProcurementStateMachine.transition(from: c.$1, action: c.$2, role: c.$3),
          throwsA(isA<WorkflowException>()),
        );
      });
    }
  });

  test('vendor delivery path is forward-only', () {
    var status = ProcurementStatus.poIssued;
    for (final action in [
      WorkflowAction.markPreparing,
      WorkflowAction.markDispatched,
      WorkflowAction.markInTransit,
      WorkflowAction.markDelivered,
    ]) {
      status = ProcurementStateMachine.transition(
        from: status,
        action: action,
        role: UserRole.vendor,
      );
    }
    expect(status, ProcurementStatus.delivered);
  });

  test('recommendVendor is not a status transition rule', () {
    final has = ProcurementStateMachine.rules.any((r) => r.action == WorkflowAction.recommendVendor);
    expect(has, isFalse);
  });
}
