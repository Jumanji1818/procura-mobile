import 'package:flutter_test/flutter_test.dart';
import 'package:procura/domain/models/auth_user.dart';
import 'package:procura/domain/models/procurement_status.dart';
import 'package:procura/domain/models/role.dart';
import 'package:procura/domain/workflow/state_machine.dart';
import 'package:procura/domain/workflow/transition_policy.dart';
import 'package:procura/domain/workflow/workflow_action.dart';

AuthUser user(String id, UserRole role, {String? dept}) => AuthUser(
      id: id,
      email: '$id@t.local',
      displayName: id,
      role: role,
      departmentId: dept,
    );

void main() {
  group('self-approval block', () {
    test('creator cannot approve own request', () {
      final actor = user('u1', UserRole.departmentHead, dept: 'd1');
      expect(
        () => TransitionPolicy.assertAllowed(
          from: ProcurementStatus.pendingDepartmentApproval,
          action: WorkflowAction.approveDepartment,
          actor: actor,
          createdByUserId: 'u1',
          departmentId: 'd1',
        ),
        throwsA(isA<WorkflowException>()),
      );
    });

    test('other department head in same dept can approve', () {
      final actor = user('head1', UserRole.departmentHead, dept: 'd1');
      final next = TransitionPolicy.nextStatus(
        from: ProcurementStatus.pendingDepartmentApproval,
        action: WorkflowAction.approveDepartment,
        actor: actor,
        createdByUserId: 'requester',
        departmentId: 'd1',
      );
      expect(next, ProcurementStatus.rfqPublished);
    });
  });

  group('cross-department block', () {
    test('ops head cannot approve engineering request', () {
      final actor = user('head-ops', UserRole.departmentHead, dept: 'ops');
      expect(
        () => TransitionPolicy.assertAllowed(
          from: ProcurementStatus.pendingDepartmentApproval,
          action: WorkflowAction.approveDepartment,
          actor: actor,
          createdByUserId: 'someone',
          departmentId: 'eng',
        ),
        throwsA(isA<WorkflowException>()),
      );
    });

    test('matching department is allowed', () {
      final actor = user('head-eng', UserRole.departmentHead, dept: 'eng');
      expect(
        () => TransitionPolicy.assertAllowed(
          from: ProcurementStatus.pendingDepartmentApproval,
          action: WorkflowAction.approveDepartment,
          actor: actor,
          createdByUserId: 'someone',
          departmentId: 'eng',
        ),
        returnsNormally,
      );
    });
  });

  group('role SoD still enforced via policy', () {
    test('org admin cannot award', () {
      expect(
        () => TransitionPolicy.assertAllowed(
          from: ProcurementStatus.evaluating,
          action: WorkflowAction.award,
          actor: user('admin', UserRole.orgAdmin),
          createdByUserId: 'x',
          departmentId: 'd',
        ),
        throwsA(isA<WorkflowException>()),
      );
    });

    test('finance cannot approve department request', () {
      expect(
        () => TransitionPolicy.assertAllowed(
          from: ProcurementStatus.pendingDepartmentApproval,
          action: WorkflowAction.approveDepartment,
          actor: user('fin', UserRole.financeOfficer, dept: 'd1'),
          createdByUserId: 'x',
          departmentId: 'd1',
        ),
        throwsA(isA<WorkflowException>()),
      );
    });
  });
}
