import 'package:flutter_test/flutter_test.dart';
import 'package:procura/domain/models/auth_user.dart';
import 'package:procura/domain/models/procurement_status.dart';
import 'package:procura/domain/models/role.dart';
import 'package:procura/domain/workflow/transition_policy.dart';
import 'package:procura/domain/workflow/workflow_action.dart';
import 'package:procura/domain/workflow/state_machine.dart';

void main() {
  group('Stage 2 request → approval path', () {
    test('request officer can submit draft', () {
      final next = TransitionPolicy.nextStatus(
        from: ProcurementStatus.draft,
        action: WorkflowAction.submitForApproval,
        actor: const AuthUser(
          id: 'r1',
          email: 'r@t',
          displayName: 'R',
          role: UserRole.requestOfficer,
          departmentId: 'ops',
        ),
        createdByUserId: 'r1',
        departmentId: 'ops',
      );
      expect(next, ProcurementStatus.pendingDepartmentApproval);
    });

    test('full happy path statuses: draft → pending → rfq', () {
      var st = ProcurementStatus.draft;
      st = TransitionPolicy.nextStatus(
        from: st,
        action: WorkflowAction.submitForApproval,
        actor: const AuthUser(
          id: 'r1', email: 'r', displayName: 'R',
          role: UserRole.requestOfficer, departmentId: 'ops',
        ),
        createdByUserId: 'r1',
        departmentId: 'ops',
      );
      expect(st, ProcurementStatus.pendingDepartmentApproval);

      st = TransitionPolicy.nextStatus(
        from: st,
        action: WorkflowAction.approveDepartment,
        actor: const AuthUser(
          id: 'h1', email: 'h', displayName: 'H',
          role: UserRole.departmentHead, departmentId: 'ops',
        ),
        createdByUserId: 'r1',
        departmentId: 'ops',
      );
      expect(st, ProcurementStatus.rfqPublished);
    });

    test('creator who is also head cannot self-approve', () {
      expect(
        () => TransitionPolicy.assertAllowed(
          from: ProcurementStatus.pendingDepartmentApproval,
          action: WorkflowAction.approveDepartment,
          actor: const AuthUser(
            id: 'same', email: 's', displayName: 'S',
            role: UserRole.departmentHead, departmentId: 'ops',
          ),
          createdByUserId: 'same',
          departmentId: 'ops',
        ),
        throwsA(isA<WorkflowException>()),
      );
    });
  });
}
