import 'package:flutter_test/flutter_test.dart';
import 'package:procura/domain/models/auth_user.dart';
import 'package:procura/domain/models/procurement_status.dart';
import 'package:procura/domain/models/role.dart';
import 'package:procura/domain/workflow/state_machine.dart';
import 'package:procura/domain/workflow/transition_policy.dart';
import 'package:procura/domain/workflow/workflow_action.dart';

void main() {
  group('Stage 4 award → delivery → receive', () {
    test('only approving authority can award', () {
      expect(
        () => TransitionPolicy.assertAllowed(
          from: ProcurementStatus.evaluating,
          action: WorkflowAction.award,
          actor: const AuthUser(
            id: 'p', email: 'p', displayName: 'P',
            role: UserRole.procurementOfficer,
          ),
          createdByUserId: 'r',
          departmentId: 'd',
        ),
        throwsA(isA<WorkflowException>()),
      );
      final next = TransitionPolicy.nextStatus(
        from: ProcurementStatus.evaluating,
        action: WorkflowAction.award,
        actor: const AuthUser(
          id: 'a', email: 'a', displayName: 'A',
          role: UserRole.approvingAuthority,
        ),
        createdByUserId: 'r',
        departmentId: 'd',
      );
      expect(next, ProcurementStatus.awarded);
    });

    test('vendor-only delivery chain', () {
      var st = ProcurementStatus.poIssued;
      for (final a in [
        WorkflowAction.markPreparing,
        WorkflowAction.markDispatched,
        WorkflowAction.markInTransit,
        WorkflowAction.markDelivered,
      ]) {
        st = TransitionPolicy.nextStatus(
          from: st,
          action: a,
          actor: const AuthUser(
            id: 'v', email: 'v', displayName: 'V',
            role: UserRole.vendor,
          ),
          createdByUserId: 'r',
          departmentId: 'd',
        );
      }
      expect(st, ProcurementStatus.delivered);
    });

    test('buyer cannot mark delivered', () {
      expect(
        () => TransitionPolicy.assertAllowed(
          from: ProcurementStatus.inTransit,
          action: WorkflowAction.markDelivered,
          actor: const AuthUser(
            id: 'b', email: 'b', displayName: 'B',
            role: UserRole.requestOfficer,
          ),
          createdByUserId: 'r',
          departmentId: 'd',
        ),
        throwsA(isA<WorkflowException>()),
      );
    });

    test('receive goods only from delivered', () {
      final next = TransitionPolicy.nextStatus(
        from: ProcurementStatus.delivered,
        action: WorkflowAction.receiveGoods,
        actor: const AuthUser(
          id: 'r', email: 'r', displayName: 'R',
          role: UserRole.requestOfficer,
        ),
        createdByUserId: 'r',
        departmentId: 'd',
      );
      expect(next, ProcurementStatus.goodsReceived);
    });
  });
}
