import 'package:flutter_test/flutter_test.dart';
import 'package:procura/domain/services/three_way_match.dart';

void main() {
  group('ThreeWayMatch', () {
    test('matches when invoice equals full PO and full receipt', () {
      final r = ThreeWayMatch.compare(
        poTotalKobo: 100000,
        qtyOrdered: 10,
        qtyReceived: 10,
        invoiceAmountKobo: 100000,
      );
      expect(r.ok, isTrue);
      expect(r.detail.contains('Match'), isTrue);
    });

    test('pro-rates expected amount on partial receipt', () {
      final r = ThreeWayMatch.compare(
        poTotalKobo: 100000,
        qtyOrdered: 10,
        qtyReceived: 5,
        invoiceAmountKobo: 50000,
      );
      expect(r.ok, isTrue);
      expect(r.expectedAmountKobo, 50000);
    });

    test('flags amount mismatch', () {
      final r = ThreeWayMatch.compare(
        poTotalKobo: 100000,
        qtyOrdered: 10,
        qtyReceived: 10,
        invoiceAmountKobo: 150000,
      );
      expect(r.ok, isFalse);
      expect(r.detail.contains('amount mismatch'), isTrue);
    });

    test('flags zero received', () {
      final r = ThreeWayMatch.compare(
        poTotalKobo: 100000,
        qtyOrdered: 10,
        qtyReceived: 0,
        invoiceAmountKobo: 100000,
      );
      expect(r.ok, isFalse);
    });
  });
}
