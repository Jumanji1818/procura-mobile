import 'package:flutter_test/flutter_test.dart';
import 'package:procura/domain/services/three_way_match.dart';

void main() {
  group('ThreeWayMatch.payableKobo', () {
    test('pays the invoice when it matches the PO', () {
      final r = ThreeWayMatch.compare(
        poTotalKobo: 100000,
        qtyOrdered: 10,
        qtyReceived: 10,
        invoiceAmountKobo: 100000,
      );
      expect(ThreeWayMatch.payableKobo(r), 100000);
    });

    test('never pays more than the PO supports when the vendor over-invoices', () {
      final r = ThreeWayMatch.compare(
        poTotalKobo: 100000,
        qtyOrdered: 10,
        qtyReceived: 10,
        invoiceAmountKobo: 1000000,
      );
      expect(r.ok, isFalse);
      expect(ThreeWayMatch.payableKobo(r), 100000);
    });

    test('a correct partial-receipt invoice is paid in full, not pro-rated twice', () {
      final r = ThreeWayMatch.compare(
        poTotalKobo: 100000,
        qtyOrdered: 10,
        qtyReceived: 5,
        invoiceAmountKobo: 50000,
      );
      expect(r.ok, isTrue);
      expect(ThreeWayMatch.payableKobo(r), 50000);
    });

    test('pays the lower invoice when the vendor under-invoices', () {
      final r = ThreeWayMatch.compare(
        poTotalKobo: 100000,
        qtyOrdered: 10,
        qtyReceived: 10,
        invoiceAmountKobo: 80000,
      );
      expect(ThreeWayMatch.payableKobo(r), 80000);
    });

    test('pays nothing when no goods were received', () {
      final r = ThreeWayMatch.compare(
        poTotalKobo: 100000,
        qtyOrdered: 10,
        qtyReceived: 0,
        invoiceAmountKobo: 100000,
      );
      expect(ThreeWayMatch.payableKobo(r), 0);
    });
  });
}
