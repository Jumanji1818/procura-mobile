import 'package:flutter_test/flutter_test.dart';
import 'package:procura/domain/services/scoring_engine.dart';
import 'package:procura/domain/services/bid_rules.dart';

void main() {
  group('ScoringEngine', () {
    final bids = [
      const BidScoreInput(
        vendorId: 'a',
        vendorName: 'Alpha',
        unitPriceKobo: 100000,
        deliveryDays: 10,
        onTimeRate: 95,
        rating: 4.5,
        complianceComplete: true,
      ),
      const BidScoreInput(
        vendorId: 'b',
        vendorName: 'Beta',
        unitPriceKobo: 200000,
        deliveryDays: 5,
        onTimeRate: 80,
        rating: 4.0,
        complianceComplete: true,
      ),
      const BidScoreInput(
        vendorId: 'c',
        vendorName: 'Gamma',
        unitPriceKobo: 50000,
        deliveryDays: 20,
        onTimeRate: 70,
        rating: 3.5,
        complianceComplete: false,
      ),
    ];

    test('ranks three bids and builds explanations from numbers', () {
      final ranked = ScoringEngine.rank(bids);
      expect(ranked.length, 3);
      expect(ranked.first.explanation.contains(ranked.first.vendorName), isTrue);
      expect(ranked.first.total, greaterThan(0));
      // Lowest price gamma may not win if compliance/on-time drag it down
      for (final r in ranked) {
        expect(r.explanation.contains('scores'), isTrue);
      }
    });

    test('known inputs: cheaper complete vendor beats expensive one on price score', () {
      final ranked = ScoringEngine.rank(bids);
      final alpha = ranked.firstWhere((r) => r.vendorId == 'a');
      final beta = ranked.firstWhere((r) => r.vendorId == 'b');
      expect(alpha.priceScore, greaterThan(beta.priceScore));
    });

    test('anomaly detection flags extreme low price', () {
      final weird = [
        ...bids,
        const BidScoreInput(
          vendorId: 'd',
          vendorName: 'Dump',
          unitPriceKobo: 1000,
          deliveryDays: 7,
          onTimeRate: 90,
          rating: 4.0,
          complianceComplete: true,
        ),
      ];
      final anomalies = ScoringEngine.detectAnomalies(weird, zThreshold: 1.0);
      expect(anomalies.any((a) => a.vendorId == 'd' && a.kind == 'low'), isTrue);
    });
  });

  group('BidRules', () {
    test('rejects category mismatch', () {
      expect(
        () => BidRules.validateSubmission(
          closingDate: DateTime.now().add(const Duration(days: 1)),
          now: DateTime.now(),
          unitPriceKobo: 100,
          deliveryDays: 5,
          lateDeliveryAcknowledged: true,
          categoryMatches: false,
          alreadyBid: false,
        ),
        throwsA(isA<BidValidationException>()),
      );
    });

    test('rejects late bid', () {
      expect(
        () => BidRules.validateSubmission(
          closingDate: DateTime.now().subtract(const Duration(hours: 1)),
          now: DateTime.now(),
          unitPriceKobo: 100,
          deliveryDays: 5,
          lateDeliveryAcknowledged: true,
          categoryMatches: true,
          alreadyBid: false,
        ),
        throwsA(isA<BidValidationException>()),
      );
    });

    test('rejects duplicate bid', () {
      expect(
        () => BidRules.validateSubmission(
          closingDate: DateTime.now().add(const Duration(days: 1)),
          now: DateTime.now(),
          unitPriceKobo: 100,
          deliveryDays: 5,
          lateDeliveryAcknowledged: true,
          categoryMatches: true,
          alreadyBid: true,
        ),
        throwsA(isA<BidValidationException>()),
      );
    });

    test('rejects missing acknowledgment', () {
      expect(
        () => BidRules.validateSubmission(
          closingDate: DateTime.now().add(const Duration(days: 1)),
          now: DateTime.now(),
          unitPriceKobo: 100,
          deliveryDays: 5,
          lateDeliveryAcknowledged: false,
          categoryMatches: true,
          alreadyBid: false,
        ),
        throwsA(isA<BidValidationException>()),
      );
    });

    test('accepts valid bid', () {
      expect(
        () => BidRules.validateSubmission(
          closingDate: DateTime.now().add(const Duration(days: 1)),
          now: DateTime.now(),
          unitPriceKobo: 100,
          deliveryDays: 5,
          lateDeliveryAcknowledged: true,
          categoryMatches: true,
          alreadyBid: false,
        ),
        returnsNormally,
      );
    });
  });
}
