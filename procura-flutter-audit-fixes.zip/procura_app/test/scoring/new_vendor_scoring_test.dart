import 'package:flutter_test/flutter_test.dart';
import 'package:procura/domain/services/scoring_engine.dart';

BidScoreInput _bid(String id, {required bool hasHistory, double onTime = 100, double rating = 0}) {
  return BidScoreInput(
    vendorId: id,
    vendorName: id,
    unitPriceKobo: 100000,
    deliveryDays: 5,
    onTimeRate: onTime,
    rating: rating,
    complianceComplete: true,
    hasHistory: hasHistory,
  );
}

void main() {
  group('new vendors', () {
    test('get a neutral reliability and rating score, not 0 or 100', () {
      final r = ScoringEngine.rank([_bid('new', hasHistory: false)]).single;
      expect(r.onTimeScore, ScoringEngine.neutralHistoryScore);
      expect(r.ratingScore, ScoringEngine.neutralHistoryScore);
      expect(r.explanation, contains('new vendor'));
    });

    test('vendors with history keep their real numbers', () {
      final r = ScoringEngine.rank([_bid('old', hasHistory: true, onTime: 80, rating: 4)]).single;
      expect(r.onTimeScore, 80);
      expect(r.ratingScore, 80);
    });
  });

  group('ScoringWeights.isValid', () {
    test('defaults are valid', () {
      expect(const ScoringWeights().isValid, isTrue);
    });

    test('negative weights are invalid', () {
      expect(const ScoringWeights(price: -0.1).isValid, isFalse);
    });

    test('all-zero weights are invalid', () {
      const w = ScoringWeights(price: 0, delivery: 0, onTime: 0, rating: 0, compliance: 0);
      expect(w.isValid, isFalse);
    });

    test('custom weights change the ranking', () {
      final cheapSlow = BidScoreInput(
        vendorId: 'a', vendorName: 'a', unitPriceKobo: 100, deliveryDays: 30,
        onTimeRate: 90, rating: 4, complianceComplete: true,
      );
      final dearFast = BidScoreInput(
        vendorId: 'b', vendorName: 'b', unitPriceKobo: 200, deliveryDays: 2,
        onTimeRate: 90, rating: 4, complianceComplete: true,
      );
      final priceHeavy = ScoringEngine.rank(
        [cheapSlow, dearFast],
        weights: const ScoringWeights(price: 1, delivery: 0, onTime: 0, rating: 0, compliance: 0),
      );
      final speedHeavy = ScoringEngine.rank(
        [cheapSlow, dearFast],
        weights: const ScoringWeights(price: 0, delivery: 1, onTime: 0, rating: 0, compliance: 0),
      );
      expect(priceHeavy.first.vendorId, 'a');
      expect(speedHeavy.first.vendorId, 'b');
    });
  });
}
