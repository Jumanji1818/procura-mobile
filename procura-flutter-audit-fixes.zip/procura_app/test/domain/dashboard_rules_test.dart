import 'package:flutter_test/flutter_test.dart';
import 'package:procura/domain/models/procurement_status.dart';
import 'package:procura/domain/models/role.dart';
import 'package:procura/domain/services/dashboard_rules.dart';

void main() {
  group('awaitingStatusesFor', () {
    test('finance waits on invoiced and payment-review items only', () {
      expect(
        awaitingStatusesFor(UserRole.financeOfficer),
        {ProcurementStatus.invoiced, ProcurementStatus.paymentReview},
      );
    });

    test('approving authority waits on evaluating items', () {
      expect(awaitingStatusesFor(UserRole.approvingAuthority), {ProcurementStatus.evaluating});
    });

    test('department head waits on pending department approval', () {
      expect(
        awaitingStatusesFor(UserRole.departmentHead),
        {ProcurementStatus.pendingDepartmentApproval},
      );
    });

    test('vendor and pending users have no request-stage work', () {
      expect(awaitingStatusesFor(UserRole.vendor), isEmpty);
      expect(awaitingStatusesFor(UserRole.pending), isEmpty);
    });
  });
}
