import 'package:flutter_test/flutter_test.dart';
import 'package:procura/domain/models/auth_user.dart';
import 'package:procura/domain/models/role.dart';
import 'package:procura/domain/services/auth_gateway.dart';
import 'package:procura/features/auth/session_notifier.dart';

class FakeAuthGateway implements AuthGateway {
  AuthUser? _user;

  @override
  AuthUser? get currentUser => _user;

  @override
  void setSession(AuthUser? user) => _user = user;

  @override
  void logout() => _user = null;

  @override
  Future<AuthUser> login({required String email, required String password}) async {
    final role = email.contains('admin')
        ? UserRole.orgAdmin
        : email.contains('vendor')
            ? UserRole.vendor
            : UserRole.requestOfficer;
    final u = AuthUser(id: email, email: email, displayName: email, role: role);
    _user = u;
    return u;
  }

  @override
  Future<AuthUser> register({
    required String email,
    required String displayName,
    required String password,
    required bool asVendor,
    List<String> categoryIds = const [],
    String? businessName,
    String? location,
  }) =>
      login(email: email, password: password);

  @override
  Future<void> assignRole({
    required String actorUserId,
    required String targetUserId,
    required UserRole role,
    String? departmentId,
    bool clearDepartment = false,
  }) async {}
}

void main() {
  test('real SessionNotifier switches admin → null → vendor', () async {
    final gateway = FakeAuthGateway();
    final notifier = SessionNotifier(gateway);

    await notifier.login(email: 'admin@t.local', password: 'x');
    expect(notifier.state?.role, UserRole.orgAdmin);

    notifier.logout();
    expect(notifier.state, isNull);

    await notifier.login(email: 'vendor@t.local', password: 'x');
    expect(notifier.state?.role, UserRole.vendor);
  });
}
