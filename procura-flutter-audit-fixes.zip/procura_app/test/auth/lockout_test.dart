import 'package:flutter_test/flutter_test.dart';
import 'package:procura/domain/services/lockout_policy.dart';

void main() {
  test('expired lockout is cleared', () {
    final now = DateTime.utc(2026, 1, 1, 12);
    final lockedUntil = DateTime.utc(2026, 1, 1, 11, 45);
    expect(LockoutPolicy.shouldClearLockout(lockedUntil, now), isTrue);
  });

  test('active lockout is not cleared', () {
    final now = DateTime.utc(2026, 1, 1, 12);
    final lockedUntil = DateTime.utc(2026, 1, 1, 12, 10);
    expect(LockoutPolicy.shouldClearLockout(lockedUntil, now), isFalse);
  });

  test('null lockout needs no clear', () {
    expect(LockoutPolicy.shouldClearLockout(null, DateTime.now()), isFalse);
  });

  test('5 failures produces a lock time; 4 does not', () {
    final now = DateTime.utc(2026, 1, 1);
    expect(LockoutPolicy.nextLockUntil(4, now), isNull);
    expect(LockoutPolicy.nextLockUntil(5, now), isNotNull);
  });
}
