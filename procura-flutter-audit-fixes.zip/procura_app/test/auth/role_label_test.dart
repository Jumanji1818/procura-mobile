import 'package:flutter_test/flutter_test.dart';
import 'package:procura/domain/models/role.dart';

void main() {
  test('all roles have human labels', () {
    for (final role in UserRole.values) {
      expect(role.label.isNotEmpty, isTrue);
    }
  });

  test('fromStorage round-trip', () {
    for (final role in UserRole.values) {
      expect(UserRole.fromStorage(role.name), role);
    }
  });
}
