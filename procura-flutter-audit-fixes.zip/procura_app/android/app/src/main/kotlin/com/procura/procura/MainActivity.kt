package com.procura.procura

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
