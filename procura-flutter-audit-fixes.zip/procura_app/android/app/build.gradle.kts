import java.util.Properties

plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

val releaseKeystorePropertiesFile = rootProject.file("key.properties")
val releaseKeystoreProperties = Properties()
if (releaseKeystorePropertiesFile.exists()) {
    releaseKeystorePropertiesFile.inputStream().use { releaseKeystoreProperties.load(it) }
}

android {
    namespace = "com.procura.procura"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_11.toString()
    }

    defaultConfig {
        applicationId = "com.procura.procura"
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    signingConfigs {
        create("release") {
            if (releaseKeystorePropertiesFile.exists()) {
                keyAlias = releaseKeystoreProperties.getProperty("keyAlias")
                    ?: error("android/key.properties is missing keyAlias")
                keyPassword = releaseKeystoreProperties.getProperty("keyPassword")
                    ?: error("android/key.properties is missing keyPassword")
                storeFile = file(
                    releaseKeystoreProperties.getProperty("storeFile")
                        ?: error("android/key.properties is missing storeFile"),
                )
                storePassword = releaseKeystoreProperties.getProperty("storePassword")
                    ?: error("android/key.properties is missing storePassword")
            }
        }
    }

    buildTypes {
        release {
            // A real release keystore is selected when android/key.properties
            // exists. Debug signing remains an explicit local-build fallback.
            signingConfig = if (releaseKeystorePropertiesFile.exists()) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
        }
    }
}

flutter {
    source = "../.."
}
