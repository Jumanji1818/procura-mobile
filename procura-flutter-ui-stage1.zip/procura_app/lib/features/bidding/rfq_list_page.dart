import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:intl/intl.dart';

import '../../core/theme/procura_theme.dart';
import 'bid_providers.dart';
import 'submit_bid_page.dart';
import '../shell/shell_menu.dart';

class RfqListPage extends ConsumerWidget {
  const RfqListPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(openRfqProvider);

    return Scaffold(
      appBar: AppBar(leading: shellMenuLeading(context), title: const Text('Open RFQs')),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator(color: ProcuraColors.gold)),
        error: (e, _) => Center(child: Text('$e')),
        data: (items) {
          if (items.isEmpty) {
            return const Center(
              child: Text(
                'No open RFQs match your categories.',
                style: TextStyle(color: ProcuraColors.muted),
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final p = items[i];
              return Card(
                child: ListTile(
                  title: Text(p.title),
                  subtitle: Text(
                    '${p.number} · ${p.quantity} ${p.unit}'
                    '${p.closingDate != null ? ' · closes ${DateFormat('d MMM').format(p.closingDate!.toLocal())}' : ''}',
                    style: const TextStyle(color: ProcuraColors.muted, fontSize: 12),
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () async {
                    await Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => SubmitBidPage(procurementId: p.id)),
                    );
                    ref.invalidate(openRfqProvider);
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
