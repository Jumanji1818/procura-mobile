import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/procura_theme.dart';
import '../../data/db/app_database.dart';
import '../../domain/models/procurement_status.dart';
import '../../domain/models/role.dart';
import '../../domain/services/dashboard_rules.dart';
import '../auth/auth_providers.dart';
import '../bidding/bid_providers.dart';
import '../delivery/fulfillment_providers.dart';
import '../notifications/notification_providers.dart';
import '../notifications/notifications_page.dart';
import '../requests/requests_providers.dart';
import '../shell/shell_menu.dart';

class DashboardPage extends ConsumerWidget {
  const DashboardPage({super.key});

  static bool _thisMonth(DateTime d) {
    final now = DateTime.now();
    final l = d.toLocal();
    return l.year == now.year && l.month == now.month;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    final role = user?.role ?? UserRole.pending;

    String open;
    String awaiting;
    String month;
    String awaitingLabel = 'Awaiting you';

    if (role == UserRole.vendor) {
      final orders = ref.watch(vendorOrdersProvider).valueOrNull ?? const <PurchaseOrder>[];
      final rfqs = ref.watch(openRfqProvider).valueOrNull ?? const <Procurement>[];
      const done = {ProcurementStatus.paid, ProcurementStatus.completed};
      const vendorActs = {
        ProcurementStatus.poIssued,
        ProcurementStatus.preparing,
        ProcurementStatus.dispatched,
        ProcurementStatus.inTransit,
        ProcurementStatus.goodsReceived,
      };
      final active =
          orders.where((o) => !done.contains(ProcurementStatus.fromStorage(o.status))).toList();
      final toAct =
          active.where((o) => vendorActs.contains(ProcurementStatus.fromStorage(o.status))).length;
      open = '${active.length}';
      awaiting = '${toAct + rfqs.length}';
      month = '${orders.where((o) => _thisMonth(o.createdAt)).length}';
    } else {
      final items = ref.watch(requestsListProvider).valueOrNull ?? const <Procurement>[];
      final mine = awaitingStatusesFor(role);
      open = '${items.where((p) {
        final st = ProcurementStatus.fromStorage(p.status);
        return !st.isTerminal && st != ProcurementStatus.paid;
      }).length}';
      awaiting = '${items.where((p) => mine.contains(ProcurementStatus.fromStorage(p.status))).length}';
      month = '${items.where((p) => _thisMonth(p.createdAt)).length}';
    }

    final unread = ref.watch(unreadCountProvider).valueOrNull ?? 0;

    return Scaffold(
      appBar: AppBar(
        leading: shellMenuLeading(context),
        title: const Text('Home'),
        actions: [
          IconButton(
            tooltip: 'Notifications',
            onPressed: () async {
              await Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const NotificationsPage()),
              );
              ref.invalidate(unreadCountProvider);
            },
            icon: Badge(
              isLabelVisible: unread > 0,
              label: Text('$unread'),
              child: const Icon(Icons.notifications_none),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('Welcome${user != null ? ', ${user.displayName}' : ''}',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text(role.label, style: const TextStyle(color: ProcuraColors.muted)),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(child: _stat('Open', open)),
              const SizedBox(width: 12),
              Expanded(child: _stat(awaitingLabel, awaiting)),
              const SizedBox(width: 12),
              Expanded(child: _stat('This month', month)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _stat(String label, String value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        child: Column(
          children: [
            Text(value,
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w700, color: ProcuraColors.gold)),
            const SizedBox(height: 4),
            Text(label,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: ProcuraColors.muted)),
          ],
        ),
      ),
    );
  }
}
