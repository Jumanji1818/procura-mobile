import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/procura_theme.dart';
import '../../domain/services/auth_service.dart';
import '../shell/app_shell.dart';
import 'auth_providers.dart';

class RegisterPage extends ConsumerStatefulWidget {
  const RegisterPage({super.key});

  @override
  ConsumerState<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends ConsumerState<RegisterPage> {
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _asVendor = false;
  final Set<String> _selectedCategoryIds = {};
  List<({String id, String parent, String sub})> _categories = [];
  String? _error;
  bool _busy = false;
  bool _loadingCats = true;

  @override
  void initState() {
    super.initState();
    _loadCategories();
  }

  Future<void> _loadCategories() async {
    try {
      final db = ref.read(databaseProvider);
      final rows = await db.select(db.categories).get();
      setState(() {
        _categories = rows
            .map((r) => (id: r.id, parent: r.parentName, sub: r.subcategory))
            .toList()
          ..sort((a, b) => '${a.parent}${a.sub}'.compareTo('${b.parent}${b.sub}'));
        _loadingCats = false;
      });
    } catch (_) {
      setState(() {
        _loadingCats = false;
        _error = 'Could not load categories.';
      });
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_asVendor) {
      if (_selectedCategoryIds.isEmpty || _selectedCategoryIds.length > 3) {
        setState(() => _error = 'Select 1–3 categories for your vendor profile.');
        return;
      }
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(sessionProvider.notifier).register(
            email: _email.text,
            displayName: _name.text,
            password: _password.text,
            asVendor: _asVendor,
            categoryIds: _selectedCategoryIds.toList(),
            businessName: _asVendor ? _name.text : null,
          );
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const AppShell()),
        (_) => false,
      );
    } on AuthException catch (e) {
      setState(() => _error = e.message);
    } catch (_) {
      setState(() => _error = 'Could not create account.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create account')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 480),
          child: ListView(
            padding: const EdgeInsets.all(24),
            children: [
              TextField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'Full name / business name'),
              ),
              const SizedBox(height: 12),
              TextField(controller: _email, decoration: const InputDecoration(labelText: 'Email')),
              const SizedBox(height: 12),
              TextField(
                controller: _password,
                decoration: const InputDecoration(labelText: 'Password (min 8)'),
                obscureText: true,
              ),
              SwitchListTile(
                title: const Text('Register as vendor'),
                value: _asVendor,
                activeColor: ProcuraColors.gold,
                onChanged: (v) => setState(() => _asVendor = v),
              ),
              if (!_asVendor)
                const Text(
                  'Staff accounts start as Pending until an Org Admin assigns a role.',
                  style: TextStyle(color: ProcuraColors.muted, fontSize: 13),
                ),
              if (_asVendor) ...[
                const SizedBox(height: 8),
                const Text(
                  'Select 1–3 categories you supply',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 8),
                if (_loadingCats)
                  const Center(child: CircularProgressIndicator())
                else
                  ..._categories.map((c) {
                    final selected = _selectedCategoryIds.contains(c.id);
                    return CheckboxListTile(
                      dense: true,
                      title: Text('${c.parent} · ${c.sub}', style: const TextStyle(fontSize: 14)),
                      value: selected,
                      activeColor: ProcuraColors.gold,
                      onChanged: (v) {
                        setState(() {
                          if (v == true) {
                            if (_selectedCategoryIds.length >= 3) {
                              _error = 'Maximum 3 categories.';
                              return;
                            }
                            _selectedCategoryIds.add(c.id);
                            _error = null;
                          } else {
                            _selectedCategoryIds.remove(c.id);
                          }
                        });
                      },
                    );
                  }),
              ],
              if (_error != null) ...[
                const SizedBox(height: 8),
                Text(_error!, style: const TextStyle(color: ProcuraColors.danger)),
              ],
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _busy ? null : _submit,
                child: Text(_busy ? 'Creating…' : 'Create account'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
