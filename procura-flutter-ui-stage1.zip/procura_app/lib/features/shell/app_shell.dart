import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/procura_theme.dart';
import '../../domain/models/auth_user.dart';
import '../../domain/models/role.dart';
import '../auth/auth_providers.dart';
import '../auth/login_page.dart';
import '../dashboard/dashboard_page.dart';
import '../requests/requests_page.dart';
import '../bidding/rfq_list_page.dart';
import '../delivery/orders_page.dart';
import '../finance/payments_page.dart';
import '../reports/reports_page.dart';
import '../account/account_page.dart';
import '../team/team_page.dart';
import 'shell_menu.dart';

enum ShellLayout {
  phone,
  compactRail,
  desktopRail,
}

ShellLayout shellLayoutForWidth(double width) {
  if (width < 600) return ShellLayout.phone;
  if (width < 960) return ShellLayout.compactRail;
  return ShellLayout.desktopRail;
}

int shellSelectedIndex(int index, int destinationCount) {
  if (destinationCount <= 0 || index < 0) return 0;
  if (index >= destinationCount) return destinationCount - 1;
  return index;
}

class AppShell extends ConsumerStatefulWidget {
  const AppShell({super.key});

  @override
  ConsumerState<AppShell> createState() => _AppShellState();
}

class _AppShellState extends ConsumerState<AppShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider);
    if (user == null) {
      return const LoginPage();
    }

    final layout = shellLayoutForWidth(MediaQuery.sizeOf(context).width);
    final destinations = _destinationsFor(user.role);
    final selectedIndex = shellSelectedIndex(_index, destinations.length);

    if (destinations.isEmpty) {
      return const Scaffold(body: SafeArea(child: _PendingRoleView()));
    }
    final body = destinations[selectedIndex].page;

    if (layout != ShellLayout.phone) {
      final compact = layout == ShellLayout.compactRail;
      return Scaffold(
        body: Row(
          children: [
            NavigationRail(
              extended: !compact,
              minWidth: 72,
              minExtendedWidth: 220,
              selectedIndex: selectedIndex,
              onDestinationSelected: (i) => setState(() => _index = i),
              labelType: compact
                  ? NavigationRailLabelType.selected
                  : NavigationRailLabelType.all,
              leading: Padding(
                padding: EdgeInsets.symmetric(vertical: compact ? 12 : 16),
                child: compact
                    ? const Icon(
                        Icons.account_balance,
                        color: ProcuraColors.gold,
                        size: 28,
                      )
                    : Column(
                        children: [
                          const Icon(
                            Icons.account_balance,
                            color: ProcuraColors.gold,
                            size: 32,
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'Procura',
                            style: TextStyle(
                              color: ProcuraColors.gold,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            user.role.label,
                            style: const TextStyle(
                              fontSize: 11,
                              color: ProcuraColors.muted,
                            ),
                          ),
                        ],
                      ),
              ),
              destinations: destinations
                  .map((d) => NavigationRailDestination(icon: Icon(d.icon), label: Text(d.label)))
                  .toList(),
              trailing: Expanded(
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: IconButton(
                    tooltip: 'Sign out',
                    onPressed: () {
                      ref.read(sessionProvider.notifier).logout();
                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                      );
                    },
                    icon: const Icon(Icons.logout, color: ProcuraColors.muted),
                  ),
                ),
              ),
            ),
            const VerticalDivider(width: 1),
            Expanded(child: body),
          ],
        ),
      );
    }

    // Phone: bottom navigation. SafeArea keeps the navigation bar clear of
    // gesture indicators and prevents short screens from clipping page content.
    return Scaffold(
      key: shellScaffoldKey,
      extendBody: true,
      drawer: _ShellDrawer(
        user: user,
        destinations: destinations,
        selectedIndex: selectedIndex,
        onSelect: (i) {
          shellScaffoldKey.currentState?.closeDrawer();
          setState(() => _index = i);
        },
        onSignOut: () {
          ref.read(sessionProvider.notifier).logout();
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const LoginPage()),
            (_) => false,
          );
        },
      ),
      body: SafeArea(top: false, child: body),
      bottomNavigationBar: destinations.isEmpty
          ? null
          : SafeArea(
              top: false,
              child: NavigationBar(
                height: 68,
                selectedIndex: selectedIndex,
                onDestinationSelected: (i) => setState(() => _index = i),
                destinations: destinations
                    .map(
                      (d) => NavigationDestination(
                        icon: Icon(d.icon),
                        label: d.label,
                      ),
                    )
                    .toList(),
              ),
            ),
    );
  }

  List<_NavDest> _destinationsFor(UserRole role) {
    if (role == UserRole.pending) return [];
    final home = _NavDest('Home', Icons.home_outlined, const DashboardPage());
    final account = _NavDest('Account', Icons.person_outline, const AccountPage());
    switch (role) {
      case UserRole.vendor:
        return [
          home,
          _NavDest('RFQs', Icons.list_alt, const RfqListPage()),
          _NavDest('Orders', Icons.local_shipping_outlined, const OrdersPage()),
          account,
        ];
      case UserRole.financeOfficer:
        return [
          home,
          _NavDest('Payments', Icons.payments_outlined, const PaymentsPage()),
          _NavDest('Reports', Icons.bar_chart, const ReportsPage()),
          account,
        ];
      case UserRole.departmentHead:
        return [
          home,
          _NavDest('Approvals', Icons.fact_check_outlined, const RequestsPage()),
          account,
        ];
      case UserRole.orgAdmin:
        return [
          home,
          _NavDest('Requests', Icons.description_outlined, const RequestsPage()),
          _NavDest('Reports', Icons.bar_chart, const ReportsPage()),
          _NavDest('Team', Icons.group_outlined, const TeamPage()),
          account,
        ];
      default:
        return [
          home,
          _NavDest('Requests', Icons.description_outlined, const RequestsPage()),
          _NavDest('Reports', Icons.bar_chart, const ReportsPage()),
          account,
        ];
    }
  }
}

class _NavDest {
  final String label;
  final IconData icon;
  final Widget page;
  _NavDest(this.label, this.icon, this.page);
}

/// Slide-out menu for the phone layout (the rail covers wider screens).
class _ShellDrawer extends StatelessWidget {
  const _ShellDrawer({
    required this.user,
    required this.destinations,
    required this.selectedIndex,
    required this.onSelect,
    required this.onSignOut,
  });

  final AuthUser user;
  final List<_NavDest> destinations;
  final int selectedIndex;
  final ValueChanged<int> onSelect;
  final VoidCallback onSignOut;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [ProcuraColors.goldSoft, ProcuraColors.surface],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.account_balance, color: ProcuraColors.gold, size: 28),
                      SizedBox(width: 10),
                      Text(
                        'Procura',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                          color: ProcuraColors.gold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Text(
                    user.displayName,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    user.email,
                    style: const TextStyle(fontSize: 12, color: ProcuraColors.muted),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    user.role.label,
                    style: const TextStyle(fontSize: 12, color: ProcuraColors.gold),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                children: [
                  for (var i = 0; i < destinations.length; i++)
                    ListTile(
                      selected: i == selectedIndex,
                      selectedColor: ProcuraColors.gold,
                      selectedTileColor: ProcuraColors.goldSoft,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      leading: Icon(destinations[i].icon),
                      title: Text(destinations[i].label),
                      onTap: () => onSelect(i),
                    ),
                ],
              ),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.logout, color: ProcuraColors.muted),
              title: const Text('Sign out'),
              onTap: onSignOut,
            ),
          ],
        ),
      ),
    );
  }
}

class _PendingRoleView extends ConsumerWidget {
  const _PendingRoleView();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.hourglass_top, color: ProcuraColors.gold, size: 48),
            const SizedBox(height: 16),
            const Text('Awaiting role assignment',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            const Text(
              'An Org Admin must assign your role before you can work in Procura.',
              textAlign: TextAlign.center,
              style: TextStyle(color: ProcuraColors.muted),
            ),
            const SizedBox(height: 24),
            OutlinedButton.icon(
              icon: const Icon(Icons.logout),
              label: const Text('Sign out'),
              onPressed: () {
                ref.read(sessionProvider.notifier).logout();
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginPage()),
                  (_) => false,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
