import 'package:flutter/material.dart';

/// Key of the phone layout's Scaffold, so any page can open the side menu.
final GlobalKey<ScaffoldState> shellScaffoldKey = GlobalKey<ScaffoldState>();

/// Hamburger button for page app bars. Returns null on tablet/desktop widths,
/// where the navigation rail is always visible.
Widget? shellMenuLeading(BuildContext context) {
  if (MediaQuery.sizeOf(context).width >= 600) return null;
  return IconButton(
    tooltip: 'Menu',
    icon: const Icon(Icons.menu),
    onPressed: () => shellScaffoldKey.currentState?.openDrawer(),
  );
}
