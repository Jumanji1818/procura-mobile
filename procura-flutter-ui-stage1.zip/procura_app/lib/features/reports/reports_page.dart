import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:fl_chart/fl_chart.dart';
import 'package:printing/printing.dart';

import '../../core/theme/procura_theme.dart';
import '../../domain/services/report_pdf.dart';
import '../../domain/services/reports_service.dart';
import '../finance/finance_providers.dart';
import '../shell/shell_menu.dart';

class ReportsPage extends ConsumerStatefulWidget {
  const ReportsPage({super.key});

  @override
  ConsumerState<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends ConsumerState<ReportsPage> {
  List<String> _lines = ['Loading…'];
  List<CategorySpend> _allCats = [];
  List<CategorySpend> _cats = [];
  List<SpendPoint> _trend = [];
  double? _forecast;
  Map<String, int> _statuses = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final reports = ref.read(reportsServiceProvider);
    final byCat = await reports.spendByCategory();
    final trend = await reports.monthlySpendTrend();
    final forecast = await reports.nextMonthEstimateNaira();
    final statuses = await reports.countByStatus();

    final lines = <String>[
      'Spend by category',
      if (byCat.isEmpty) '  (no payments yet)' else ...byCat.take(8).map(
            (c) => '  ${c.category}: ₦${c.amountNaira.toStringAsFixed(0)}',
          ),
      '',
      'Monthly trend',
      if (trend.isEmpty) '  (no payments yet)' else ...trend.map(
            (t) => '  ${t.label}: ₦${t.amountNaira.toStringAsFixed(0)}',
          ),
      '',
      if (forecast != null)
        'Next-month estimate (3-month moving average): ₦${forecast.toStringAsFixed(0)}'
      else
        'Next-month estimate: insufficient history',
      '',
      'Procurements by status',
      ...statuses.entries.map((e) => '  ${e.key}: ${e.value}'),
    ];
    if (mounted) {
      setState(() {
        _lines = lines;
        _allCats = byCat;
        _cats = byCat.take(6).toList();
        _trend = trend;
        _forecast = forecast;
        _statuses = statuses;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: shellMenuLeading(context),
        title: const Text('Reports'),
        actions: [
          IconButton(
            tooltip: 'Export PDF',
            icon: const Icon(Icons.picture_as_pdf_outlined),
            onPressed: () async {
              final bytes = await ReportPdf.build(
                byCategory: _allCats,
                trend: _trend,
                forecastNaira: _forecast,
                statusCounts: _statuses,
              );
              await Printing.layoutPdf(onLayout: (_) async => bytes, name: 'procura-report');
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'Local insights from this install only. Forecast is an estimate.',
            style: TextStyle(color: ProcuraColors.muted, fontSize: 13),
          ),
          const SizedBox(height: 16),
          if (_cats.isNotEmpty) ...[
            const Text('Spend by category (₦)',
                style: TextStyle(fontWeight: FontWeight.w600, color: ProcuraColors.gold)),
            const SizedBox(height: 8),
            _BarChartBox(
              labels: _cats.map((c) => c.category.split(' · ').last).toList(),
              values: _cats.map((c) => c.amountNaira).toList(),
            ),
            const SizedBox(height: 16),
          ],
          if (_trend.isNotEmpty) ...[
            const Text('Monthly spend (₦)',
                style: TextStyle(fontWeight: FontWeight.w600, color: ProcuraColors.gold)),
            const SizedBox(height: 8),
            _BarChartBox(
              labels: _trend.map((t) => t.label).toList(),
              values: _trend.map((t) => t.amountNaira).toList(),
            ),
            const SizedBox(height: 16),
          ],
          ..._lines.map(
            (l) => Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text(
                l,
                style: TextStyle(
                  fontWeight: l.startsWith(' ') ? FontWeight.normal : FontWeight.w600,
                  color: l.startsWith(' ') ? ProcuraColors.text : ProcuraColors.gold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _BarChartBox extends StatelessWidget {
  final List<String> labels;
  final List<double> values;
  const _BarChartBox({required this.labels, required this.values});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 190,
      child: BarChart(
        BarChartData(
          alignment: BarChartAlignment.spaceAround,
          gridData: const FlGridData(show: false),
          borderData: FlBorderData(show: false),
          titlesData: FlTitlesData(
            leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 30,
                getTitlesWidget: (value, meta) {
                  final i = value.toInt();
                  if (i < 0 || i >= labels.length) return const SizedBox.shrink();
                  final t = labels[i];
                  return Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      t.length > 8 ? '${t.substring(0, 8)}…' : t,
                      style: const TextStyle(fontSize: 10, color: ProcuraColors.muted),
                    ),
                  );
                },
              ),
            ),
          ),
          barGroups: [
            for (var i = 0; i < values.length; i++)
              BarChartGroupData(
                x: i,
                barRods: [
                  BarChartRodData(toY: values[i], color: ProcuraColors.gold, width: 18),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
