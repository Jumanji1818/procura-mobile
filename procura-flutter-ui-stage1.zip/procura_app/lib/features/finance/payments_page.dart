import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:printing/printing.dart';

import '../../core/theme/procura_theme.dart';
import '../../domain/models/procurement_status.dart';
import '../../data/db/app_database.dart';
import '../../domain/models/role.dart';
import '../../domain/services/invoice_pdf.dart';
import '../../shared/utils/money.dart';
import '../auth/auth_providers.dart';
import '../delivery/fulfillment_providers.dart';
import '../requests/requests_providers.dart';
import 'finance_providers.dart';
import '../shell/shell_menu.dart';

class PaymentsPage extends ConsumerStatefulWidget {
  const PaymentsPage({super.key});

  @override
  ConsumerState<PaymentsPage> createState() => _PaymentsPageState();
}

class _PaymentsPageState extends ConsumerState<PaymentsPage> {
  bool _busy = false;

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  /// Shows invoice, PO, receipt and match result, then lets finance pay or hold.
  Future<void> _review(Procurement p) async {
    final procurementId = p.id;
    final user = ref.read(currentUserProvider);
    if (user == null || _busy) return;
    final svc = ref.read(financeServiceProvider);
    final preview = await svc.paymentPreview(procurementId);
    if (!mounted) return;
    if (preview == null) {
      _toast('No invoice details found.');
      return;
    }
    final canAct = user.role == UserRole.financeOfficer && preview.invoice.status != 'paid';
    final onHold = preview.invoice.status == 'mismatch';

    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Invoice ${preview.invoice.number}'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _line('Invoiced', formatNaira(preview.invoice.amountKobo)),
              _line('PO total (${preview.po.number})', formatNaira(preview.po.totalKobo)),
              _line('Ordered / received',
                  '${preview.receipt.qtyOrdered} / ${preview.receipt.qtyReceived}'),
              _line('Damaged / missing',
                  '${preview.receipt.qtyDamaged} / ${preview.receipt.qtyMissing}'),
              _line('Supported by goods received', formatNaira(preview.match.expectedAmountKobo)),
              const Divider(),
              Text(
                preview.match.ok ? 'Three-way match: OK' : 'Three-way match: MISMATCH',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: preview.match.ok ? ProcuraColors.success : ProcuraColors.danger,
                ),
              ),
              const SizedBox(height: 4),
              Text(preview.match.detail, style: const TextStyle(fontSize: 13)),
              const SizedBox(height: 12),
              Text(
                'Amount that will be paid: ${formatNaira(preview.payableKobo)}',
                style: const TextStyle(fontWeight: FontWeight.w700, color: ProcuraColors.gold),
              ),
              if (preview.payableKobo < preview.invoice.amountKobo)
                const Padding(
                  padding: EdgeInsets.only(top: 4),
                  child: Text(
                    'Payment is capped at what the PO and the goods received support.',
                    style: TextStyle(fontSize: 12, color: ProcuraColors.muted),
                  ),
                ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
          TextButton(
            onPressed: () async {
              final vendor = await ref
                  .read(fulfillmentServiceProvider)
                  .vendorName(preview.invoice.vendorId);
              final bytes = await InvoicePdf.build(
                invoice: preview.invoice,
                po: preview.po,
                receipt: preview.receipt,
                match: preview.match,
                vendorName: vendor,
                requestNumber: p.number,
                requestTitle: p.title,
              );
              await Printing.layoutPdf(onLayout: (_) async => bytes, name: preview.invoice.number);
            },
            child: const Text('Print PDF'),
          ),
          if (canAct && !onHold && preview.invoice.status == 'submitted')
            TextButton(onPressed: () => Navigator.pop(ctx, 'hold'), child: const Text('Hold')),
          if (canAct)
            ElevatedButton(onPressed: () => Navigator.pop(ctx, 'pay'), child: const Text('Approve payment')),
        ],
      ),
    );
    if (choice == null || !mounted) return;

    setState(() => _busy = true);
    try {
      if (choice == 'pay') {
        await svc.approvePayment(actor: user, procurementId: procurementId, method: 'transfer');
        _toast('Payment approved.');
      } else if (choice == 'hold') {
        final reason = await _askReason();
        if (reason == null) return;
        await svc.holdPayment(actor: user, procurementId: procurementId, reason: reason);
        _toast('Payment held for review.');
      }
      ref.invalidate(requestsListProvider);
    } catch (e) {
      _toast('$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<String?> _askReason() {
    final c = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hold payment'),
        content: TextField(
          controller: c,
          maxLines: 3,
          decoration: const InputDecoration(labelText: 'Reason'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('Hold')),
        ],
      ),
    );
  }

  Widget _line(String k, String v) => Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: Text(k, style: const TextStyle(color: ProcuraColors.muted, fontSize: 13))),
            const SizedBox(width: 8),
            Text(v, style: const TextStyle(fontSize: 13)),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final list = ref.watch(requestsListProvider);

    return Scaffold(
      appBar: AppBar(leading: shellMenuLeading(context), title: const Text('Payments')),
      body: list.when(
        loading: () => const Center(child: CircularProgressIndicator(color: ProcuraColors.gold)),
        error: (e, _) => Center(child: Text('$e')),
        data: (items) {
          final payable = items.where((p) {
            final st = ProcurementStatus.fromStorage(p.status);
            return st == ProcurementStatus.invoiced ||
                st == ProcurementStatus.paymentReview ||
                st == ProcurementStatus.paid;
          }).toList();
          if (payable.isEmpty) {
            return const Center(
              child: Text('No invoices awaiting payment.', style: TextStyle(color: ProcuraColors.muted)),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: payable.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final p = payable[i];
              final st = ProcurementStatus.fromStorage(p.status);
              return Card(
                child: ListTile(
                  title: Text(p.title),
                  subtitle: Text('${p.number} · ${st.label}',
                      style: const TextStyle(color: ProcuraColors.muted, fontSize: 12)),
                  trailing: TextButton(
                    onPressed: _busy ? null : () => _review(p),
                    child: Text(st == ProcurementStatus.paid ? 'View' : 'Review'),
                  ),
                  onTap: _busy ? null : () => _review(p),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
