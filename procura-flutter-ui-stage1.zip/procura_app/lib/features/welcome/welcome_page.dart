import 'package:flutter/material.dart';

import '../../core/theme/procura_theme.dart';
import '../auth/login_page.dart';
import '../auth/register_page.dart';

class _Feature {
  final IconData icon;
  final String title;
  final String subtitle;
  const _Feature(this.icon, this.title, this.subtitle);
}

/// First screen a person sees: what Procura is, then sign in or register.
class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  static const _features = <_Feature>[
    _Feature(Icons.description_outlined, 'Requests & approvals',
        'Raise a request and route it through the right approvers.'),
    _Feature(Icons.gavel_outlined, 'Competitive bidding',
        'Invite matching vendors and compare bids side by side.'),
    _Feature(Icons.insights_outlined, 'Smart vendor scoring',
        'Recommendations weigh price, delivery and reliability.'),
    _Feature(Icons.local_shipping_outlined, 'Delivery to payment',
        'Track purchase orders, receipts, invoices and payments.'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [ProcuraColors.goldSoft, ProcuraColors.canvas],
            stops: [0.0, 0.45],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Container(
                        width: 84,
                        height: 84,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: ProcuraColors.surface,
                          border: Border.all(color: ProcuraColors.gold, width: 1.5),
                        ),
                        child: const Icon(Icons.account_balance,
                            size: 40, color: ProcuraColors.gold),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Procura',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 38,
                        fontWeight: FontWeight.w600,
                        color: ProcuraColors.gold,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Procurement, from request to payment.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16, color: ProcuraColors.text),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'One workspace for requests, bids, purchase orders, '
                      'delivery and payment, with a full audit trail.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: ProcuraColors.muted),
                    ),
                    const SizedBox(height: 28),
                    for (final f in _features) ...[
                      Card(
                        margin: EdgeInsets.zero,
                        child: ListTile(
                          leading: Icon(f.icon, color: ProcuraColors.gold),
                          title: Text(f.title,
                              style: const TextStyle(fontWeight: FontWeight.w600)),
                          subtitle: Text(f.subtitle,
                              style: const TextStyle(color: ProcuraColors.muted)),
                        ),
                      ),
                      const SizedBox(height: 10),
                    ],
                    const SizedBox(height: 18),
                    ElevatedButton(
                      onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                      ),
                      child: const Text('Sign in'),
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size.fromHeight(48),
                        foregroundColor: ProcuraColors.gold,
                        side: const BorderSide(color: ProcuraColors.gold),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                      onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const RegisterPage()),
                      ),
                      child: const Text('Create an account'),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Works fully offline. Your data stays on this device.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, color: ProcuraColors.muted),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
