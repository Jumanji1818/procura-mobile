import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/procura_theme.dart';
import '../auth/auth_providers.dart';
import '../auth/login_page.dart';
import '../shell/shell_menu.dart';

/// Profile plus sign-out, available on every layout (the phone layout has no rail).
class AccountPage extends ConsumerWidget {
  const AccountPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    return Scaffold(
      appBar: AppBar(leading: shellMenuLeading(context), title: const Text('Account')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(Icons.account_circle_outlined, size: 64, color: ProcuraColors.gold),
          const SizedBox(height: 12),
          Center(
            child: Text(user?.displayName ?? '',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
          ),
          const SizedBox(height: 4),
          Center(child: Text(user?.email ?? '', style: const TextStyle(color: ProcuraColors.muted))),
          const SizedBox(height: 4),
          Center(child: Text(user?.role.label ?? '', style: const TextStyle(color: ProcuraColors.gold))),
          const SizedBox(height: 32),
          OutlinedButton.icon(
            icon: const Icon(Icons.logout),
            label: const Text('Sign out'),
            onPressed: () {
              ref.read(sessionProvider.notifier).logout();
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (_) => false,
              );
            },
          ),
        ],
      ),
    );
  }
}
