import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:procura/core/theme/procura_theme.dart';
import 'package:procura/features/welcome/welcome_page.dart';

void main() {
  testWidgets('welcome page offers sign in and registration', (tester) async {
    await tester.pumpWidget(
      MaterialApp(theme: ProcuraTheme.dark, home: const WelcomePage()),
    );
    expect(find.text('Procura'), findsOneWidget);
    expect(find.text('Sign in'), findsOneWidget);
    expect(find.text('Create an account'), findsOneWidget);
  });
}
